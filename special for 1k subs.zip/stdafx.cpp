#include "stdafx.h"

CInterfaces Interfaces;
CUtils Utils;

HMODULE INIT::Dll;
bool INIT::Exit;
WNDPROC INIT::OldWindow = 0;
