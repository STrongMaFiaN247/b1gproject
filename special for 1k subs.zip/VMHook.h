
extern unsigned char(__cdecl *ReadByte) (uintptr_t);
extern int(__cdecl *ReadInt) (uintptr_t);
extern float(__cdecl *ReadFloat) (uintptr_t);
extern double(__cdecl *ReadDouble) (uintptr_t);
extern short(__cdecl *ReadShort) (uintptr_t);
extern void(__cdecl *WriteByte) (uintptr_t, unsigned char);
extern void(__cdecl *WriteInt) (uintptr_t, int);
extern void(__cdecl *WriteFloat) (uintptr_t, float);
extern void(__cdecl *WriteDouble) (uintptr_t, double);
extern void(__cdecl *WriteShort) (uintptr_t, short);
#ifndef VTHOOK_H
#define VTHOOK_H


class VTHook
{
public:
	VTHook()
	{
		memset(this, 0, sizeof(VTHook));
	}

	VTHook(PDWORD* ppdwClassBase)
	{
		bInitialize(ppdwClassBase);
	}

	~VTHook()
	{
		if (m_ClassBase)
		{
			//*m_ClassBase = m_OldVT;
			WriteInt(ReadInt((DWORD)m_ClassBase), (int)m_OldVT);
		}
	}

	PDWORD* GetClassBase()
	{
		return m_ClassBase;
	}

	void ClearClassBase()
	{
		m_ClassBase = NULL;
	}

	void /*bool*/ bInitialize(PDWORD* ppdwClassBase)
	{
		auto WriteByteArray  = [](char* dest, char* source, int sourcelength)
		{
			for (int i = 0; i < sourcelength; i++)
			{
				WriteByte((uintptr_t)(dest + i), source[i]);
			}
		};
#if 1
		m_ClassBase = ppdwClassBase; // Get Pointer to the class base and store in member variable of current object
									 //m_OldVT = *ppdwClassBase; // Get Pointer the the Old Virtual Address Table
		m_OldVT = (PDWORD)ReadInt((DWORD)ppdwClassBase);
		m_VTSize = GetVTCount(m_OldVT);//*ppdwClassBase); // Get the number of functions in the Virtual Address Table


		m_NewVT = new DWORD[m_VTSize + 1]; // Create A new virtual Address Table
										   //memcpy(m_NewVT, m_OldVT, sizeof(DWORD) * m_VTSize);

		WriteByteArray((char*)((DWORD)m_NewVT + 4), (char*)m_OldVT, sizeof(DWORD) * m_VTSize); //Use driver to write instead of hack
																							   //*ppdwClassBase = m_NewVT; // replace the old virtual address table pointer with a pointer to the newly created virtual address table above
		m_NewVT[0] = (DWORD)ReadInt((DWORD)m_OldVT - 4);

		WriteInt(ReadInt((DWORD)&ppdwClassBase), (int)((DWORD)m_NewVT + 4));
		//return true;
#else
		m_ClassBase = ppdwClassBase; // Get Pointer to the class base and store in member variable of current object
									 //m_OldVT = *ppdwClassBase; // Get Pointer the the Old Virtual Address Table
		m_OldVT = (PDWORD)ReadInt((DWORD)ppdwClassBase);
		m_VTSize = GetVTCount(m_OldVT);//*ppdwClassBase); // Get the number of functions in the Virtual Address Table
		m_VTSize++; //for rtti
		m_NewVT = new DWORD[m_VTSize]; // Create A new virtual Address Table
									   //memcpy(m_NewVT, m_OldVT, sizeof(DWORD) * m_VTSize);
		WriteByteArray((char*)((DWORD)m_NewVT + sizeof(DWORD)), (char*)m_OldVT, sizeof(DWORD) * (m_VTSize - 1)); //Use driver to write instead of hack
		m_NewVT[0] = ReadInt((DWORD)m_OldVT - sizeof(DWORD));
		//*ppdwClassBase = m_NewVT; // replace the old virtual address table pointer with a pointer to the newly created virtual address table above
		WriteInt(ReadInt((DWORD)&ppdwClassBase), (DWORD)m_NewVT + sizeof(DWORD));
		//return true;
#endif
	}
	void /*bool*/ bInitialize(PDWORD** pppdwClassBase) // fix for pp
	{
		//return bInitialize(*pppdwClassBase);
		bInitialize(*pppdwClassBase);
	}

	/*
	void ReHook()
	{
	if (m_ClassBase)
	{
	*m_ClassBase = m_NewVT;
	}
	}
	*/
	/*
	int iGetFuncCount()
	{
	return (int)m_VTSize;
	}
	*/
	/*
	DWORD GetFuncAddress(int Index)
	{
	if (Index >= 0 && Index <= (int)m_VTSize && m_OldVT != NULL)
	{
	return m_OldVT[Index];
	}
	return NULL;
	}
	*/

	/*
	PDWORD GetOldVT()
	{
	return m_OldVT;
	}
	*/

	DWORD HookFunction(DWORD dwNewFunc, unsigned int iIndex)
	{
		// Noel: Check if both the New Virtual Address Table and the the Old one have been allocated and exist,
		// also check if the function index into the New Virtual Address Table is within the bounds of the table
		if (m_NewVT && m_OldVT && iIndex <= m_VTSize && iIndex >= 0)
		{
			m_NewVT[iIndex + 1] = dwNewFunc; // Set the new function to be called in the new virtual address table
			return ReadInt((DWORD)m_OldVT + (sizeof(DWORD*) * iIndex));
			//return m_OldVT[iIndex]; // Return the old function to be called in the virtual address table
		}
		// Return null and fail if the new Virtual Address Table or the old one hasn't been allocated with = new,
		// or if the index chosen is outside the bounds of the table.
		return NULL;
	}

private:

	//Use standard C++ functions instead
	BOOL CodePointerIsInvalid(DWORD* testptr) {
#if 0
		bool Invalid = false;
		int test;
		try {
			test = ReadInt((DWORD)testptr);
		}
		catch (...) {
			Invalid = true;
		}
		return Invalid;
#else

		return IsBadCodePtr((FARPROC)testptr);
#endif
	}
	DWORD GetVTCount(PDWORD pdwVMT)
	{
		DWORD dwIndex = NULL;

		for (dwIndex = 0; pdwVMT[dwIndex]; dwIndex++)
			if (!pdwVMT[dwIndex])
				break;

		/*
		for (dwIndex = 0; pdwVMT[dwIndex] != 0; dwIndex++)
		{
		//if (ShitPointer((DWORD*)pdwVMT[dwIndex]))
		//break;

		if (CodePointerIsInvalid((DWORD*)ReadInt((DWORD)pdwVMT + (sizeof(DWORD*) * dwIndex))))
		break;

		//Original code, uses windows api function

		//if (IsBadCodePtr((FARPROC)pdwVMT[dwIndex]))
		//{
		//break;
		//}
		}
		*/
		return dwIndex;
	}
	PDWORD*	m_ClassBase;
	PDWORD	m_NewVT, m_OldVT;
	DWORD	m_VTSize;
}; 
extern VTHook* HNetchanZ;