#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#include <winhttp.h>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <time.h>
#include <cstring>
#include <iostream>


#pragma comment( lib, "Winhttp.lib" )
#pragma comment (lib, "urlmon.lib")



using namespace std;



class my_license
{
	typedef void(_stdcall *GSI)(LPSYSTEM_INFO);
public:
	const  char
		*user_name = new char,
		*user_password = new char,
		*user_key = new char;

	virtual std::string        generate_key();
	virtual std::string GetRec(std::string, int);

	virtual void        win32_copy_to_clipboardW(char*);
	virtual bool        check_license(std::string, std::string);
	std::string
		host = "spectro.pw/",
		path = "cheat/",
		host_gate_login = "license-test.php?login=",
		host_gate_password = "&password=",
		host_gate_system_key = "&binding=",
		host_gate_token = "&token=",
		host_gate_inject = "&inject=1",
		base64_chars =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz"
		"0123456789+/";
private:
	virtual DWORD       get_system_info();
	virtual char*       string_to_hex(const char * input);
	virtual char*       convert_key_to_char(const char*, const char*, DWORD);

	virtual std::string get_hash_system_key();
	virtual std::string str_to_hex(const std::string);
	virtual std::string get_hash_text(const void*, const size_t);
	virtual std::string base64_encode(char const*, unsigned int);

	SYSTEM_INFO sysinfo;
	DWORD system_key = NULL;
	HGLOBAL hMem = NULL;
	UINT uFormat = NULL;


};

my_license* my_lic = new my_license();
#include <cstring>
#include <iostream>


class MD5
{
public:
	typedef unsigned int size_type;

	MD5();
	MD5(const std::string&);
	virtual MD5& finalize();
	virtual void update(const unsigned char *, size_type);
	virtual void update(const char *, size_type);
	virtual 	std::string hexdigest() const;
	friend std::ostream& operator<<(std::ostream&, MD5);

private:
	void init();
	typedef unsigned char uint1;
	typedef unsigned int uint4;
	enum { blocksize = 64 };

	virtual void transform(const uint1 block[blocksize]);
	static void decode(uint4 output[], const uint1 input[], size_type len);
	static void encode(uint1 output[], const uint4 input[], size_type len);

	bool finalized;
	uint1 buffer[blocksize];
	uint4 count[2];
	uint4 state[4];
	uint1 digest[16];


	static inline uint4 F(uint4 x, uint4 y, uint4 z);
	static inline uint4 G(uint4 x, uint4 y, uint4 z);
	static inline uint4 H(uint4 x, uint4 y, uint4 z);
	static inline uint4 I(uint4 x, uint4 y, uint4 z);
	static inline uint4 rotate_left(uint4 x, int n);
	static inline void FF(uint4 &a, uint4 b, uint4 c, uint4 d, uint4 x, uint4 s, uint4 ac);
	static inline void GG(uint4 &a, uint4 b, uint4 c, uint4 d, uint4 x, uint4 s, uint4 ac);
	static inline void HH(uint4 &a, uint4 b, uint4 c, uint4 d, uint4 x, uint4 s, uint4 ac);
	static inline void II(uint4 &a, uint4 b, uint4 c, uint4 d, uint4 x, uint4 s, uint4 ac);
};

std::string md5(const std::string str);


class CHTTPSession
{
private:
	HINTERNET hSession, hConnect, hRequest;
	LPCWSTR wcUserAgent;
	LPCWSTR wcHTTPVerb;

	int iHTTPMethod;
	std::wstring wsDomain, wsDocument;
	std::string sPOSTData, sPOSTFile;
	int iSESSION_PROTOCOL, iSESSION_PORT;
private:
	virtual bool SetHTTPSecuirty(int);
	virtual bool CreateSession();
	virtual	bool SetServer(LPCWSTR, INTERNET_PORT);
	virtual bool SetRequest(LPCWSTR);
	virtual bool SendRequest();
	virtual bool SetResponseHandle();
	virtual bool HTTPPhraseData(std::string, std::string);

	void CloseHandles();

public:
	virtual std::wstring GetResponseHeader();
	virtual int GetHTTPStatusCode();
	virtual bool ReciveData(std::string&);
	virtual bool SetHTTPMethod(int);

	virtual bool Send(LPCWSTR, LPCWSTR);
	virtual bool Recv(int&, std::string&, std::string&);
	virtual int Transmit(int, int, std::string, std::string&, std::string, int);


	CHTTPSession()
	{
		wcUserAgent = L"MyUserAgent/1.0";
	}

	CHTTPSession(LPCWSTR lwcUserAgent)
	{
		wcUserAgent = lwcUserAgent;
	}

	~CHTTPSession()
	{
		CloseHandles();
	}

	void AddPOSTFile(std::string sData)
	{
		sPOSTFile = sData;
	}
};

enum CHTTP_PROTOCOLID
{
	HTTP_CLEAR = 10,
	HTTP_SSL
};

enum CHTTP_METHODID
{
	HTTP_GET = 10,
	HTTP_POST
};