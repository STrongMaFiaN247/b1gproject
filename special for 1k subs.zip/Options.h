#pragma once
#include "ImGUI\imgui.h"
#include <vector>

class RageTabNew
{
public:
	bool MP[6] = { false, false, false , false , false , false };
	float MPs[6] = { 0.5f, 0.5f, 0.5f , 0.5f , 0.5f , 0.5f };


	bool AutoPistol = true;
	bool AutoRevolver = true;
	bool LagComp = false;

	bool Ragebot_Knopka180 = false;

	int Ragebot_BodyKeyEnable;


	int Ragebot_Knopka180Val = 0;
	int Ragebot_Knopka180ValAA = 0;

	bool Ragebot_MoonWalk = false;
	bool Ragebot_FakeWalk = false;
	int Ragebot_FakeWalkKey = 0;

	int Ragebot_BodyAimAfterHP = 30;
	bool BodyWhenFake = true;
	bool Ragebot_BodyAwp = true;
	bool Ragebot_AimbotEnabled = false;
	int Ragebot_Selection = 0;
	int Ragebot_Hitbox = 6;
	bool Ragebot_AutoShoot = true;
	bool Ragebot_Autoscope = true;
	bool Ragebot_SilentAim = true;
	float Ragebot_Hitchance = 30.f;
	float Ragebot_MinDamage = 15.f;
	bool Ragebot_Resolver = false;
	int Ragebot_AutoWallMode = 1;
	int Ragebot_PreferBodyAim = 1;
	bool Ragebot_PositionAdjustment = true;
	bool Ragebot_CustomHitscan[6] = { true, true, true , true , true , true };


	bool AntiAim_Enabled = false;
	bool AntiAim_EnabledMove = false;
	bool AntiAim_EnabledEdge = false;

	int AntiAim_Pitch = 0;
	int AntiAim_Yaw = 0;
	int AntiAim_FakeYaw = 0;
	bool AntiAim_AtTargets = false;
	int Ragebot_AddRealYaw = 0;
	int Ragebot_AddFakeYaw = 0;


	int AntiAim_PitchMove = 0;
	int AntiAim_YawMove = 0;
	int AntiAim_FakeYawMove = 0;
	bool AntiAim_AtTargetsMove = false;
	int Ragebot_AddRealYawMove = 0;
	int Ragebot_AddFakeYawMove = 0;


	int AntiAim_PitchEdge = 0;
	int AntiAim_YawEdge = 0;
	int AntiAim_FakeYawEdge = 0;
	int Ragebot_AddRealYawEdge = 0;
	int Ragebot_AddFakeYawEdge = 0;
	float Ragebot_LBYDELTA = 90.f;
};
class VisualsTabNew
{
public:
	bool Enabled = true;
	bool Visuals_BoxEnabled = true;
	int Visuals_BoxType = 1;
	int Visuals_HealthBarType = 1;
	bool Visuals_Scoped = false;
	bool Visuals_AmmoESP = true;
	int Visuals_AmmoESPType = 1;

	bool Visuals_EspTeam = false;
	bool Visuals_VisableOnly = false;



	bool Visuals_HealthBar = true;
	bool Visuals_Name = true;
	bool Visuals_ArmorBar = false;
	bool Visuals_Flashed = false;
	bool Visuals_Defuser = false;
	bool Visuals_Weapons = false;
	int Visuals_WeaponsType = 0;
	bool Visuals_AimLines = false;
	bool Visuals_Skeltal = false;
	bool Visuals_EngineRadar = false;
	bool Visuals_DrawLinesAA = false;
	bool Visuals_DroppedWeapons = false;
	bool Visuals_NoRecoil = false;
	bool Visuals_NoFlash = false;
	bool Visuals_NoSmoke = false;
	bool Visuals_NoSmokeVar = false;
	bool Visuals_NoScope = false;
	bool Visuals_NoZoom = false;
	bool Visuals_NoPostProcess = false;


	bool Visuals_Chams = true;
	bool Visuals_ChamsTeam = false;
	bool Visuals_ChamsXQZ = false;
	int  Visuals_ChamsMaterial = 1;
	bool Visuals_GhostAngle = false;
	bool Visuals_ChamsGuns = false;
	bool Visuals_Crosshair = false;
	bool Visuals_CrosshairDynamic = false;

	bool Visuals_Hitmarker = false;
	bool Visuals_Spread = false;
	bool Visuals_GrenadePrediction = false;
	bool Visuals_DamageESP = false;
	bool Visuals_C4 = false;


	bool Vis_Glow = true;
	bool Vis_Glow_Team = false;
	bool Vis_Glow_Vis = false;


	bool Visuals_NightMode = false;
	bool Visuals_Asus = false;

	bool Visuals_DrawBeams = false;
	float Visuals_DrawBeamsDuration = 3.f;
	float Visuals_DrawBeamsSize = 3.f;

	bool Visuals_DrawCapsules = false;
	bool Visuals_DrawEventLog = false;
	float Visuals_DrawCapsulesDuration = 5.f;
	int Visuals_Spread_Type = 0;
	struct
	{
		bool Enabled = false;
		float Distance = 800.f;
		int type = 0;
		float Radius = 10.f;
		bool Animated = false;
		bool visonly = true;
	}SoundESP;
	struct
	{
		struct
		{
			bool	ExternalRadar;
			int		RadarStyle;
			float	RadarDistance;
			bool	RadarVisibleOnly;
			bool	RadarSmoke;
		}Radar;
		bool Monitor = false;
	}Panels;
 
	bool lbyIndicator = false;
	bool strelkiIndicator = false;

};


class cLegitBot
{
public:
	struct
	{
		bool 	Enabled;
		bool AutoPistol = true;
		int 	Key;
		bool	OnKey;
		bool DistanceBased = true;
		int   AimType;
		bool	BackTracking = true;
		int 	Filter; // will hold flags for team/enemy/etc.
		bool 	VisCheck;
		bool 	AlwaysOn;
		bool	FriendlyFire;
		bool	SmokeCheck;
		bool    bKillDelay;
		float		iKillDelay = 0.3f;
		float  HitChance = 30.f;
		bool	JumpCheck;
		bool    FlashCheck;
		float  FlashCheckAlpha;
		bool DrawFOV = false;
		bool FastZoom;
	} Aimbot;

	struct
	{
		bool	Enabled;
		bool	AutoFire;
		int		Key;
		bool 	HitChance;
		float	HitChanceAmt;
		bool AutoWall;
		int Delay;


		struct
		{
			bool Head;
			bool Chest;
			bool Stomach;
			bool Arms;
			bool Legs;
			bool Friendly;
			bool smoke;
		} Filter;

	} Triggerbot;

	class Weapon_t
	{
	public:
		bool Enabled = true;
		int Aimtype = 0;
		int SmoothType = 0;
		float Fov = 2;
		int Bone = 0;
		bool Nearest = true;
		bool NearestRCS = true;
		float Smooth = 8.5f;
		bool FireDelayRepeat = false;
		int FireDelay = 1;
		int StartBullet = 1;
		int EndBullet = 100;
		float RcsX = 0.f;
		float RcsY = 0.f;
		bool pSilent = true;
		//int pSilentPercentage = 73;
		int pSilentBullet = 1;
		float pSilentFov = 1.5f;
		float pSilentHitChance = 30.f;
		int PaintKit;
	}Weapon[520];
};

class cMiscTab
{
public:
	struct
	{
		bool AntiUntrusted = true;

	}AntiCheats;
	struct
	{
		int Misc_FakeLag = 0;
		bool Misc_InAirOnly = false;
		int Misc_FakeLagFactor = 7;
	}FakeLag;


	bool Misc_AutoAccept = false;
	bool Misc_KnifeBot = true;
	bool Misc_ZeusBot = true;
	bool Misc_ZStrafe = false;
	int Misc_ZStrafeKey = 0;

	bool Misc_AutoJump = true;
	bool Misc_AutoStrafe = false;
	int Misc_AutoStraferMode = 0;

	

	bool Misc_ClanTagSpammer;
	bool Misc_ClanTagAnimate;
	
	int Misc_Fov = 0;
	int ViewModelFov = 68;
	char configname[128] = "New Config";
	char confignameskins[128] = "New Config";
	char confignameColors[128] = "New Config";



	bool Visuals_ThirdPerson = false;
	int Visuals_ThirdPersonAngle = 0;
	int Visuals_ThirdPersonKey = 0;
	int Visuals_ThirdPersonDistance = 150;


	bool    SpectatorList = false;
	bool Misc_Ranks = false;
};
class cMenu
{
public:
	bool	Opened = false;
	bool    SkinChangerWindow = false;
	int 	Key;
	bool	Ragebot = false;
	bool	Legitbot = false;
	bool	Visual = false;
	bool	Misc = false;
	bool    Animations = true;
};
#define STICKERS_COUNT 5


class Sticker_t
{
public:
	int iID = 0;
	float flWear = 0.f;
	float flScale = 1.f;
	int iRotation = 0;
};
class cSkins
{
public:
	bool EnabledChanger = false;
	int WeaponID;
	int knifemodel = 3;
	int glovemodel = 2;
	int gloveskin = 1;
	struct
	{
		int PaintKit = 0;
		int Seed = 0;
		bool Stattrak = false;
		int StattrakValue = 1337;
		float Wear = 0.1f;
		bool StickersEnabled = false;
		Sticker_t Stickers[STICKERS_COUNT];
	} SkinMaster[520];
	struct
	{
		bool Enable = false;
		int Player = 0;
		char CustomPlayer[128] = "models/player/";
		int Arms = 0;
		char CustomArms[128] = "models/weapons/";
		int Knife = 0;
		char CustomKnife[128] = "models/weapons/";
		int Weapon = 0;
	} MDLModels;
};
class cPlayersList
{
public:
	bool	Playerlist;
	bool	Resolveall;
	struct
	{
		int YAngle;
		int PAngle;
		int Resolver;
		bool Baim;
	}AAA[64];

};
namespace ResolverVars
{
	extern int ResolverStage[65];
	extern int DidhitHS[65];
	extern int ResolvedpAngles[65];
}



class Variables
{
public:

	RageTabNew Ragebot;
	VisualsTabNew Visuals;
	cMiscTab Misc;
	cPlayersList Players;
	cLegitBot NewLegitbot;
	cSkins Skinchanger;

	//	cRagebot Ragebot;
	//	cPlayersList Players;
	//	cVisuals Visuals;
	//	cMisc Misc;
	//	cLegitBot Legitbot;
	//	cSkins Skins;
	cMenu Menu;

	int wpn;

	Variables()
	{
		wpn = -1;
	}

	int Bomber;
	int Hostage;
	int Defuser;
	bool Bomb;
	bool font2;
	bool shoot;
	//QAngle lastTickViewAngles = { 0,0,0 };
	bool bIsNoShot;
	int m_iBulletsFire = 0;

	float g_fMColor[4] = { 0.20f, 0.20f, 0.20f, 1.0f }; //RGBA color
	float g_fBColor[4] = { 0.1f, 0.1f, 0.1f, 1.0f };
	float g_fTColor[4] = { 1.f, 1.f, 1.f, 1.0f };


	ImFont* font;
	//CColorsTab ColorsTab;
};

namespace CPlayerList
{
	extern std::vector<int> Players;
}

extern Variables g_Options;




