#pragma once
#include "../Hacks/Misc.h"
#include "Autowall.h"
#include <iostream>     // std::cout
#include <algorithm>    // std::min

class Hitbox
{
public:


	Vector& GetCenter()
	{
		Vector Aimspot;
		return Aimspot = this->points[0];
	}
	Vector& GetCenterAll()
	{
		Vector Aimspot;
		return Aimspot = this->points[0];
	}

	Vector points[9];

	bool GetHitbox(CBaseEntity* Player, int HitboxID) {

		if (!Player)
			return false;

		matrix3x4 matrix[128];

		if (!Player->SetupBones(matrix, 128, BONE_USED_BY_HITBOX, Player->GetSimulationTime()))
			return false;


		studiohdr_t* hdr = Interfaces.g_pModelInfo->GetStudioModel(Player->GetModel());

		if (!hdr)
			return false;

		mstudiohitboxset_t* hitboxSet = hdr->GetHitboxSet(Player->GetHitboxSet());
		if (!hitboxSet)
			return false;
		mstudiobbox_t* untransformedBox = hitboxSet->pHitbox(HitboxID);
		if (!untransformedBox)
			return false;

		Vector bbmin = untransformedBox->bbmin;
		Vector bbmax = untransformedBox->bbmax;

		if (untransformedBox->radius != -1.f) {
			bbmin -= Vector(untransformedBox->radius, untransformedBox->radius, untransformedBox->radius);
			bbmax += Vector(untransformedBox->radius, untransformedBox->radius, untransformedBox->radius);
		}
		Vector points[] = { ((bbmin + bbmax) * .5f),
			Vector(bbmin.x, bbmin.y, bbmin.z),
			Vector(bbmin.x, bbmax.y, bbmin.z),
			Vector(bbmax.x, bbmax.y, bbmin.z),
			Vector(bbmax.x, bbmin.y, bbmin.z),
			Vector(bbmax.x, bbmax.y, bbmax.z),
			Vector(bbmin.x, bbmax.y, bbmax.z),
			Vector(bbmin.x, bbmin.y, bbmax.z),
			Vector(bbmax.x, bbmin.y, bbmax.z) };


			g_Math.VectorTransform2(points[0], matrix[untransformedBox->bone], this->points[0]);
			return true;
		

		/*for (int index = 0; index < 9; index++) {
			if (index != 0)
				points[index] = ((((points[index] + points[0]) * (static_cast<float>(PointScale) / 100))
					+ points[index]) * (static_cast<float>(PointScale) / 100));

			 g_Math.VectorTransform2(points[index], matrix[untransformedBox->bone], this->points[index]);
		}

		return true;*/
	}

	bool GetHitbox2(CBaseEntity* Player, int HitboxID, matrix3x4 matrix[128]) {




		if (!Player)
			return false;

		

		studiohdr_t* hdr = Interfaces.g_pModelInfo->GetStudioModel(Player->GetModel());

		if (!hdr)
			return false;

		mstudiohitboxset_t* hitboxSet = hdr->GetHitboxSet(Player->GetHitboxSet());
		if (!hitboxSet)
			return false;
		mstudiobbox_t* untransformedBox = hitboxSet->pHitbox(HitboxID);
		if (!untransformedBox)
			return false;

		Vector bbmin = untransformedBox->bbmin;
		Vector bbmax = untransformedBox->bbmax;

		if (untransformedBox->radius != -1.f) {
			bbmin -= Vector(untransformedBox->radius, untransformedBox->radius, untransformedBox->radius);
			bbmax += Vector(untransformedBox->radius, untransformedBox->radius, untransformedBox->radius);
		}
		Vector points[] = { ((bbmin + bbmax) * .5f),
			Vector(bbmin.x, bbmin.y, bbmin.z),
			Vector(bbmin.x, bbmax.y, bbmin.z),
			Vector(bbmax.x, bbmax.y, bbmin.z),
			Vector(bbmax.x, bbmin.y, bbmin.z),
			Vector(bbmax.x, bbmax.y, bbmax.z),
			Vector(bbmin.x, bbmax.y, bbmax.z),
			Vector(bbmin.x, bbmin.y, bbmax.z),
			Vector(bbmax.x, bbmin.y, bbmax.z) };

		g_Math.VectorTransform2(points[0], matrix[untransformedBox->bone], this->points[0]);
		return true;

	
	}


	bool GetHitbox33(CBaseEntity* Player, int HitboxID)
	{
		if (!Player)
			return false;

		matrix3x4 matrix[128];
		if (!Player->SetupBones(matrix, 128, 0x00000100, GetTickCount64()))
			return false;
		const model_t* mod = Player->GetModel();
		if (!mod)
			return false;
		studiohdr_t* hdr = Interfaces.g_pModelInfo->GetStudioModel(mod);
		if (!hdr)
			return false;
		mstudiohitboxset_t* set = hdr->GetHitboxSet(0);
		if (!set)
			return false;
		mstudiobbox_t* hitbox = set->pHitbox(HitboxID);
		if (!hitbox)
			return false;

		Vector points[] = { ((hitbox->bbmin + hitbox->bbmax) * .5f),
			Vector(hitbox->bbmin.x, hitbox->bbmin.y, hitbox->bbmin.z),
			Vector(hitbox->bbmin.x, hitbox->bbmax.y, hitbox->bbmin.z),
			Vector(hitbox->bbmax.x, hitbox->bbmax.y, hitbox->bbmin.z),
			Vector(hitbox->bbmax.x, hitbox->bbmin.y, hitbox->bbmin.z),
			Vector(hitbox->bbmax.x, hitbox->bbmax.y, hitbox->bbmax.z),
			Vector(hitbox->bbmin.x, hitbox->bbmax.y, hitbox->bbmax.z),
			Vector(hitbox->bbmin.x, hitbox->bbmin.y, hitbox->bbmax.z),
			Vector(hitbox->bbmax.x, hitbox->bbmin.y, hitbox->bbmax.z) };

		for (int index = 0; index < 9; ++index)
		{
			//float multiplier = 100.f / Settings.GetSetting;
			g_Math.VectorTransform2(points[index], matrix[hitbox->bone], this->points[index]);
		}

		return true;
	}
	void FixHitbox(CBaseEntity* entity)
	{
		for (int index = 0; index <= 8; ++index)
		{
			trace_t tr;
			Ray_t ray;
			CTraceFilterEntity filter;
			filter.pHit = entity;
			ray.Init(points[index], points[0]);
			Interfaces.pTrace->TraceRay(ray, MASK_SHOT, &filter, &tr);

			points[index] = tr.endpos;
		}
	}
	float GetBestPointHead(Vector& aimspot)
	{
		int amount = /*(Settings.GetSetting( Tab_Ragebot, Ragebot_Multibox ) <= 1 ) ? 27 :*/ 9;
		if (amount < 1)
			amount = 1;
		float bestdamage = -1;
		
		float damage = Autowall::GetDamage(this->points[0]);
		if (damage > bestdamage)
		{
			aimspot = points[0];
			bestdamage = damage;
		}
		return bestdamage;
	}

	float GetBestPointHead(Vector& aimspot, bool MultiPoint)
	{
		int amount = /*(Settings.GetSetting( Tab_Ragebot, Ragebot_Multibox ) <= 1 ) ? 27 :*/ 9;
		float bestdamage = -1;
		if (MultiPoint)
		{
			for (int index = 0; index < amount; ++index)
			{
				float damage = Autowall::GetDamage(this->points[index]);
				if (damage > bestdamage)
				{
					aimspot = points[index];
					bestdamage = damage;
				}
			}
		}
		else
		{
			float damage = Autowall::GetDamage(this->points[0]);
			if (damage > bestdamage)
			{
				aimspot = points[0];
				bestdamage = damage;
			}
		}
		return bestdamage;
	}
	float GetBestPoint(Vector& aimspot, bool MultiPoint)
	{
		int amount = /*(Settings.GetSetting( Tab_Ragebot, Ragebot_Multibox ) <= 1 ) ? 27 :*/ 9;
		float bestdamage = -1;
		if (MultiPoint)
		{
			for (int index = 0; index < amount; ++index)
			{
				float damage = Autowall::GetDamage(this->points[index]);
				if (damage > bestdamage)
				{
					aimspot = points[index];
					bestdamage = damage;
				}
			}
		}
		else
		{
			aimspot = this->points[0];

			bestdamage = this->points[0] == Vector(0, 0, 0) ? -1.f : Autowall::GetDamage(this->points[0]);

		}
		return bestdamage;
	}


	float ScanCenter(Vector& Aimspot)
	{
	
			Aimspot = this->points[0];
			return this->points[0] == Vector(0, 0, 0) ? -1.f : Autowall::GetDamage(this->points[0]);
	
	}

	/*float ScanCenter(Vector& Aimspot)
	{
		float bestdamage = -1;
		Aimspot = this->points[0];
		float damage = this->points[0] == Vector(0, 0, 0) ? -1.f : Autowall::GetDamage(this->points[0]);
		if (damage > bestdamage)
		{
			Aimspot = points[0];
			bestdamage = damage;
		}
	}*/

	/*
	void FindActualHitbox(CBaseEntity* pEntity, Vector& best) {
		FireBulletData Bullet_Data = FireBulletData(Vector(best.x, best.y, best.z - 0.5));
		int bestdamage = 0;
		for (int i = -180; i < 180; i += 30) {
			Vector Angle = Vector(0, i, 0);
			g_Math.angleVectors(Angle, Bullet_Data.direction);
			if (Autowall::FireSimulatedBullet(Bullet_Data, G::LocalPlayer, Hacks.LocalWeapon()))
				if (Bullet_Data.current_damage > bestdamage) {
					bestdamage = Bullet_Data.current_damage;
					best = Bullet_Data.enter_trace.endpos;
				}
		}
	}
	*/
};
