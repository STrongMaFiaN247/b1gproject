﻿#pragma once
#include "stdafx.h"
#include <chrono>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#define M_PI       3.14159265358979323846
typedef bool(*LineGoesThroughSmokeFfn)(float, float, float, float, float, float, short);
template< class T, class Y >
T Clamp(T const &val, Y const &minVal, Y const &maxVal)
{
	if (val < minVal)
		return minVal;
	else if (val > maxVal)
		return maxVal;
	else
		return val;
}
class Misc
{
	typedef bool(__cdecl* ServerRankRevealAllFn)(float*);

public:

	static float GetFOV(Vector qAngles, Vector vecSource, Vector vecDestination, bool bDistanceBased)
	{
		auto MakeVector = [](Vector qAngles)
		{
			auto ret = Vector();
			auto pitch = float(qAngles[0] * 3.14159265358979323846 / 180.f);
			auto yaw = float(qAngles[1] * 3.14159265358979323846 / 180.f);
			auto tmp = float(cos(pitch));
			ret.x = float(-tmp * -cos(yaw));
			ret.y = float(sin(yaw)*tmp);
			ret.z = float(-sin(pitch));
			return ret;
		};

		Vector ang, aim;
		double fov;

		ang = CalcAngle(vecSource, vecDestination);
		aim = MakeVector(qAngles);
		ang = MakeVector(ang);

		auto mag_s = sqrt((aim[0] * aim[0]) + (aim[1] * aim[1]) + (aim[2] * aim[2]));
		auto mag_d = sqrt((aim[0] * aim[0]) + (aim[1] * aim[1]) + (aim[2] * aim[2]));
		auto u_dot_v = aim[0] * ang[0] + aim[1] * ang[1] + aim[2] * ang[2];

		fov = acos(u_dot_v / (mag_s*mag_d)) * (180.f / 3.14159265358979323846);

		if (bDistanceBased) {
			fov *= 1.4;
			float xDist = abs(vecSource[0] - vecDestination[0]);
			float yDist = abs(vecSource[1] - vecDestination[1]);
			float Distance = sqrt((xDist * xDist) + (yDist * yDist));

			Distance /= 650.f;

			if (Distance < 0.7f)
				Distance = 0.7f;

			if (Distance > 6.5)
				Distance = 6.5;

			fov *= Distance;
		}

		return (float)fov;
	}

	static vec_t Normalize_y(vec_t ang)
	{
		while (ang < -180.0f)
			ang += 360.0f;
		while (ang > 180.0f)
			ang -= 360.0f;
		return ang;
	}
	static void SinCos(float a, float* s, float*c)
	{
		*s = sin(a);
		*c = cos(a);
	}

	static void AngleVectors3(const Vector& qAngles, Vector& vecForward)
	{
		float sp, sy, cp, cy;
		SinCos((float)(qAngles[1] * (M_PI / 180.f)), &sy, &cy);
		SinCos((float)(qAngles[0] * (M_PI / 180.f)), &sp, &cp);

		vecForward[0] = cp*cy;
		vecForward[1] = cp*sy;
		vecForward[2] = -sp;
	}

	static Vector CalcAngle(Vector src, Vector dst)
	{
		Vector angles;
		Vector delta = src - dst;
		angles.x = (asinf(delta.z / delta.Length()) * 57.295779513082f);
		angles.y = (atanf(delta.y / delta.x) * 57.295779513082f);
		angles.z = 0.0f;
		if (delta.x >= 0.0) { angles.y += 180.0f; }

		return angles;
	}

	static void CalcAngle(Vector src, Vector dst, Vector& angles)
	{
		Vector delta = src - dst;
		double hyp = delta.Length2D();
		angles.y = atan(delta.y / delta.x) * 57.295779513082f;
		angles.x = atan(delta.z / hyp) * 57.295779513082f;
		if (delta.x >= 0.0)
			angles.y += 180.0f;
		angles.z = 0;
	}

	static float GetFov(const Vector& viewAngle, const Vector& aimAngle)
	{
		Vector ang, aim;

		g_Math.angleVectors(viewAngle, aim);
		g_Math.angleVectors(aimAngle, ang);

		return RAD2DEG(acos(aim.Dot(ang) / aim.LengthSqr()));
	}
	static bool pIsVisible(Vector& vecAbsStart, Vector& vecAbsEnd, CBaseEntity* pLocal, CBaseEntity* pBaseEnt, bool smokeCheck) throw()
	{
		trace_t tr;
		Ray_t ray;
		CTraceFilter filter;

		filter.pSkip = pLocal;

		ray.Init(vecAbsStart, vecAbsEnd);

		Interfaces.pTrace->TraceRay(ray, MASK_SHOT, &filter, &tr);

		bool visible = (tr.m_pEnt == pBaseEnt || tr.fraction >= 0.96f);

		if (visible && smokeCheck)
			visible = !LineGoesThroughSmoke(vecAbsStart, vecAbsEnd);

		return visible;
	}
	static bool LineGoesThroughSmoke(Vector pos1, Vector pos2) throw()
	{

		
		static DWORD OffsetLineGoes = (DWORD)Utils.PatternSearch("client.dll", (PBYTE)"\x55\x8B\xEC\x83\xEC\x08\x8B\x15\x00\x00\x00\x00\x0F\x57\xC0", "xxxxxxxx????xxx", NULL, NULL);
		LineGoesThroughSmokeFfn LineGoesThroughSmokeEx;
		LineGoesThroughSmokeEx = (LineGoesThroughSmokeFfn)(OffsetLineGoes);
		return LineGoesThroughSmokeEx(pos1.x, pos1.y, pos1.z, pos2.x, pos2.y, pos2.z, 1);
	}

	static void AngleVectors1313(const Vector &angles, Vector *forward)
	{
		Assert(s_bMathlibInitialized);
		Assert(forward);

		float	sp, sy, cp, cy;

		sy = sin(DEG2RAD(angles[1]));
		cy = cos(DEG2RAD(angles[1]));

		sp = sin(DEG2RAD(angles[0]));
		cp = cos(DEG2RAD(angles[0]));

		forward->x = cp*cy;
		forward->y = cp*sy;
		forward->z = -sp;
	}

	static void VectorAngles3(const Vector &vecForward, Vector &vecAngles)
	{
		Vector vecView;
		if (vecForward[1] == 0.f && vecForward[0] == 0.f)
		{
			vecView[0] = 0.f;
			vecView[1] = 0.f;
		}
		else
		{
			vecView[1] = atan2(vecForward[1], vecForward[0]) * 180.f / M_PI;

			if (vecView[1] < 0.f)
				vecView[1] += 360.f;

			vecView[2] = sqrt(vecForward[0] * vecForward[0] + vecForward[1] * vecForward[1]);

			vecView[0] = atan2(vecForward[2], vecView[2]) * 180.f / M_PI;
		}

		vecAngles[0] = -vecView[0];
		vecAngles[1] = vecView[1];
		vecAngles[2] = 0.f;
	}
	static void NormalizeVector(Vector& vec)
	{
		for (int i = 0; i < 3; ++i)
		{
			while (vec[i] > 180.f)
				vec[i] -= 360.f;

			while (vec[i] < -180.f)
				vec[i] += 360.f;
		}
		vec[2] = 0.f;
	}

	static void setName(const char* name)
	{

		auto namevar = Interfaces.g_ICVars->FindVar("name");
		*reinterpret_cast< int* >(reinterpret_cast< DWORD >(&namevar->m_fnChangeCallbacks) + 0xC) = 0;
		namevar->SetValue(name);
	}

	

	static void SetClanTag(const char* tag, const char* name)
	{
		static auto pSetClanTag = reinterpret_cast< void(__fastcall*)(const char*, const char*) >((DWORD)(Utils.FindPatternIDA("engine.dll", "53 56 57 8B DA 8B F9 FF 15")));
		pSetClanTag(tag, name);
	}

	static int TIME_TO_TICKSZ(int dt)
	{
		return (int)(0.5f + (float)(dt) / Interfaces.pGlobalVars->interval_per_tick);
	}

	static float GetNetworkLatency()
	{
		INetChannelInfo* nci = Interfaces.pEngine->GetNetChannelInfo();
		if (nci)
		{
			return nci->GetAvgLatency(FLOW_OUTGOING);
		}
		return 0.0f;
	}
	static void ChatSpam()
	{
		if (!Interfaces.pEngine->IsConnected())
			return;
		if (!Interfaces.pEngine->IsInGame())
			return;

		static float nextTime = 0.f;
		float flServerTime = G::LocalPlayer->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick;

		if (nextTime > flServerTime)
			return;

		nextTime = flServerTime + 2.5f;

		Interfaces.pEngine->ClientCmd_Unrestricted("say Spectro | [Premium Cheat] for CS:GO", 0);
	}
	
	

	static double GetNumberOfTicksChoked(CBaseEntity* pEntity)
	{
		double flSimulationTime = pEntity->GetSimulationTime();
		double flSimDiff = ((double)G::LocalPlayer->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick) - flSimulationTime;
		return TIME_TO_TICKSZ(max(0.0f, flSimDiff));
	}

	static bool Shooting()
	{
		if (!Hacks.CurrentCmd || !G::LocalPlayer->GetActiveBaseCombatWeapon()) return false;
		if (G::LocalPlayer->GetActiveBaseCombatWeapon()->IsKnife())
		{
			if (Hacks.CurrentCmd->buttons & IN_ATTACK || Hacks.CurrentCmd->buttons & IN_ATTACK2)
				return true;
		}
		else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->IsNade())
		{
			CBaseCSGrenade* csGrenade = (CBaseCSGrenade*)G::LocalPlayer->GetActiveBaseCombatWeapon();
			if (csGrenade->GetThrowTime() > 0.f)
			{
				return true;
			}
		}
		else if (Hacks.CurrentCmd->buttons & IN_ATTACK && bullettime())
		{
			if (*G::LocalPlayer->GetActiveBaseCombatWeapon()->GetItemDefinitionIndex() == weapon_revolver && g_Options.Ragebot.Ragebot_AimbotEnabled)
			{
				if (G::LocalPlayer->GetActiveBaseCombatWeapon()->GetPostponeFireReadyTime() - GetServerTime() <= 0.05f)
				{
					return true;
				}
			}
			else
				return true;
		}
		return false;
	}

	static void DrawScope(int w,int h)
	{
			if (G::LocalPlayer->GetActiveBaseCombatWeapon() && G::LocalPlayer->GetActiveBaseCombatWeapon()->isSniper() && G::LocalPlayer->m_bIsScoped() && g_Options.Visuals.Visuals_NoScope)
			{
					DrawRect((w / 2), 0, (w / 2) + 1, h, CColor(0, 0, 0, 255));
					DrawRect(0, (h / 2), w, (h / 2) + 1, CColor(0, 0, 0, 255));
			}
	}


	static Vector Normalize(Vector& angs)
	{
		while (angs.y < -180.0f)
			angs.y += 360.0f;
		while (angs.y > 180.0f)
			angs.y -= 360.0f;
		if (angs.x > 89.0f)
			angs.x = 89.0f;
		if (angs.x < -89.0f)
			angs.x = -89.0f;
		angs.z = 0;
		return angs;
	}

	static bool AimStep(Vector angSource, Vector& angDestination)
	{
		Vector angDelta = Normalize(angDestination - angSource);
		if (angDelta.Abs() > 40.f)
		{
			angDestination = Normalize(angSource + angDelta / angDelta.Abs() * 40.f);
			return false;
		}
		return true;
	}

	static float GetServerTime()
	{
		return (float)G::LocalPlayer->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick;
	}

	static bool bullettime()
	{
		if (!G::LocalPlayer->GetActiveBaseCombatWeapon())
			return false;
		float flNextPrimaryAttack = G::LocalPlayer->GetActiveBaseCombatWeapon()->NextPrimaryAttack();

		return flNextPrimaryAttack <= GetServerTime();
	}

	static void MoveFix(CUserCmd* cmd, Vector& realvec)
	{
		Vector vMove(cmd->forwardmove, cmd->sidemove, cmd->upmove);
		float flSpeed = sqrt(vMove.x * vMove.x + vMove.y * vMove.y), flYaw;
		Vector vMove2;
		g_Math.vectorAnglesVec(vMove, vMove2);
		Normalize(vMove2);
		flYaw = DEG2RAD(cmd->viewangles.y - realvec.y + vMove2.y);
		cmd->forwardmove = cos(flYaw) * flSpeed;
		cmd->sidemove = sin(flYaw) * flSpeed;
		if (90 < abs(cmd->viewangles.x) && 180 > abs(cmd->viewangles.x))
			cmd->forwardmove *= -1;
	}


	
	

	static int FovTo(Vector From, Vector To)
	{
		From -= To;
		Normalize(From);
		return (abs(From.y) + abs(From.x));
	}
#define TICK_INTERVAL1			( Interfaces.pGlobalVars->interval_per_tick )
#define TIME_TO_TICKS1( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL1 ) )
	static void CreateMove()
	{
		
	}

};
