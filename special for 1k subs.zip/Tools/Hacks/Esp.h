﻿#pragma once
#include "../../stdafx.h"
#include "../../RenderD9.h"



class Esp
{
public:
	struct SoundObject_t
	{
		SoundObject_t(Vector vecOrigin, float flTime, CBaseEntity* pEntity, float flRadius, bool isZero = true)
		{
			origin = vecOrigin;
			time = flTime;
			entity = pEntity;
			radius = flRadius;
			isZeroz = isZero;
		}
		bool isZeroz;
		Vector origin;
		float time;
		float radius;
		CBaseEntity* entity;
	};

	class CSoundESP : public Singleton<CSoundESP>
	{
	public:
		void Draw();

		void AddSound(Vector vecOrigin, float flTime, CBaseEntity* pEntity, float flRadius)
		{
			SoundObject_t pSound(vecOrigin, flTime, pEntity, flRadius);
			footsteps.push_back(pSound);
		}
		std::deque<SoundObject_t> footsteps;
	private:
		static void DrawWave(Vector loc, float radius, CColor color) {
			static float Step = M_PI * 3.0f / 40.f; Vector prev;
			for (float lat = 0; lat <= M_PI * 3.0f; lat += Step)
			{
				float sin1 = sin(lat);
				float cos1 = cos(lat);
				float sin3 = sin(0.0);
				float cos3 = cos(0.0);
				Vector point1;
				point1 = Vector(sin1 * cos3, cos1, sin1 * sin3) * radius;
				Vector point3 = loc;
				Vector Out;
				point3 += point1;
				if (render->WorldToScreen(point3, Out))
				{
					if (lat > 0.000)
						DrawLine2(prev.x, prev.y, Out.x, Out.y, color);
				}
				prev = Out;
			}
		}
	};

	static void CapsuleOverlay(CBaseEntity* pPlayer, CColor col, float duration)
	{

	
		if (!pPlayer)
			return;

		studiohdr_t* pStudioModel = Interfaces.g_pModelInfo->GetStudioModel((model_t*)pPlayer->GetModel());
		if (!pStudioModel)
			return;

		static matrix3x4 pBoneToWorldOut[128];
		if (!pPlayer->SetupBones(pBoneToWorldOut, 128, 256, 0))
			return;

		mstudiohitboxset_t* pHitboxSet = pStudioModel->GetHitboxSet(0);
		if (!pHitboxSet)
			return;
		auto VectorTransform2 = [](const Vector in1, matrix3x4_t in2, Vector& out)
		{

			out[0] = g_Math.DotProduct(in1, Vector(in2[0][0], in2[0][1], in2[0][2])) + in2[0][3];
			out[1] = g_Math.DotProduct(in1, Vector(in2[1][0], in2[1][1], in2[1][2])) + in2[1][3];
			out[2] = g_Math.DotProduct(in1, Vector(in2[2][0], in2[2][1], in2[2][2])) + in2[2][3];
		};

		for (int i = 0; i < pHitboxSet->numhitboxes; i++)
		{
			mstudiobbox_t* pHitbox = pHitboxSet->pHitbox(i);
			if (!pHitbox)
				continue;

			Vector vMin, vMax;
			g_Math.VectorTransform2(pHitbox->bbmin, pBoneToWorldOut[pHitbox->bone], vMin); //nullptr???
			g_Math.VectorTransform2(pHitbox->bbmax, pBoneToWorldOut[pHitbox->bone], vMax);

			if (pHitbox->radius > -1)
			{
				Interfaces.g_pDebugOverlay->AddCapsuleOverlay(vMin, vMax, pHitbox->radius, col.r(), col.g(), col.b(), col.a(), duration);
			}
		}
	}

	

};
