#pragma once
#include "../../stdafx.h"

#include "Misc.h"
#include "Aimbot.h"


#define KEY_DOWN(VK_NNM) ((GetAsyncKeyState(VK_NNM) & 0x8000) ? 1:0)

#define M_PI		3.14159265358979323846	// matches value in gcc v2 math.h

#define M_PI_F		((float)(M_PI))	// Shouldn't collide with anything.

#define M_PHI		1.61803398874989484820 // golden ratio
	
class AntiAim
{
public:


	Vector temp;
	bool start = false;
	bool jitter = false;
	bool flip = false;
	bool ShouldAA = true;
	int current = 0;
private:

	void AutisticYossAA(float& views)
	{
		float addvalue = rand() % 40 - 20;
		static bool left = true;
		static bool first = true;
		static int counter = 1;
		if (Hacks.CurrentCmd->buttons & IN_ATTACK)
		{
			if (first)
				left = !left;
			first = false;
			if (counter % 30 == 0)
				left = !left;
		}
		else
			first = true;
		if (counter % 64 == 0)
			left = !left;

		counter++;


		if (left)
			views -= 90 + addvalue;
		else
			views += 90 + addvalue;
	}

	
	float GetOutgoingLatency()
	{
		INetChannelInfo *nci = Interfaces.pEngine->GetNetChannelInfo();
		if (nci)
		{
			float OutgoingLatency = nci->GetAvgLatency(FLOW_OUTGOING);
			return OutgoingLatency;
		}
		else
		{
			return 0.0f;
		}
	}
	float GetIncomingLatency()
	{
		INetChannelInfo *nci = Interfaces.pEngine->GetNetChannelInfo();
		if (nci)
		{
			float IncomingLatency = nci->GetAvgLatency(FLOW_INCOMING);
			return IncomingLatency;
		}
		else
		{
			return 0.0f;
		}
	}
	float GetLatency()
	{
		INetChannelInfo *nci = Interfaces.pEngine->GetNetChannelInfo();
		if (nci)
		{
			float Latency = nci->GetAvgLatency(FLOW_OUTGOING) + nci->GetAvgLatency(FLOW_INCOMING);
			return Latency;
		}
		else
		{
			return 0.0f;
		}
	}
	bool NextLBYUpdate()
	{
		static float OldLBY;
		static int LBYBreakerTimer;

		static float LastLBYUpdateTime;
		float flServerTime = (float)(G::LocalPlayer->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick);

		if (OldLBY != G::LocalPlayer->pelvisangs())
		{
			LBYBreakerTimer++;
			OldLBY = G::LocalPlayer->pelvisangs();
			LastLBYUpdateTime = flServerTime;
		}

		if (G::LocalPlayer->GetVecVelocity().Length2D() > 0.5)
		{
			if (((LastLBYUpdateTime + 0.22f - GetOutgoingLatency()) <= flServerTime) && (G::LocalPlayer->GetFlags() & FL_ONGROUND))
			{
				LastLBYUpdateTime += 0.22f;
				return true;
			}
			return false;
		}
		else {

			if (((LastLBYUpdateTime + 1.115f - GetOutgoingLatency()) <= flServerTime))
				LastLBYUpdateTime += 1.115f;
			if (((LastLBYUpdateTime + 1.05f - GetOutgoingLatency()) <= flServerTime))
			{
				return true;
			}
			return false;
		}
	}
	void MemeWalk()
	{
		if (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
			return;

		if (Hacks.CurrentCmd->forwardmove > 0)
		{
			Hacks.CurrentCmd->buttons |= IN_BACK;
			Hacks.CurrentCmd->buttons &= ~IN_FORWARD;
		}

		if (Hacks.CurrentCmd->forwardmove < 0)
		{
			Hacks.CurrentCmd->buttons |= IN_FORWARD;
			Hacks.CurrentCmd->buttons &= ~IN_BACK;
		}

		if (Hacks.CurrentCmd->sidemove < 0)
		{
			Hacks.CurrentCmd->buttons |= IN_MOVERIGHT;
			Hacks.CurrentCmd->buttons &= ~IN_MOVELEFT;
		}

		if (Hacks.CurrentCmd->sidemove > 0)
		{
			Hacks.CurrentCmd->buttons |= IN_MOVELEFT;
			Hacks.CurrentCmd->buttons &= ~IN_MOVERIGHT;
		}
	}

	void FakeWalk()
	{
		if (GetAsyncKeyState(g_Options.Ragebot.Ragebot_FakeWalkKey) && g_Options.Ragebot.Ragebot_FakeWalkKey > 0)
		{
			
			static int iChoked = -1;
			iChoked++;

			if (iChoked < 3)
			{
				Hacks.SendPacket = false;
				Hacks.CurrentCmd->tick_count += 10;
				Hacks.CurrentCmd += 7 + Hacks.CurrentCmd->tick_count % 2 ? 0 : 1;
				Hacks.CurrentCmd->buttons |= G::LocalPlayer->GetMoveType() == IN_BACK;
				Hacks.CurrentCmd->forwardmove = Hacks.CurrentCmd->sidemove = 0.f;
			}
			else
			{
				Hacks.SendPacket = true;
				iChoked = -1;
				Interfaces.pGlobalVars->frametime *= (G::LocalPlayer->GetVecVelocity().Length2D()) / 1.f;
				Hacks.CurrentCmd->buttons |= G::LocalPlayer->GetMoveType() == IN_FORWARD;
			}
		}
	}


	
	bool CanFireNext(CBaseEntity* pEntity)
	{
		CBaseCombatWeapon* pWeapon = pEntity->GetActiveBaseCombatWeapon();
		float flServerTime = pEntity->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick;
		float flNextShot = pWeapon->NextPrimaryAttack() - flServerTime;
		return flNextShot == 1;
	}

	void AtTarget(Vector& viewangles)
	{

		if (Aimbot.Target != Vector(0, 0, 0))
		{
			Misc::CalcAngle(G::LocalPlayer->GetVecOrigin(), Aimbot.Target + G::LocalPlayer->GetVecOrigin(), viewangles);
		}
	}

	void DoAA(int style, Vector& view, bool Change)
	{

		static bool flipMeme;
		flipMeme = rand() % 2 == 1 ? false : true;
		flipMeme = !flipMeme;

		static bool sFlip = false;
		if ((Interfaces.pGlobalVars->tickcount % 100) > 1 && (Interfaces.pGlobalVars->tickcount % 100) < 50)
			sFlip = true;
		else sFlip = false;

		static bool flip;
		

		static int state = 0;
		static bool bFlip = false;

		float flCurTime = Interfaces.pGlobalVars->curtime;
		static float flTimeUpdate = 1.09f;
		static float flNextTimeUpdate = flCurTime + flTimeUpdate;
		if (flCurTime >= flNextTimeUpdate) {
			bFlip = !bFlip;
			state = 0;
		}





		
		float MyLowerBody = 0.0f;

		static bool Switch;
		if (G::LocalPlayer->pelvisangs() != MyLowerBody)
			Switch = !Switch;

	


		static int breakanimaton;
		static bool GoZero;
		if (breakanimaton >= 40)
			GoZero = true;
		if(breakanimaton <= 0)
			GoZero = false;

		if (GoZero)breakanimaton-= 5;
		else breakanimaton+= 4;


		long currentTime_ms = std::chrono::duration_cast< std::chrono::seconds >(std::chrono::system_clock::now().time_since_epoch()).count();
		static long timeStamp = currentTime_ms;

		timeStamp = currentTime_ms;

		float yaw = 0;
		int pitch = 0;
		int maxJitter;
		int random;
		float temp;
//		double factor;
		static int SpinYaw = 0;
		static float StoredAng = 0;


		//static int jitter = 0;
		static int last = 0;
		int help = {};
		int Fake = rand() % 3;
		static int Spin[2] = { 0, 0 };
		for (int& s : Spin)
			if (s > 180)
				s -= 360;
			else if (s < -180)
				s += 360;

	//	Hacks.SendPacket = true;

		// Stand Anti-Anon huehuehuehue



		if (style == 0)
		{

			int iFakeYawAdd = g_Options.Ragebot.Ragebot_AddFakeYaw;
			int iYawAdd = g_Options.Ragebot.Ragebot_AddRealYaw;
			int Pitch = g_Options.Ragebot.AntiAim_Pitch;
			int FakeYaw = g_Options.Ragebot.AntiAim_FakeYaw + 1;
			int RealYaw = g_Options.Ragebot.AntiAim_Yaw + 1;

			int CaseAA = Hacks.SendPacket ? FakeYaw : RealYaw;
			int NeedAdd = Change ? 180 : 0 + Hacks.SendPacket ? iFakeYawAdd : iYawAdd;

			switch (CaseAA)
			{
			case 0:
			case 1:
			default:
				break;
			case 2:
				yaw = 180.f; break;
			case 3: // Backwards Jitter
				yaw -= 180;
				random = rand() % 100;
				maxJitter = rand() % (85 - 70 + 1) + 70;
				temp = maxJitter - (rand() % maxJitter);
				if (random < 35 + (rand() % 15))
					yaw -= temp;
				else if (random < 85 + (rand() % 15))
					yaw += temp;
				break;
			case 4: // Sideways
				AutisticYossAA(yaw); break;
			case 5:
				if (!Hacks.SendPacket)
				{
					if (NextLBYUpdate())
						yaw += g_Options.Ragebot.Ragebot_LBYDELTA;
					else
						yaw -= 70 + breakanimaton;
				}
				else
				{
					if (NextLBYUpdate())
						yaw -= g_Options.Ragebot.Ragebot_LBYDELTA;
					else
						yaw += 70 - breakanimaton;
				}
				break;
			case 6:
			{
				if (bFlip)
					yaw = -90;
				else
					yaw = 90;
			}break;
			}

			if(CaseAA > 3)
			yaw += NeedAdd;


			switch (Pitch)
			{
			case 0:
				break;
			case 1: //down
				pitch = 88.99f;
				break;
			case 2: //up
				pitch = -88.99f;
				break;
			case 3: // Minimal
				pitch = 89;
				if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isSniper())
					pitch = 85;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isRifle() || G::LocalPlayer->GetActiveBaseCombatWeapon()->isSmgW())
					pitch = 80;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isPistol())
					pitch = 89;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isMachineW())
					pitch = 78.50;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isShotgun())
					pitch = 75.00;
				break;
			case 4:
				pitch = rand();
				break;
			case 5: // Fake Down
				pitch = -991;
				break;
			case 6: // Fake Up
				pitch = 991;
				break;
			case 7: // Fake Zero
				pitch = 1080;
				break;
			}

			MyLowerBody = G::LocalPlayer->pelvisangs();
			if (g_Options.Ragebot.AntiAim_AtTargets)
				AtTarget(view);


		}

		// Move Anti-Anon huehuehuehue
		else if (style == 1)
		{

			int iFakeYawAdd = g_Options.Ragebot.Ragebot_AddFakeYawMove;
			int iYawAdd = g_Options.Ragebot.Ragebot_AddRealYawMove;
			int Pitch = g_Options.Ragebot.AntiAim_PitchMove;
			int FakeYaw = g_Options.Ragebot.AntiAim_FakeYawMove + 1;
			int RealYaw = g_Options.Ragebot.AntiAim_YawMove + 1;

			int CaseAA = Hacks.SendPacket ? FakeYaw : RealYaw;
			int NeedAdd = Change ? 180 : 0 + Hacks.SendPacket ? iFakeYawAdd : iYawAdd;

			switch (CaseAA)
			{
			case 0:
			case 1:
			default:
				break;
			case 2:
				yaw = 180.f; break;
			case 3: // Backwards Jitter
				yaw -= 180;
				random = rand() % 100;
				maxJitter = rand() % (85 - 70 + 1) + 70;
				temp = maxJitter - (rand() % maxJitter);
				if (random < 35 + (rand() % 15))
					yaw -= temp;
				else if (random < 85 + (rand() % 15))
					yaw += temp;
				break;
			case 4: // Sideways
				AutisticYossAA(yaw); break;
			case 5:
				if (!Hacks.SendPacket)
				{
					if (NextLBYUpdate())
						yaw += g_Options.Ragebot.Ragebot_LBYDELTA;
					else
						yaw -= 70 + breakanimaton;
				}
				else
				{
					if (NextLBYUpdate())
						yaw -= g_Options.Ragebot.Ragebot_LBYDELTA;
					else
						yaw += 70 - breakanimaton;
				}
				break;
			case 6:
			{
				if (bFlip)
					yaw = -90;
				else
					yaw = 90;
			}break;

			}

			if (CaseAA > 3)
				yaw += NeedAdd;

			switch (Pitch)
			{
			case 0:
				break;
			case 1: //down
				pitch = 88.99f;
				break;
			case 2: //up
				pitch = -88.99f;
				break;
			case 3: // Minimal
				pitch = 89;
				if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isSniper())
					pitch = 85;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isRifle() || G::LocalPlayer->GetActiveBaseCombatWeapon()->isSmgW())
					pitch = 80;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isPistol())
					pitch = 89;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isMachineW())
					pitch = 78.50;
				else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isShotgun())
					pitch = 75.00;
				break;
			case 4: // Fake Down
				pitch = -991;
				break;
			case 5: // Fake Up
				pitch = 991;
				break;
			case 6: // Fake Zero
				pitch = 1080;
				break;
			case 7: // Fake Zero
				if (NextLBYUpdate())
				{
					pitch = -88.99f;
				}
				else
				{
					pitch = 88.99f;
				}
				break;
			}

			MyLowerBody = G::LocalPlayer->pelvisangs();
			if (g_Options.Ragebot.AntiAim_AtTargetsMove)
				AtTarget(view);


		}

		if(!Hacks.SendPacket)
		Hacks.strelki = yaw;

		Hacks.CurrentCmd->viewangles.y = view.y + yaw;
		Hacks.Yaw = view.y + yaw;

		Hacks.CurrentCmd->viewangles.x = pitch;
		Hacks.Pitch = pitch;
	}

	bool isEdging(CBaseEntity* pLocalBaseEntity, CUserCmd* cmd, float flWall, float flCornor, bool& bSendPacket, Vector& view)
	{
		Ray_t ray;
		trace_t tr;

		bool isEdging;

		CTraceFilter traceFilter;
		traceFilter.pSkip = pLocalBaseEntity;

		auto bRetVal = false;
		auto vecCurPos = pLocalBaseEntity->GetEyePosition();
		Vector meme = cmd->viewangles;
		Misc::NormalizeVector(meme);

		int iPitch = g_Options.Ragebot.AntiAim_PitchEdge + 1;
		int iYaw = g_Options.Ragebot.AntiAim_YawEdge + 1;
		int iFakeYaw = g_Options.Ragebot.AntiAim_FakeYawEdge + 1;
	//	int random;
		float setyaw = 0;
		float setpitch = 0;
		bool switchb = cmd->command_number % 2;

		for (float i = 0; i < 360; i += 2)
		{
			Vector vecDummy(10.f, meme.y, 0.f);
			vecDummy.y += i;

			Misc::NormalizeVector(vecDummy);

			Vector vecForward;
			Misc::AngleVectors3(vecDummy, vecForward);

			auto flLength = ((16.f + 3.f) + ((16.f + 3.f) * sin(DEG2RAD(10.f)))) + 7.f;
			vecForward *= flLength;

			ray.Init(vecCurPos, (vecCurPos + vecForward));
			Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter *)&traceFilter, &tr);

			if (tr.fraction != 1.0f)
			{
				Vector qAngles;
				auto vecNegate = tr.plane.normal;

				vecNegate *= -1.f;
				Misc::VectorAngles3(vecNegate, qAngles);

				vecDummy.y = qAngles.y;

				Misc::NormalizeVector(vecDummy);
				trace_t leftTrace, rightTrace;

				Vector vecLeft;
				Misc::AngleVectors3(vecDummy + Vector(0.f, 30.f, 0.f), vecLeft);

				Vector vecRight;
				Misc::AngleVectors3(vecDummy - Vector(0.f, 30.f, 0.f), vecRight);

				vecLeft *= (flLength + (flLength * sin(DEG2RAD(30.f))));
				vecRight *= (flLength + (flLength * sin(DEG2RAD(30.f))));

				ray.Init(vecCurPos, (vecCurPos + vecLeft));
				Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter*)&traceFilter, &leftTrace);

				ray.Init(vecCurPos, (vecCurPos + vecRight));
				Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter*)&traceFilter, &rightTrace);

				if ((leftTrace.fraction == 1.f) && (rightTrace.fraction != 1.f))
					vecDummy.y -= flCornor; // left
				else if ((leftTrace.fraction != 1.f) && (rightTrace.fraction == 1.f))
					vecDummy.y += flCornor; // right			
				cmd->viewangles.x = setpitch;
				cmd->viewangles.y = vecDummy.y + setyaw;
				bRetVal = true;
			}
		}
		return bRetVal;

		isEdging = true;
	}

	bool Edge(CBaseEntity* pLocalBaseEntity, CUserCmd* cmd, float flWall, float flCornor, bool& bSendPacket, Vector& view, bool Change)
	{


		static bool flipMeme;
		flipMeme = rand() % 2 == 1 ? false : true;
		flipMeme = !flipMeme;

		static bool sFlip = false;
		if ((Interfaces.pGlobalVars->tickcount % 100) > 1 && (Interfaces.pGlobalVars->tickcount % 100) < 50)
			sFlip = true;
		else sFlip = false;

		static bool flip;
		static bool flip2;


		float flip2angle = 0.f;
		float MyLowerBody = 0.0f;


		static bool Switch;
		if (G::LocalPlayer->pelvisangs() != MyLowerBody)
			Switch = !Switch;

		if (G::LocalPlayer->pelvisangs() != MyLowerBody)
			flip2 = !flip2;
		if (flip2)
			flip2angle = 180.f;
		else
			flip2angle = 0.f;

		long currentTime_ms = std::chrono::duration_cast< std::chrono::seconds >(std::chrono::system_clock::now().time_since_epoch()).count();
		static long timeStamp = currentTime_ms;

		timeStamp = currentTime_ms;

		static int SpinYaw = 0;
		static float StoredAng = 0;
		static bool fake;
		fake = !fake;

		//static int jitter = 0;
		static int last = 0;
		int help = {};
		int Fake = rand() % 3;
		static int Spin[2] = { 0, 0 };
		for (int& s : Spin)
			if (s > 180)
				s -= 360;
			else if (s < -180)
				s += 360;



		Ray_t ray;
		trace_t tr;

		CTraceFilter traceFilter;
		traceFilter.pSkip = pLocalBaseEntity;

		auto bRetVal = false;
		auto vecCurPos = pLocalBaseEntity->GetEyePosition();
		Vector meme = cmd->viewangles;
		Misc::NormalizeVector(meme);
		int iPitch = g_Options.Ragebot.AntiAim_PitchEdge + 1;
		int iYaw = g_Options.Ragebot.AntiAim_YawEdge + 1;
		int iFakeYaw = g_Options.Ragebot.AntiAim_FakeYawEdge + 1;
		int maxJitter;
		int random;
		float temp;
//		double factor;
		float setyaw = 0;
		float setpitch = 0;
		bool switchb = cmd->command_number % 2;

		int iFakeYawAdd = g_Options.Ragebot.Ragebot_AddFakeYawEdge;
		int iYawAdd = g_Options.Ragebot.Ragebot_AddRealYawEdge;
		int NeedAdd = Change ? 180 : 0 + Hacks.SendPacket ? iFakeYawAdd : iYawAdd;

		static int breakanimaton;
		static bool GoZero;
		if (breakanimaton >= 40)
			GoZero = true;
		if (breakanimaton <= 0)
			GoZero = false;

		if (GoZero)breakanimaton -= 4;
		else breakanimaton += 4;

		static int state = 0;
		static bool bFlip = false;

		float flCurTime = Interfaces.pGlobalVars->curtime;
		static float flTimeUpdate = 1.09f;
		static float flNextTimeUpdate = flCurTime + flTimeUpdate;
		if (flCurTime >= flNextTimeUpdate) {
			bFlip = !bFlip;
			state = 0;
		}

		int CaseAA = Hacks.SendPacket ? iFakeYaw : iYaw;
		switch (CaseAA)
		{
		case 0:
		case 1:
		default:
			break;
		case 2:
			setyaw = 180.f; break;
		case 3: // Backwards Jitter
			setyaw -= 180;
			random = rand() % 100;
			maxJitter = rand() % (85 - 70 + 1) + 70;
			temp = maxJitter - (rand() % maxJitter);
			if (random < 35 + (rand() % 15))
				setyaw -= temp;
			else if (random < 85 + (rand() % 15))
				setyaw += temp;
			break;
		case 4: // Sideways
			AutisticYossAA(setyaw); break;
		case 5:
			if (!Hacks.SendPacket)
			{
				if (NextLBYUpdate())
					setyaw += g_Options.Ragebot.Ragebot_LBYDELTA;
				else
					setyaw -= 70 + breakanimaton;
			}
			else
			{
				if (NextLBYUpdate())
					setyaw -= g_Options.Ragebot.Ragebot_LBYDELTA;
				else
					setyaw += 70 - breakanimaton;
			}
			break;
		case 6:
		{
			if (bFlip)
				setyaw = -90;
			else
				setyaw = 90;
		}break;
		}
		if (CaseAA > 3)
			setyaw += NeedAdd;

		switch (iPitch)
		{
		case 0:
			break;
		case 1:
			break;
		case 2: //down
			setpitch = 88.99f;
			break;
		case 3: //up
			setpitch = -88.99f;
			break;
		case 4: // Minimal
			setpitch = 89;
			if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isSniper())
				setpitch = 85;
			else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isRifle() || G::LocalPlayer->GetActiveBaseCombatWeapon()->isSmgW())
				setpitch = 80;
			else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isPistol())
				setpitch = 89;
			else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isMachineW())
				setpitch = 78.50;
			else if (G::LocalPlayer->GetActiveBaseCombatWeapon()->isShotgun())
				setpitch = 75.00;
			break;
		case 5:
			setpitch = rand();
			break;
		case 6: // Fake Down
			setpitch = -991;
			break;
		case 7: // Fake Up
			setpitch = 991;
			break;
		case 8: // Fake Zero
			setpitch = 1080;
			break;
		}

		Hacks.CurrentCmd->viewangles.y = view.y + setyaw;

		Hacks.Yaw = view.y + setyaw;
		Hacks.Pitch = setpitch;
		Hacks.CurrentCmd->viewangles.x = setpitch;

		for (float i = 0; i < 360; i += 2)
		{
			Vector vecDummy(10.f, meme.y, 0.f);
			vecDummy.y += i;

			Misc::Normalize(vecDummy);

			Vector vecForward;
			Misc::AngleVectors3(vecDummy, vecForward);

			auto flLength = ((16.f + 3.f) + ((16.f + 3.f) * sin(DEG2RAD(10.f)))) + 7.f;
			vecForward *= flLength;

			ray.Init(vecCurPos, (vecCurPos + vecForward));
			Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter *)&traceFilter, &tr);

			if (tr.fraction != 1.0f)
			{
				Vector qAngles;
				auto vecNegate = tr.plane.normal;

				vecNegate *= -1.f;
				Misc::VectorAngles3(vecNegate, qAngles);

				vecDummy.y = qAngles.y;

				Misc::Normalize(vecDummy);
				trace_t leftTrace, rightTrace;

				Vector vecLeft;
				Misc::AngleVectors3(vecDummy + Vector(0.f, 30.f, 0.f), vecLeft);

				Vector vecRight;
				Misc::AngleVectors3(vecDummy - Vector(0.f, 30.f, 0.f), vecRight);

				vecLeft *= (flLength + (flLength * sin(DEG2RAD(30.f))));
				vecRight *= (flLength + (flLength * sin(DEG2RAD(30.f))));

				ray.Init(vecCurPos, (vecCurPos + vecLeft));
				Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter*)&traceFilter, &leftTrace);

				ray.Init(vecCurPos, (vecCurPos + vecRight));
				Interfaces.pTrace->TraceRay(ray, MASK_SHOT, (CTraceFilter*)&traceFilter, &rightTrace);

				if ((leftTrace.fraction == 1.f) && (rightTrace.fraction != 1.f))
					vecDummy.y -= flCornor; // left
				else if ((leftTrace.fraction != 1.f) && (rightTrace.fraction == 1.f))
					vecDummy.y += flCornor; // right			
				cmd->viewangles.x = setpitch;
				cmd->viewangles.y = vecDummy.y + setyaw;
				bRetVal = true;
			}
		}
		return bRetVal;
	}
	
	
public:
	void Run()
	{
		if(!G::LocalPlayer || !Hacks.CurrentCmd || !G::LocalPlayer->GetActiveBaseCombatWeapon())
			return;

		static bool Change = false;
		static bool check = false;

		
		if ((GetAsyncKeyState(g_Options.Ragebot.Ragebot_Knopka180ValAA)) && g_Options.Ragebot.Ragebot_Knopka180ValAA > 0)
		{
			if (!check)
				Change = !Change;
			check = true;
		}
		else
			check = false;

		if (g_Options.Ragebot.Ragebot_MoonWalk)
			MemeWalk();
		if (g_Options.Ragebot.Ragebot_FakeWalk)
			FakeWalk();

		if (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
			return;
		if (Hacks.CurrentCmd->buttons & IN_USE)
			return;
		int PitchEdge = g_Options.Ragebot.AntiAim_PitchEdge + 1;
		int RealEdge = g_Options.Ragebot.AntiAim_YawEdge + 1;
		int FakeEdge = g_Options.Ragebot.AntiAim_FakeYawEdge + 1;
		
		ShouldAA = true;
		Vector view = Hacks.CurrentCmd->viewangles;





		bool isMove = false;
		if (G::LocalPlayer->GetVecVelocity().Length2D() > 95 && g_Options.Ragebot.AntiAim_EnabledMove)
			isMove = true;
		else
			isMove = false;
		if (ShouldAA)
		{
			
			if (!isMove && g_Options.Ragebot.AntiAim_Enabled)
			{
				DoAA(0, view, Change);
			}
			else if (isMove)
				DoAA(1, view, Change);
			if (g_Options.Ragebot.AntiAim_EnabledEdge)
			{
				if (isEdging(G::LocalPlayer, Hacks.CurrentCmd, 0.f, 90.f, Hacks.SendPacket, view))
					if (PitchEdge >= 2 || RealEdge >= 2 || FakeEdge >= 2)
					{
						if (G::LocalPlayer->GetVecVelocity().Length2D() < 300 && (G::LocalPlayer->GetFlags() & FL_ONGROUND))
						{
							bool bEdge = Edge(G::LocalPlayer, Hacks.CurrentCmd, 0.f, 90.f, Hacks.SendPacket, view, Change);
							if (bEdge)
								return;
						}
					}
			}
			
		}
		
	}

} AA;
