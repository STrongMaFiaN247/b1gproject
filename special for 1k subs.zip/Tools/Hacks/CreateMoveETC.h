#pragma once
#include "stdafx.h"
#include "Strafer.h"
#include "Misc.h"
#include "Antiaim.h"
#include <vector>


class CreateMoveETC
{
public:

	static void BhopMovement(Vector& OrigAng)
	{
		static AutoStrafer Strafer;
		static int OldMouseX = OrigAng.y;
		int mousedx = OldMouseX - OrigAng.y;
		OldMouseX = OrigAng.y;
		static Vector LastOrigAng = Misc::Normalize(OrigAng);
	
		if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
		{
			if (Hacks.CurrentCmd->buttons & IN_JUMP)
			{
				if (!(G::LocalPlayer->GetFlags() & FL_INWATER))
					if (g_Options.Misc.Misc_AutoJump)
						Hacks.CurrentCmd->buttons &= ~IN_JUMP;
				if (g_Options.Misc.Misc_AutoStrafe)
				{
					if (G::LocalPlayer->GetVecVelocity().Length2D() == 0 && (Hacks.CurrentCmd->forwardmove == 0 && Hacks.CurrentCmd->sidemove == 0))
					{
						Hacks.CurrentCmd->forwardmove = 450.f;
					}
					else if (Hacks.CurrentCmd->forwardmove == 0 && Hacks.CurrentCmd->sidemove == 0)
					{
						if (mousedx > 0 || mousedx < -0)
						{
							if (g_Options.Misc.Misc_AutoStraferMode == 2)
							{
								Hacks.CurrentCmd->forwardmove = 450;
								Hacks.CurrentCmd->sidemove = 0;
								if (mousedx > 0)
									Hacks.CurrentCmd->viewangles.y -= 90;
								if (mousedx < 0)
									Hacks.CurrentCmd->viewangles.y += 90;
							}
							else if (g_Options.Misc.Misc_AutoStraferMode == 3)
							{
								Hacks.CurrentCmd->sidemove = mousedx < 0.f ? -450.f : 450.f;
								Hacks.CurrentCmd->forwardmove = Hacks.CurrentCmd->sidemove;
								Hacks.CurrentCmd->sidemove = 0;
								Hacks.CurrentCmd->viewangles.y -= 90;
							}
							else
								Hacks.CurrentCmd->sidemove = mousedx < 0.f ? -450.f : 450.f;
						}
						else
						{
							auto airaccel = Interfaces.g_ICVars->FindVar("sv_airaccelerate");
							auto maxspeed = Interfaces.g_ICVars->FindVar("sv_maxspeed");
							static int zhop = 0;
							double yawrad = Misc::Normalize_y(OrigAng.y) * PI / 180;
							float speed = maxspeed->GetFloat();
							if (Hacks.CurrentCmd->buttons & IN_DUCK)
								speed *= 0.333f;
							double tau = Interfaces.pGlobalVars->interval_per_tick, MA = speed * airaccel->GetFloat();
							int Sdir = 0, Fdir = 0;
							Vector velocity = G::LocalPlayer->GetVecVelocity();
							double vel[3] = { velocity[0], velocity[1], velocity[2] };
							double pos[2] = { 0, 0 };
							double dir[2] = { std::cos((OrigAng[1] + 10 * zhop) * PI / 180), std::sin((OrigAng[1] + 10 * zhop) * PI / 180) };
							Strafer.strafe_line_opt(yawrad, Sdir, Fdir, vel, pos, 30.0,
								tau, MA, pos, dir);
							//Strafer.strafe_side_opt(yawrad, Sdir, Fdir, vel, 30.0, tau * MA, dir);
							OrigAng.y = Misc::Normalize_y(yawrad * 180 / PI);
							Hacks.CurrentCmd->sidemove = Sdir * 450;
							if (g_Options.Misc.Misc_AutoStraferMode != 0)
							{
								Hacks.CurrentCmd->viewangles = Misc::Normalize(OrigAng);
								if (g_Options.Misc.Misc_AutoStraferMode == 2)
								{
									Hacks.CurrentCmd->forwardmove = 450;
									Hacks.CurrentCmd->sidemove = 0;
									Hacks.CurrentCmd->viewangles.y += Sdir > 0 ? -90 : 90;
								}
								if (g_Options.Misc.Misc_AutoStraferMode == 3)
								{
									Hacks.CurrentCmd->forwardmove = Hacks.CurrentCmd->sidemove;
									Hacks.CurrentCmd->sidemove = 0;
									Hacks.CurrentCmd->viewangles.y -= 90;
								}
							}
						}
					}
				}
			}
		}
		LastOrigAng.y = Misc::Normalize_y(LastOrigAng.y);
		LastOrigAng = Misc::Normalize(OrigAng);
	}




	static void CleanUp(Vector OrigAng)
	{
		
		if (Hacks.SendPacket)
		{
			Hacks.LastAngles = Hacks.CurrentCmd->viewangles;
			Hacks.lineFakeAngle = Hacks.CurrentCmd->viewangles.y;
			Hacks.lineFakeAnglePitch = Hacks.CurrentCmd->viewangles.x;
			Hacks.lineFakeAngleZ = Hacks.CurrentCmd->viewangles.z;
		}
		if (!Hacks.SendPacket)
		{
			Hacks.LastAnglesReal = Hacks.CurrentCmd->viewangles;
			Hacks.lineRealAngle = Hacks.CurrentCmd->viewangles.y;
		}
		Hacks.lineLBY = G::LocalPlayer->pelvisangs();


		if (g_Options.Misc.AntiCheats.AntiUntrusted)
		{
			Misc::Normalize(Hacks.CurrentCmd->viewangles);
			if (Hacks.CurrentCmd->forwardmove > 450)
				Hacks.CurrentCmd->forwardmove = 450;
			if (Hacks.CurrentCmd->forwardmove < -450)
				Hacks.CurrentCmd->forwardmove = -450;
			if (Hacks.CurrentCmd->sidemove > 450)
				Hacks.CurrentCmd->sidemove = 450;
			if (Hacks.CurrentCmd->sidemove < -450)
				Hacks.CurrentCmd->sidemove = -450;
		}

		Misc::MoveFix(Hacks.CurrentCmd, OrigAng);
	}
};
