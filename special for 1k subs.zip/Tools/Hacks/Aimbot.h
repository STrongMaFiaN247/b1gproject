#pragma once
#include "../../stdafx.h"
//#include "../Utils/Hitbox.h"
#include "../../ResolverV2.h"
#include "../Utils/Autowall.h"

#define PIRAGE 3.14159265358979323846f
#define PI_FRAGE	((float)(PI)) 
#define RandomIntZ2(min, max) (rand() % (max - min + 1) + min)
class Aimbot
{
private:
	struct Target_t
	{
		Target_t(Vector aimvec, CBaseEntity* pEnt)
		{
			aimspot = aimvec;
			ent = pEnt;
		}

		Vector aimspot;
		CBaseEntity* ent;
	};
	struct ScanParameters
	{
		ScanParameters(int a, int b)
		{
			hitboxid = a;
			hitgroupid = b;
		}
		int hitboxid;
		int hitgroupid;
	};


	std::vector<Vector> GetMultiplePointsForHitbox(CBaseEntity *pBaseEntity, ScanParameters iHitbox, matrix3x4 BoneMatrix[128])
	{
		std::vector<Vector> vPoints;

		auto VectorTransform_Wrapper = [](const Vector& in1, const matrix3x4 &in2, Vector &out)
		{
			auto VectorTransform = [](const float *in1, const matrix3x4& in2, float *out)
			{
				auto DotProducts = [](const float *v1, const float *v2)
				{
					return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
				};
				out[0] = DotProducts(in1, in2[0]) + in2[0][3];
				out[1] = DotProducts(in1, in2[1]) + in2[1][3];
				out[2] = DotProducts(in1, in2[2]) + in2[2][3];
			};
			VectorTransform(&in1.x, in2, &out.x);
		};

		auto VectorTransformForHitbox = [](const Vector& in1, const matrix3x4& in2, Vector& out) {
			out.x = in1.x * in2[0][0] + in1.y * in2[0][1] + in1.z * in2[0][2] + in2[0][3];
			out.y = in1.x * in2[1][0] + in1.y * in2[1][1] + in1.z * in2[1][2] + in2[1][3];
			out.z = in1.x * in2[2][0] + in1.y * in2[2][1] + in1.z * in2[2][2] + in2[2][3];
		};

		if (!pBaseEntity)
			return vPoints;


		studiohdr_t* pStudioModel = Interfaces.g_pModelInfo->GetStudioModel(pBaseEntity->GetModel());
		mstudiohitboxset_t* set = pStudioModel->GetHitboxSet(0);

		if (!set)
			return vPoints;

		mstudiobbox_t* untransformedBox = set->pHitbox(iHitbox.hitboxid);
		if (!untransformedBox)
			return vPoints;

		Vector vecMin = { 0, 0, 0 };
		VectorTransform_Wrapper(untransformedBox->bbmin, BoneMatrix[untransformedBox->bone], vecMin);

		Vector vecMax = { 0, 0, 0 };
		VectorTransform_Wrapper(untransformedBox->bbmax, BoneMatrix[untransformedBox->bone], vecMax);

		float mod = untransformedBox->radius != -1.f ? untransformedBox->radius : 0.f;
		Vector max;
		Vector min;
		VectorTransformForHitbox(untransformedBox->bbmax + mod, BoneMatrix[untransformedBox->bone], max);
		VectorTransformForHitbox(untransformedBox->bbmin - mod, BoneMatrix[untransformedBox->bone], min);
		auto center = (min + max) * 0.5f;
		Vector curAngles = Misc::CalcAngle(center, G::LocalPlayer->GetEyePosition());
		Vector forward;
		
		g_Math.angleVectors(curAngles, forward);
		Vector right = forward.Cross(Vector(0, 0, 1));
		Vector left = Vector(-right.x, -right.y, right.z);
		Vector top = Vector(0, 0, 1);
		//Vector bot = Vector(0, 0, -1);


		//	Vector v1 = Vector(right.x / 2, right.y, 0.6);
		//	Vector v2 = Vector(right.x, right.y / 2, 0.6);
		//	Vector v3 = Vector(right.x / 2, right.y / 2, 0.6);
		//	Vector v4 = Vector(-right.x / 2, -right.y / 2, 0.6);

		float ps = g_Options.Ragebot.MPs[iHitbox.hitgroupid];
		if (g_Options.Ragebot.MP[iHitbox.hitgroupid])
		{
			switch (iHitbox.hitgroupid)
			{
			case 0:
				for (auto i = 0; i < 4/*4*/; ++i)
					vPoints.emplace_back(center);

				vPoints.at(1) += top * (untransformedBox->radius *  g_Options.Ragebot.MPs[iHitbox.hitgroupid]);
				vPoints.at(2) += right * (untransformedBox->radius *  g_Options.Ragebot.MPs[iHitbox.hitgroupid]);
				vPoints.at(3) += left * (untransformedBox->radius *  g_Options.Ragebot.MPs[iHitbox.hitgroupid]);
				break;

			default:
				for (auto i = 0; i < 2; ++i)
					vPoints.emplace_back(center);
				vPoints.at(0) += right * (untransformedBox->radius *  g_Options.Ragebot.MPs[iHitbox.hitgroupid]);
				vPoints.at(1) += left * (untransformedBox->radius *  g_Options.Ragebot.MPs[iHitbox.hitgroupid]);
				break;
			}
		}
		else
			vPoints.emplace_back(center);

		return vPoints;
	}

	void GetTargets(std::vector< CBaseEntity* >& possibletargets)
	{
		for (int i = 1; i < 65; i++)
		{
				
				auto pEntity = Interfaces.pEntList->GetClientEntity(i);

				if (!pEntity)
					continue;
				if (pEntity == G::LocalPlayer)
					continue;
				if (!pEntity->isAlive())
					continue;
				if (pEntity->GetTeam() == G::LocalPlayer->GetTeam())
					continue;
				if (pEntity->IsDormant())
					continue;
				if (pEntity->HasGunGameImmunity())
					continue;

				possibletargets.emplace_back(pEntity);
		}
	}

	void GetAimSpots(std::vector< Vector >& Targets, std::vector< Target_t >& possibleaimspots, std::vector< CBaseEntity* >& possibletargets,CBaseCombatWeapon* pWeapon)
	{
		
		if (possibletargets.size())
		{
			for (auto pEntity : possibletargets)
			{
				
				Targets.emplace_back(pEntity->GetVecOrigin() - G::LocalPlayer->GetVecOrigin());

				std::vector< ScanParameters > iArray;

				iArray.clear();		
				bool ShouldBaim;
				if ((pEntity->GetHealth() <= g_Options.Ragebot.Ragebot_BodyAimAfterHP) || (pWeapon->isAWP() && g_Options.Ragebot.Ragebot_BodyAwp)
					|| (g_Options.Ragebot.Ragebot_BodyKeyEnable > 0 && (GetAsyncKeyState(g_Options.Ragebot.Ragebot_BodyKeyEnable))) || (Hacks.FakingLBY[pEntity->GetIndex()] && g_Options.Ragebot.BodyWhenFake))
					ShouldBaim = true;
				else
					ShouldBaim = false;

				if ((g_Options.Ragebot.Ragebot_PreferBodyAim == 1 && ShouldBaim) || g_Options.Ragebot.Ragebot_PreferBodyAim == 2)
				{
					iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_PELVIS, 2));
					iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_BELLY,3));
					iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_THORAX,3));
					iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LOWER_CHEST,3));
					iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_UPPER_CHEST,3));
				}
				else
				{
					switch (g_Options.Ragebot.Ragebot_Hitbox)
					{
					case 0:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_HEAD,0));
						break;
					case 1:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_NECK,1));
						break;
					case 2:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_BELLY,3));
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_THORAX,3));
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LOWER_CHEST,3));
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_UPPER_CHEST,3));
						break;
					case 3:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_PELVIS, 2));
						break;
					case 4:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_HAND,4));
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_HAND,4));
						break;
					case 5:
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_FOOT,5));
						iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_FOOT, 5));
						break;
					case 6:
						if (g_Options.Ragebot.Ragebot_CustomHitscan[0])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_HEAD, 0));
						}
						if (g_Options.Ragebot.Ragebot_CustomHitscan[1])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_NECK, 1));
						}
						if (g_Options.Ragebot.Ragebot_CustomHitscan[2])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_PELVIS, 2));
						}
						if (g_Options.Ragebot.Ragebot_CustomHitscan[3])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_BELLY, 3));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_THORAX, 3));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LOWER_CHEST, 3));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_UPPER_CHEST, 3));
						}
						if (g_Options.Ragebot.Ragebot_CustomHitscan[4])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_HAND, 4));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_HAND, 4));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_FOREARM, 4));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_FOREARM, 4));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_UPPER_ARM, 4));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_UPPER_ARM, 4));
						}
						if (g_Options.Ragebot.Ragebot_CustomHitscan[5])
						{
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_FOOT, 5));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_FOOT, 5));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_LEFT_CALF, 5));
							iArray.push_back(ScanParameters((int)CSGOHitboxID::HITBOX_RIGHT_CALF, 5));
						}
						break;
					default:break;
					}
				}

					matrix3x4 matrix[128];
					if (!pEntity->SetupBones(matrix, 128, 256, pEntity->GetSimulationTime()))
						return;
					
					ScanBoxList(pEntity, possibleaimspots, matrix, iArray);
			}
		}
	}

	bool ScanBoxList(CBaseEntity* pEntity, std::vector< Target_t > &possibleaimspots, matrix3x4 matrix[128],  std::vector< ScanParameters > iArray)
	{
		Vector BestPoint;
		float flBestDamage = 0.f;
	
	
				for (ScanParameters CurScan : iArray)
					{
						std::vector< Vector > Aimspots = GetMultiplePointsForHitbox(pEntity, CurScan, matrix);
						Vector Aimspot = Vector(0, 0, 0);
						float flDamage = 0.f;
						for (int g = 0; g < Aimspots.size(); g++)
						{
							float damage = Autowall::GetDamage(Aimspots.at(g));
							if (flDamage < damage && (damage > g_Options.Ragebot.Ragebot_MinDamage) || flDamage > pEntity->GetHealth())
							{
								Aimspot = Aimspots.at(g);
								flDamage = damage;
								if (g == 0 && CurScan.hitgroupid == 0)break;
							}
						}

				
						if (Aimspot == Vector(0, 0, 0) || flDamage == 0)
							continue;

						if ((flBestDamage < flDamage && (flDamage > g_Options.Ragebot.Ragebot_MinDamage) || flDamage > pEntity->GetHealth()))
						{
							flBestDamage = flDamage;

							if (Misc::GetNumberOfTicksChoked(pEntity) > 5 && g_Options.Ragebot.Ragebot_PositionAdjustment)
							{
								Aimspot -= pEntity->GetAbsOrigin();
								Aimspot += pEntity->GetNetworkOrigin();
							}

							BestPoint = Aimspot;


						}			
					}

		if (BestPoint != Vector(0, 0, 0) && flBestDamage)
		{
			possibleaimspots.emplace_back(Target_t(BestPoint, pEntity));
			return true;
		}
		return false;

	}

	void GetAtTargetsSpot(std::vector< Vector >& Targets)
	{
		if (!Targets.size())
			Target = Vector(0, 0, 0);
		else
		{
			Target = Vector(8128, 8128, 8128);
			for (Vector t : Targets)
			{
				if (t.Length() < Target.Length())
					Target = t;
			}
		}
	}

	float GetFov(const Vector& viewAngle, const Vector& aimAngle)
	{


		Vector delta = aimAngle - viewAngle;
		delta.Normalize();
		return sqrtf(powf(delta.x, 2.0f) + powf(delta.y, 2.0f));

	}

	bool Fire(CUserCmd* cmd, std::vector< Target_t >& possibleaimspots, Vector origAng,bool scoped)
	{
		if (!g_Options.Ragebot.Ragebot_AutoShoot && !(cmd->buttons & IN_ATTACK))
			return true;
		
		if (!Misc::bullettime())
			return true;

		float maxfov = 360.f;
	
		Vector Aimvec;
		CBaseEntity* pEntityx;

		for (Target_t Aimspot : possibleaimspots)
		{
			Vector Aimangles;
			Misc::CalcAngle(G::LocalPlayer->GetEyePosition(), Aimspot.aimspot, Aimangles);
			float curFov;

			switch (g_Options.Ragebot.Ragebot_Selection)
			{
			default:curFov = GetFov(origAng, Aimangles); break;
			case 0:curFov = GetFov(origAng, Aimangles); break;
			case 1:curFov = G::LocalPlayer->GetEyePosition().DistTo(Aimspot.aimspot); break;
			case 2:curFov = (float)Aimspot.ent->GetHealth(); break;
			}



			if (fabs(curFov) < maxfov)
			{
				maxfov = curFov;
				pEntityx = Aimspot.ent;
				Aimvec = Aimangles;
			}
		}

		if (pEntityx)
		{
			
			auto MAngs = Aimvec - *G::LocalPlayer->GetPunchAnglePtr() * 2.f;
			if (g_Options.Ragebot.Ragebot_Autoscope && scoped)
			{
				cmd->buttons |= IN_ATTACK2;
			}
			else if (HitChance(MAngs, pEntityx, g_Options.Ragebot.Ragebot_Hitchance))
			{
				if (Misc::GetNumberOfTicksChoked(pEntityx) > 5 && g_Options.Ragebot.Ragebot_PositionAdjustment)
				{
					cmd->tick_count = cmd->tick_count + Misc::GetNumberOfTicksChoked(pEntityx) + Misc::TIME_TO_TICKSZ(fabs(Interfaces.pEngine->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING)));
				}
				cmd->viewangles = MAngs;
				cmd->buttons |= IN_ATTACK;
				G::AimbotID = pEntityx->GetIndex();
				if (!g_Options.Ragebot.Ragebot_SilentAim)
					Interfaces.pEngine->SetViewAngles(cmd->viewangles);
			}
		}
		



		return false;
	}
	float RandomFloat(float min, float max)
	{
		static auto ranFloat = reinterpret_cast<float(*)(float, float)>(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat"));
		if (ranFloat)
			return ranFloat(min, max);
		else
			return 0.f;
	}
	void SinCosM(float a, float* s, float*c)
	{
		*s = sin(a);
		*c = cos(a);
	}
	void AngleVectors(const Vector &angles, Vector& forward, Vector& right, Vector& up)
	{
		float sr, sp, sy, cr, cp, cy;

		SinCosM(DEG2RAD(angles[1]), &sy, &cy);
		SinCosM(DEG2RAD(angles[0]), &sp, &cp);
		SinCosM(DEG2RAD(angles[2]), &sr, &cr);

		forward.x = (cp * cy);
		forward.y = (cp * sy);
		forward.z = (-sp);
		right.x = (-1 * sr * sp * cy + -1 * cr * -sy);
		right.y = (-1 * sr * sp * sy + -1 * cr *  cy);
		right.z = (-1 * sr * cp);
		up.x = (cr * sp * cy + -sr * -sy);
		up.y = (cr * sp * sy + -sr * cy);
		up.z = (cr * cp);
	}
	Vector CrossProduct(const Vector &a, const Vector &b)
	{
		return Vector(a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x);
	}
	void VectorAngles(const Vector& forward, Vector& up, QAngle& angles)
	{
		Vector left = CrossProduct(up, forward);
		left.NormalizeInPlace();

		float forwardDist = forward.Length2D();

		if (forwardDist > 0.001f)
		{
			angles.x = atan2f(-forward.z, forwardDist) * 180 / PI;
			angles.y = atan2f(forward.y, forward.x) * 180 / PI;

			float upZ = (left.y * forward.x) - (left.x * forward.y);
			angles.z = atan2f(left.z, upZ) * 180 / PI;
		}
		else
		{
			angles.x = atan2f(-forward.z, forwardDist) * 180 / PI;
			angles.y = atan2f(-left.x, left.y) * 180 / PI;
			angles.z = 0;
		}
	}
	void AngleVectors(const QAngle &angles, Vector& forward)
	{
		float	sp, sy, cp, cy;

		SinCosM(DEG2RAD(angles[1]), &sy, &cy);
		SinCosM(DEG2RAD(angles[0]), &sp, &cp);

		forward.x = cp * cy;
		forward.y = cp * sy;
		forward.z = -sp;
	}
	bool HitChance(Vector angles, CBaseEntity *ent, float chance)
	{
		auto weapon = G::LocalPlayer->GetActiveBaseCombatWeapon();

		if (!weapon)
			return false;

		Vector forward, right, up;
		Vector src = G::LocalPlayer->GetEyePosition();
		AngleVectors(angles, forward, right, up);

		int cHits = 0;
		int cNeededHits = static_cast<int>(150.f * (chance / 100.f));

		weapon->UpdateAccuracyPenalty();
		float weap_spread = weapon->GetSpread();
		float weap_inaccuracy = weapon->GetInaccuracy();

		for (int i = 0; i < 150; i++)
		{
			float a = this->RandomFloat(0.f, 1.f);
			float b = this->RandomFloat(0.f, 2.f * PI);
			float c = this->RandomFloat(0.f, 1.f);
			float d = this->RandomFloat(0.f, 2.f * PI);

			float inaccuracy = a * weap_inaccuracy;
			float spread = c * weap_spread;

			if (*weapon->GetItemDefinitionIndex() == 64)
			{
				a = 1.f - a * a;
				a = 1.f - c * c;
			}

			Vector spreadView((cos(b) * inaccuracy) + (cos(d) * spread), (sin(b) * inaccuracy) + (sin(d) * spread), 0), direction;

			direction.x = forward.x + (spreadView.x * right.x) + (spreadView.y * up.x);
			direction.y = forward.y + (spreadView.x * right.y) + (spreadView.y * up.y);
			direction.z = forward.z + (spreadView.x * right.z) + (spreadView.y * up.z);
			direction.Normalized();

			QAngle viewAnglesSpread;
			VectorAngles(direction, up, viewAnglesSpread);
			Misc::Normalize(viewAnglesSpread);

			Vector viewForward;
			AngleVectors(viewAnglesSpread, viewForward);
			viewForward.NormalizeInPlace();

			viewForward = src + (viewForward * weapon->GetCSWpnData()->range);

			trace_t tr;
			Ray_t ray;
			


			ray.Init(src, viewForward);
			Interfaces.pTrace->ClipRayToEntity(ray, MASK_SHOT | CONTENTS_GRATE, ent, &tr);
		
			if (tr.m_pEnt == ent)
				++cHits;

			if (static_cast<int>((static_cast<float>(cHits) / 150.f) * 100.f) >= chance)
				return true;

			if ((150 - i + cHits) < cNeededHits)
				return false;
		}
		return false;
	}

	
public:
	bool IsAbleToShoot(CBaseCombatWeapon* pWeapon)
	{
		if (!G::LocalPlayer || !pWeapon)
			return false;

		auto flServerTime = (float)G::LocalPlayer->GetTickBase() * Interfaces.pGlobalVars->interval_per_tick;
		auto flNextPrimaryAttack = pWeapon->NextPrimaryAttack();

		return(!(flNextPrimaryAttack > flServerTime));
	}

	Vector Target;


	bool Aim(CUserCmd* cmd, Vector origAng, CBaseCombatWeapon* pWeap)
	{
		
		/*if (!G::LocalPlayer || !pWeap || pWeap->IsMiscWeapon()  || !G::LocalPlayer->isAlive() || !cmd || !g_Options.Ragebot.Ragebot_AimbotEnabled)
		{
			G::AimbotID = NULL;
			return false;
		}
	*/
		std::vector< Vector > Targets;
		std::vector< Target_t > possibleaimspots;
		std::vector< CBaseEntity* > possibletargets;
		GetTargets(possibletargets);
	
		
		GetAimSpots(Targets, possibleaimspots, possibletargets, pWeap);


		GetAtTargetsSpot(Targets);

		if (!possibleaimspots.size())
			return false;

		

		return !Fire(cmd, possibleaimspots, origAng, (pWeap->isSniper() && !G::LocalPlayer->m_bIsScoped()));
	}

} Aimbot;





