﻿#pragma once
#include "../../stdafx.h"
//#include "XorStr.hpp"

CColor LightGray = CColor( 170, 170, 170, 255 );
CColor Gray = CColor( 150, 150, 150, 255 );
CColor DarkGray = CColor( 25, 26, 25, 255 );
CColor MainColor = CColor( 255, 188, 88, 255 );
CColor MiddleGray = CColor( 42, 43, 42, 255 );
CColor Black = CColor( 14, 14, 14, 255 );


