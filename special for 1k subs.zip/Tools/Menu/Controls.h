#pragma once
#include "../../stdafx.h"


extern CColor LightGray;
extern CColor Gray;
extern CColor DarkGray;
extern CColor MainColor;
extern CColor MiddleGray;
extern CColor Black;

inline void DrawRect( int x1, int y1, int x2, int y2, CColor clr )
{
	Interfaces.pSurface->DrawSetColor1( clr );
	Interfaces.pSurface->DrawFilledRect( x1, y1, x2, y2 );
}

inline void DrawFade( int x1, int y1, int x2, int y2, int alpha, int alpha2, CColor clr, bool horiz = false )
{
	Interfaces.pSurface->DrawSetColor1( clr );
	Interfaces.pSurface->DrawFilledRectFade( x1, y1, x2, y2, alpha, alpha2, horiz );
}

inline void DrawString(unsigned long font, int x, int y, CColor color, uintptr_t alignment, const char* msg, ...) {
	va_list va_alist;
	char buf[1024];
	va_start(va_alist, msg);
	_vsnprintf_s(buf, sizeof(buf), msg, va_alist);
	va_end(va_alist);
	wchar_t wbuf[1024];
	MultiByteToWideChar(CP_UTF8, 0, buf, 256, wbuf, 256);

	int r = 255, g = 255, b = 255, a = 255;
	color.GetColor(r, g, b, a);

	int width, height;
	Interfaces.pSurface->GetTextSize(font, wbuf, width, height);

	if (alignment & 1)
		x -= width;
	if (alignment & 2)
		x -= width / 2;

	Interfaces.pSurface->DrawSetTextFont(font);
	Interfaces.pSurface->DrawSetTextColor(r, g, b, a);
	Interfaces.pSurface->DrawSetTextPos(x, y - height / 2);
	Interfaces.pSurface->DrawPrintText(wbuf, wcslen(wbuf));
}
inline void DrawLine( int x1, int y1, int x2, int y2, CColor clr )
{
	int width = 0;
	int height = 0;
	Interfaces.pEngine->GetScreenSize( width, height );
	if( !( x1 < width && x1 > 0 && y1 < height && y1 > 0 ) || !( x2 < width && x2 > 0 && y2 < height && y2 > 0 ) )
		return;
	Interfaces.pSurface->DrawSetColor1( clr );
	Interfaces.pSurface->DrawLine( x1, y1, x2, y2 );
}
inline void DrawLine2(int x0, int y0, int x2, int y2, CColor clr)
{
	Interfaces.pSurface->DrawSetColor(clr.r(), clr.g(), clr.b(), clr.a());
	Interfaces.pSurface->DrawLine(x0, y0, x2, y2);
}
inline void DrawOutlinedRect( int x1, int y1, int x2, int y2, CColor clr )
{
	Interfaces.pSurface->DrawSetColor1( clr );
	Interfaces.pSurface->DrawOutlinedRect( x1, y1, x2, y2 );
}

inline void DrawCircle( int x, int y, float Radius, CColor Color )
{
	int Points = Radius * 2;
	Vertex_t* Circle = new Vertex_t[Points];

	for( int i = 0; i < Points; ++i )
	{
		float Theta = 2 * PI * i / Points;
		Circle[ i ].Init( x + cosf( Theta ) * Radius, y + sinf( Theta ) * Radius );
	}

	static int Texture = NULL;

	if( !Texture )
		Texture = Interfaces.pSurface->CreateNewTextureID( true );

	unsigned char buffer[4] = { (unsigned char)Color._color[ 0 ], (unsigned char)Color._color[ 1 ], (unsigned char)Color._color[ 2 ], (unsigned char)Color._color[ 3 ] };

	Interfaces.pSurface->DrawSetTextureRGBA( Texture, buffer, 1, 1 );
	Interfaces.pSurface->DrawSetTexture( Texture );
	Interfaces.pSurface->DrawSetColor1( Color );
	Interfaces.pSurface->DrawTexturedPolygon( Points, Circle );
	//delete[]Circle;
}


inline RECT GetTextSize( DWORD font, const char* text )
{
	char Buffer[1024] = { '\0' };

	/* set up varargs*/
	va_list Args;

	va_start(Args, text);
	vsprintf_s( Buffer, text, Args );
	va_end(Args);

	size_t Size = strlen( Buffer ) + 1;
	wchar_t* WideBuffer = new wchar_t[Size];

	mbstowcs_s( nullptr, WideBuffer, Size, Buffer, Size - 1 );

	RECT rect;
	int x, y;
	Interfaces.pSurface->GetTextSize( font, WideBuffer, x, y );
	rect.left = x;
	rect.bottom = y;
	rect.right = x;
	return rect;
}

inline RECT GetTextSize1( DWORD font, const wchar_t* text )
{
	RECT rect;
	int x, y;
	Interfaces.pSurface->GetTextSize( font, text, x, y );
	rect.left = x;
	rect.bottom = y;
	rect.right = x;
	return rect;
}

inline bool IsMousePressed()
{
	return ( GetAsyncKeyState( 0x01 ) );
}

inline bool IsMousePressedRight()
{
	return ( GetAsyncKeyState( 0x02 ) );
}
inline RECT GetViewport()
{
	RECT Viewport = { 0, 0, 0, 0 };
	int w, h;
	Interfaces.pEngine->GetScreenSize(w, h);
	Viewport.right = w; Viewport.bottom = h;
	return Viewport;
}
inline bool WorldToScreen(Vector &in, Vector &out)
{
	const VMatrix& worldToScreen = Interfaces.pEngine->WorldToScreenMatrix(); //Grab the world to screen matrix from CEngineClient::WorldToScreenMatrix

	float w = worldToScreen[3][0] * in[0] + worldToScreen[3][1] * in[1] + worldToScreen[3][2] * in[2] + worldToScreen[3][3]; //Calculate the angle in compareson to the player's camera.
	out.z = 0; //Screen doesn't have a 3rd dimension.

	if (w > 0.001) //If the object is within view.
	{
		RECT ScreenSize = GetViewport();
		float fl1DBw = 1 / w; //Divide 1 by the angle.
		out.x = (ScreenSize.right / 2) + (0.5f * ((worldToScreen[0][0] * in[0] + worldToScreen[0][1] * in[1] + worldToScreen[0][2] * in[2] + worldToScreen[0][3]) * fl1DBw) * ScreenSize.right + 0.5f); //Get the X dimension and push it in to the Vector.
		out.y = (ScreenSize.bottom / 2) - (0.5f * ((worldToScreen[1][0] * in[0] + worldToScreen[1][1] * in[1] + worldToScreen[1][2] * in[2] + worldToScreen[1][3]) * fl1DBw) * ScreenSize.bottom + 0.5f); //Get the Y dimension and push it in to the Vector.
		return true;
	}

	return false;
}

