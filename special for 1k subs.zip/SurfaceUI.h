#pragma once
#include "stdafx.h"

enum InputInts
{
	Test1,
};

class UIPositions
{
public:
	int x;
	int y;

public:
	int UIUpdateX;
	int UIUpdateY;
};
class UIStyles
{
public:
	//Colors
	class Colors
	{
	public:
		CColor FrameBackGround = CColor(0, 0, 0, 0);
		CColor FrameBorder = CColor(0, 0, 0, 0);
		CColor FrameTitleBar = CColor(0, 0, 0, 0);
		CColor Text = CColor(255, 255, 255, 255);
	}Colors;
	//Sizes
	class Sizes
	{
	public:
		int FrameBorderSize = 1;
		int FrameTitleBarSize = 50;
	}Sizes;

	//Sizes
	class AddPos
	{
	public:
		int FrameTitleBarX = 0;
		int FrameTitleBarY = 0;
	}AddPos;
};
struct UIVec2
{
	int x, y;
	UIVec2() { x = y = 0; }
	UIVec2(int _x, int _y) { x = _x; y = _y; }
};

enum MenuStages
{
	StartStageOfMenu, EndStageOfMenu
};
enum FuncStages
{
	InitFunc , Render
};
class CSurfaceUI
{
public:
	void DrawUI();
private:
	void Initalize(int Stage);
	void SetupStyles();
	void BeginFrame(char* name, const UIVec2& VecUI, bool borders, bool TitleBar);
	void CheckBox(char* name, bool* Func, int x, int y);
	void Button(char* name, DWORD function, int x, int y);
	void ComboBox(char* name, int* Func, int x, int y, std::vector< char* > arr, int stage);
	void SliderInt(char* name, int* Func, double min, double max ,int x, int y);
	void InputText(char* name, int itsa, int x, int y);

private:
	void DrawMouse();
	void Update_Frame();
	bool Clicked_CurrentFrame();

	
public:

	UIPositions UIPos;
	UIStyles UIStyle;
	
	bool Dont_Click;
	bool Holding_Mouse_1;
	bool Holding_Menu;
	bool Clicked_This_Frame;
	int Menu_Drag_X;
	int Menu_Drag_Y;

}; extern CSurfaceUI* SurfaceUI;

class CSurfaceUIVars
{
public:
	bool Test1 = true;
	bool Test2 = false;
	int Test3 = 0;
	int Test4 = 0;
	char Test3131[128] = "";
	char* Test3123131;
}; extern CSurfaceUIVars* g_OptionsTest;





class CButtonUI
{
public:


	void Draw()
	{
			Interfaces.pSurface->DrawSetColor(5, 5, 5, 255);
			Interfaces.pSurface->DrawFilledRect(this->pos.x, this->pos.y, this->pos.x + 155, this->pos.y + 20);
			Interfaces.pSurface->DrawSetColor(64, 64, 64, 255);
			Interfaces.pSurface->DrawOutlinedRect(this->pos.x + 1, this->pos.y + 1, this->pos.x + 154, this->pos.y + 19);
			Interfaces.pSurface->DrawSetColor(54, 54, 54, 255);
			Interfaces.pSurface->DrawFilledRect(this->pos.x + 2, this->pos.y + 2, this->pos.x + 153, this->pos.y + 18);
			Interfaces.pSurface->DrawT(this->pos.x + 67.5, this->pos.y + 3, CColor(255, 255, 255, 255), Hacks.Font_Controls, true, Name);
	}

	void Init(int x, int y, DWORD function, char* name)
	{
		this->Function = function;
		this->Name = name;

		this->pos.x = SurfaceUI->UIPos.x + x;
		this->pos.y = SurfaceUI->UIPos.y + y;

		Draw();

		if (this->GetClicked())
		{
			DWORD disfunc = this->Function;
			__asm
			{
				CALL disfunc
			}
		}
		
	}

	bool GetClicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return false;
		}
		if (SurfaceUI->Dont_Click)
		{
			return false;
		}

		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;

		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + 20)
		{
			return true;
		}

		return false;
	}

private:
	DWORD Function;
	char* Name = "NO NAME";
	UIPositions pos;
}; extern CButtonUI* ButtonUI;
class CInputTextUI
{
private:


	char* KeyStringsSave[254] = { "Not Bound", "Left Mouse", "Right Mouse", "Control+Break", "Middle Mouse", "Mouse 4", "Mouse 5",
		nullptr, "Backspace", "TAB", nullptr, nullptr, nullptr, "ENTER", nullptr, nullptr, "SHIFT", "CTRL", "ALT", "PAUSE",
		"CAPS LOCK", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "ESC", nullptr, nullptr, nullptr, nullptr, "SPACEBAR",
		"PG UP", "PG DOWN", "END", "HOME", "Left", "Up", "Right", "Down", nullptr, "Print", nullptr, "Print Screen", "Insert",
		"Delete", nullptr, "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
		nullptr, "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X",
		"Y", "Z", "Left Windows", "Right Windows", nullptr, nullptr, nullptr, "0", "1", "2", "3", "4", "5", "6",
		"7", "8", "9", "*", "+", "_", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
		"F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", nullptr, nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, "NUM LOCK", "SCROLL LOCK", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, "LSHIFT", "RSHIFT", "LCONTROL", "RCONTROL", "LMENU", "RMENU", nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "Next Track", "Previous Track", "Stop", "Play/Pause", nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, ";", "+", ",", "-", ".", "/?", "~", nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "[{", "\\|", "}]", "'\"", nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
		nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };

	UIPositions pos;
	//char Func[1024] = "\0";

	int Setting;
	char* Name = "ERROR";
	int defaultotstup = 10;
	bool Hovering()
	{
		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;
		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + 20 + defaultotstup)
		{
			return true;
		}
		return false;
	}
	bool Hovering2()
	{
		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;
		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + 20 + defaultotstup)
		{
			return false;
		}
		return true;
	}
	bool Clicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return false;
		}
		if (SurfaceUI->Dont_Click)
		{
			return false;
		}
		if (Hovering())
		{
			return true;
		}
		return false;
	}
	bool Clicked2()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return false;
		}
		if (SurfaceUI->Dont_Click)
		{
			return false;
		}
		if (Hovering2())
		{
			return true;
		}
		return false;
	}
	
	void Draw()
	{

		

		if (!textboxactive)
		Interfaces.pSurface->DrawSetColor(5, 5, 5, 255);
		else
		Interfaces.pSurface->DrawSetColor(255, 54, 54, 255);

		Interfaces.pSurface->DrawOutlinedRect(this->pos.x, this->pos.y + defaultotstup, this->pos.x + 155, this->pos.y + 20 + defaultotstup);
		
	
		Interfaces.pSurface->DrawSetColor(80, 80, 80, 255);
		Interfaces.pSurface->DrawFilledRect(this->pos.x + 1, this->pos.y + 1 + defaultotstup, this->pos.x + 154, this->pos.y + 19 + defaultotstup);

		if (textboxactive)
		{
			for (int i = 0; i < 224; i++)
			{
				switch (i)
				{
				case VK_LSHIFT:
				case VK_RSHIFT:
				case VK_SHIFT:
				case VK_LCONTROL:
				case VK_RCONTROL:
				case VK_LEFT:
				case VK_RIGHT:
				case VK_CAPITAL:
				case VK_LBUTTON:
				case VK_RBUTTON:
				case VK_MENU:
				case VK_LMENU:
				case VK_RMENU:
				case VK_INSERT:
				case VK_SNAPSHOT:
				case VK_CONTROL:
				case VK_PAUSE:
				case VK_PRIOR:
				case VK_F1:
				case VK_F2:
				case VK_F3:
				case VK_F4:
				case VK_F5:
				case VK_F6:
				case VK_F7:
				case VK_F8:
				case VK_F9:
				case VK_F10:
				case VK_F11:
				case VK_F12:
				case VK_SCROLL:
				case VK_END:
				case VK_HOME:
				case VK_NEXT:
				case VK_TAB:
					continue; break;
				}
				if (ToggleButton(i))
				{
					HandleKeys(i);
				}
			}
			
			va_list va_alist;
			va_start(va_alist, command);
			vsprintf_s(this->Extern, command.c_str(), va_alist);
			va_end(va_alist);
		}
		Interfaces.pSurface->DrawT(this->pos.x + 5, this->pos.y + 3 + defaultotstup, CColor(SurfaceUI->UIStyle.Colors.Text), Hacks.Font_Controls, false, "%s", this->Extern);
		Interfaces.pSurface->DrawT(this->pos.x + 5, this->pos.y - 4, CColor(SurfaceUI->UIStyle.Colors.Text), Hacks.Font_Controls, false, "%s", this->Name);

	}
	bool ToggleButton(int code)
	{
		static int buttonPressedTick = 0;
		if (GetAsyncKeyState(code) && (GetTickCount64() - buttonPressedTick) > 150)
		{
			buttonPressedTick = GetTickCount64();
			return true;
		}
		return false;
	}
	std::string command;
	bool textboxactive;
	void HandleKeys(int key)
	{



		switch (key)
		{

		case VK_RETURN:
		case VK_ESCAPE:
			textboxactive = false;
			break;

		case VK_SPACE:
			command.append(" ");
			break;

		case VK_BACK:
		case VK_DELETE:
			if (command.length() > 0)
			{
				command.erase(command.length() - 1);
				break;
			}
			else
				break;

		default:
			char* KeyName = "0";
			KeyName = KeyStringsSave[key];
			//if (GetKeyNameText(key << 16, KeyName, 127))

			while (command.length() > 20)
			{
				command.erase(command.length() - 1);
			}
			if(command.length() <= 20)
				command.append(KeyName);

			if (command.length() <= 20)
			break;
		}
	}
	char Extern[1024] = "\0";
	char* Extern2 = "\0";

public:
	
	void Init(char* name, int itsa, int x, int y)
	{
		this->pos.x = SurfaceUI->UIPos.x + x;
		this->pos.y = SurfaceUI->UIPos.y + y;
		this->Name = name;

		static int memorycheck;

		switch (itsa)
		{
		case InputInts::Test1: 
			if(this->command != string(this->Extern))
			this->command = string(this->Extern);
			break;

		default:break;
		}

		
		Draw();
		if (Clicked())
		{

			SurfaceUI->Dont_Click = true;
			textboxactive = true;
		}
		if(Clicked2())
		{
			textboxactive = false;
		}

		switch (itsa)
		{
		case InputInts::Test1: g_OptionsTest->Test3123131 = this->Extern; break;

		default:break;
		}

	}
}; extern CInputTextUI* InputTextUI;
class CCheckBoxUI
{
private:
	UIPositions pos;
	bool Func;

	int Setting;
	char* Name = "ERROR";

	bool Hovering()
	{
		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;
		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 11 && Mouse.y < this->pos.y + 11)
		{
			return true;
		}
		return false;
	}

	bool Clicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return false;
		}
		if (SurfaceUI->Dont_Click)
		{
			return false;
		}
		if (Hovering())
		{
			return true;
		}
		return false;
	}

	void Draw()
	{

		Interfaces.pSurface->DrawSetColor(5, 5, 5, 255);
		Interfaces.pSurface->DrawOutlinedRect(this->pos.x, this->pos.y, this->pos.x + 12, this->pos.y + 12);
		Interfaces.pSurface->DrawSetColor(80, 80, 80, 255);
		Interfaces.pSurface->DrawFilledRect(this->pos.x + 1, this->pos.y + 1, this->pos.x + 11, this->pos.y + 11);

		if (this->Func)
		{
			Interfaces.pSurface->DrawSetColor(255, 255, 255, 255);
			Interfaces.pSurface->DrawFilledRectFade(this->pos.x + 1, this->pos.y + 1, this->pos.x + 11, this->pos.y + 11, 255, 0, false);
			Interfaces.pSurface->DrawFilledRectFade(this->pos.x + 1, this->pos.y + 1, this->pos.x + 11, this->pos.y + 11, 255, 0, true);
			Interfaces.pSurface->DrawSetColor(230, 230, 230, 255);
			Interfaces.pSurface->DrawFilledRectFade(this->pos.x + 1, this->pos.y + 1, this->pos.x + 11, this->pos.y + 11, 0, 255, false);
		}
		Interfaces.pSurface->DrawT(this->pos.x + 20, this->pos.y - 1, CColor(255, 255, 255, 255), Hacks.Font_Controls, false, this->Name);
	}
public:
	void Init(char* name, bool* Func, int x, int y)
	{
		this->pos.x = SurfaceUI->UIPos.x + x;
		this->pos.y = SurfaceUI->UIPos.y + y;
		this->Name = name;
		this->Func = *Func;
		Draw();
		if (Clicked())
		{

			SurfaceUI->Dont_Click = true;

			*Func = !(*Func);
		}
	}
}; extern CCheckBoxUI* CheckBoxUI;
class CDropBoxUI 
{
private:
	int Tab = 0;
	int Setting = 0;

	char* Name = "ERROR";
	char* Parts[256];
	int Amount = 0;

	bool Dropping = false;

	UIPositions pos;


	bool GetClicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return false;
		}
		if (SurfaceUI->Dont_Click)
		{
			return false;
		}
		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;

		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + 20)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	int GetPartClicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			return -1;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			return -1;
		}
		if (SurfaceUI->Dont_Click)
		{
			return -1;
		}

		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;

		for (int i = 1; i < this->Amount; i++)
		{
			if (Mouse.x > this->pos.x && Mouse.y > this->pos.y + (20 * (i)) && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + (20 * (i + 1)))
			{
				return i;
			}
		}
		return -1;
	}

public:


	void Draw()
	{
				Interfaces.pSurface->DrawSetColor(54, 54, 54, 255);
				Interfaces.pSurface->DrawFilledRect(this->pos.x + 1, this->pos.y + 1, this->pos.x + 154, this->pos.y + 19);
				Interfaces.pSurface->DrawSetColor(5, 5, 5, 255);
				Interfaces.pSurface->DrawOutlinedRect(this->pos.x, this->pos.y, this->pos.x + 155, this->pos.y + 20);
				Interfaces.pSurface->DrawT(this->pos.x + 1, this->pos.y - 13, CColor(255, 255, 255, 255), Hacks.Font_Controls, false, this->Name);

				if (this->Dropping)
				{
					for (int i = 1; i < this->Amount; i++)
					{
						Interfaces.pSurface->DrawSetColor(54, 54, 54, 255); //dark top color
						Interfaces.pSurface->DrawFilledRect(this->pos.x, this->pos.y + (20 * i), this->pos.x + 155, this->pos.y + (20 * i) + 20);
						Interfaces.pSurface->DrawSetColor(5, 5, 5, 255);
						Interfaces.pSurface->DrawOutlinedRect(pos.x, pos.y, pos.x + 155, pos.y + (20 * i));
						Interfaces.pSurface->DrawT(this->pos.x + 11, this->pos.y + 4 + (20 * i), CColor(255, 255, 255, 255), Hacks.Font_Controls, false, this->Parts[i]);
						//part 2
						int value = (int)Setting;
						if (value >= this->Amount)
							value = 0;
						//Interfaces.pSurface->DrawT(pos.x + 11, pos.y + 4, CColor(255, 255, 255, 255), Hacks.Font_Tahoma, false, Parts[value]);

						static int Texture = Interfaces.pSurface->CreateNewTextureID(true); //need to make a texture with procedural true
						unsigned char buffer[4] = { (unsigned char)152, (unsigned char)152, (unsigned char)152, (unsigned char)255 };//{ color.r(), color.g(), color.b(), color.a() };

						Interfaces.pSurface->DrawSetTextureRGBA(Texture, buffer, 1, 1); //Texture, char array of texture, width, height
						Interfaces.pSurface->DrawSetColor(152, 152, 152, 255); // keep this full color and opacity use the RGBA @top to set values.
						Interfaces.pSurface->DrawSetTexture(Texture); // bind texture

						Vertex_t Verts2[3];
						Verts2[0].x = pos.x + 145;
						Verts2[0].y = pos.y + 8;
						Verts2[1].x = pos.x + 150;
						Verts2[1].y = pos.y + 8;
						Verts2[2].x = pos.x + 147.5;
						Verts2[2].y = pos.y + 11;

						Interfaces.pSurface->DrawTexturedPolygon(3, Verts2);
					}
					int value = (int)Setting;
					if (value >= this->Amount)
						value = 0;
					Interfaces.pSurface->DrawT(this->pos.x + 11, this->pos.y + 4, CColor(255, 255, 255, 255), Hacks.Font_Controls, false, this->Parts[value]);
				}
				else
				{
					int value = (int)Setting;
					if (value >= this->Amount)
						value = 0;
					Interfaces.pSurface->DrawT(this->pos.x + 11, this->pos.y + 4, CColor(255, 255, 255, 255), Hacks.Font_Controls, false, this->Parts[value]);

					static int Texture = Interfaces.pSurface->CreateNewTextureID(true); //need to make a texture with procedural true
					unsigned char buffer[4] = { (unsigned char)152, (unsigned char)152, (unsigned char)152, (unsigned char)255 };//{ color.r(), color.g(), color.b(), color.a() };

					Interfaces.pSurface->DrawSetTextureRGBA(Texture, buffer, 1, 1); //Texture, char array of texture, width, height
					Interfaces.pSurface->DrawSetColor(152, 152, 152, 255); // keep this full color and opacity use the RGBA @top to set values.
					Interfaces.pSurface->DrawSetTexture(Texture); // bind texture

					Vertex_t Verts2[3];
					Verts2[0].x = pos.x + 145;
					Verts2[0].y = pos.y + 8;
					Verts2[1].x = pos.x + 150;
					Verts2[1].y = pos.y + 8;
					Verts2[2].x = pos.x + 147.5;
					Verts2[2].y = pos.y + 11;

					Interfaces.pSurface->DrawTexturedPolygon(3, Verts2);
			}
	}

	void Init(int x, int y, int* setting, char* name, int parts, std::vector< char* > arr)
	{
		Name = name;

		Amount = parts;

		for (int i = 0; i < parts; i++)
		{
			Parts[i] = arr[i];
		}


		Setting = *setting;



		pos.x = SurfaceUI->UIPos.x + x;
		pos.y = SurfaceUI->UIPos.y + y;



		
		if (this->GetClicked())
		{
			if (this->Dropping == true)
			{
				this->Dropping = false;
			}
			else
			{
				this->Dropping = true;
			}
			SurfaceUI->Dont_Click = true;
		}
		else if (this->Dropping)
		{
			int index = this->GetPartClicked();
			if (index != -1)
			{
				*setting = this->GetPartClicked();
				this->Dropping = false;
				SurfaceUI->Dont_Click = true;
			}
			else if (SurfaceUI->Clicked_This_Frame && !SurfaceUI->Holding_Mouse_1)
			{
				Dropping = false;
			}
		}

	

	
	}
}; extern CDropBoxUI* DropBoxUI;
class CSliderUI
{
private:
	int Tab = 0;
	int SubTab = 0;
	int Setting = 0;
	double Max = 100;
	double Min = 0;
	UIPositions pos;
	char* Name = "ERROR";
	//char* SValue = "0";
	bool Is_Holding;

	bool GetClicked()
	{
		if (!SurfaceUI->Clicked_This_Frame)
		{
			this->Is_Holding = false;
			return false;
		}
		if (SurfaceUI->Holding_Mouse_1)
		{
			if (!this->Is_Holding)
			{
				return false;
			}
		}
		if (SurfaceUI->Dont_Click)
			return false;

		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;

		if (Mouse.x > this->pos.x && Mouse.y > this->pos.y && Mouse.x < this->pos.x + 155 && Mouse.y < this->pos.y + 13)
		{
			this->Is_Holding = true;
			return true;
		}
		else if (this->Is_Holding)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

public:
	void Draw()
	{

		double Ratio = Setting / (this->Max - this->Min);
		double Location = Ratio * 150;
		Interfaces.pSurface->DrawSetColor(80, 80, 80, 255);
		Interfaces.pSurface->DrawFilledRect(this->pos.x + 1, this->pos.y + 6, this->pos.x + 150, this->pos.y + 12);
		Interfaces.pSurface->DrawSetColor(255, 255, 255, 255);
		Interfaces.pSurface->DrawFilledRectFade(this->pos.x + 1, this->pos.y + 6, this->pos.x + Location, this->pos.y + 12, 255, 0, false);
		Interfaces.pSurface->DrawSetColor(230, 230, 230, 255);
		Interfaces.pSurface->DrawFilledRectFade(this->pos.x + 1, this->pos.y + 6, this->pos.x + Location, this->pos.y + 12, 0, 255, false);
		Interfaces.pSurface->DrawSetColor(20, 20, 20, 255);
		Interfaces.pSurface->DrawOutlinedRect(this->pos.x, this->pos.y + 5, this->pos.x + 151, this->pos.y + 13);
		Interfaces.pSurface->DrawT(this->pos.x, this->pos.y - 10, CColor(255, 255, 255, 255), Hacks.Font_Controls, false, "%s", this->Name, (float)Setting);
		float Value1 = (float)Setting;
		char vl[128];
		sprintf(vl, "%.f", Value1);

		Interfaces.pSurface->DrawSetColor(255, 255, 255, 255);
		Interfaces.pSurface->DrawFilledRectFade(this->pos.x + Location, this->pos.y + 3, this->pos.x + Location + 5, this->pos.y + 15, 255, 0, false);
		Interfaces.pSurface->DrawSetColor(230, 230, 230, 255);
		Interfaces.pSurface->DrawFilledRectFade(this->pos.x + Location, this->pos.y + 3, this->pos.x + Location + 5, this->pos.y + 15, 0, 255, false);



		Interfaces.pSurface->DrawT(this->pos.x - 10, this->pos.y + 3, CColor(255, 255, 255, 255), Hacks.Font_Controls, true, vl);

	}

	void Init(int x, int y, double min, double max, char* name, int* setting)
	{
		Setting = *setting;
		Max = max;
		Min = min;
		Name = name;
	

		this->pos.x = SurfaceUI->UIPos.x + x;
		this->pos.y = SurfaceUI->UIPos.y + y;

		if (this->GetClicked())
		{
			SurfaceUI->Dont_Click = true;
			POINT Mouse;
			POINT mp;
			GetCursorPos(&mp);
			ScreenToClient(GetForegroundWindow(), &mp);
			Mouse.x = mp.x;
			Mouse.y = mp.y;
			// get differance
			double idifference;
			idifference = Mouse.x - this->pos.x;
			// Set Value
			double value = ((idifference / 150) * (this->Max - this->Min));
			if (value < Min)
			{
				value = Min;
			}
			else if (value > Max)
			{
				value = Max;
			}

			*setting = value;
		}
		Draw();
	}

}; extern CSliderUI* SliderUI;