#include "Config.h"
//#include "SDK.h"
#include <winerror.h>
/*#include <ShlObj_core.h>
#pragma comment(lib, "Shell32.lib")*/


std::string GetCFGNameChanger(int iWeaponID, int secondint)
{
		switch (iWeaponID)
		{
		case WEAPON_DEAGLE:
			return XorStr("Desert Eagle");
		case WEAPON_ELITE:
			return XorStr("Dual Berettas");
		case WEAPON_FIVESEVEN:
			return XorStr("Five-SeveN");
		case WEAPON_GLOCK:
			return XorStr("Glock-18");
		case WEAPON_AK47:
			return XorStr("AK-47");
		case WEAPON_AUG:
			return XorStr("AUG");
		case WEAPON_AWP:
			return XorStr("AWP");
		case WEAPON_FAMAS:
			return XorStr("FAMAS");
		case WEAPON_G3SG1:
			return XorStr("G3SG1");
		case WEAPON_GALILAR:
			return XorStr("Galil");
		case WEAPON_M249:
			return XorStr("M249");
		case WEAPON_M4A1:
			return XorStr("M4A1");
		case WEAPON_MAC10:
			return XorStr("MAC-10");
		case WEAPON_P90:
			return XorStr("P90");
		case WEAPON_UMP45:
			return XorStr("UMP-45");
		case WEAPON_XM1014:
			return XorStr("XM1014");
		case WEAPON_BIZON:
			return XorStr("PP-Bizon");
		case WEAPON_MAG7:
			return XorStr("MAG-7");
		case WEAPON_NEGEV:
			return XorStr("Negev");
		case WEAPON_SAWEDOFF:
			return XorStr("Sawed-Off");
		case WEAPON_TEC9:
			return XorStr("Tec-9");
		case WEAPON_TASER:
			return XorStr("Taser");
		case WEAPON_HKP2000:
			return XorStr("P2000");
		case WEAPON_MP7:
			return XorStr("MP7");
		case WEAPON_MP9:
			return XorStr("MP9");
		case WEAPON_NOVA:
			return XorStr("Nova");
		case WEAPON_P250:
			return XorStr("P250");
		case WEAPON_SCAR20:
			return XorStr("SCAR-20");
		case WEAPON_SG556:
			return XorStr("SG 553");
		case WEAPON_SSG08:
			return XorStr("SSG 08");
		case WEAPON_KNIFE:
			return XorStr("KnifeCT");
		case WEAPON_FLASHBANG:
			return XorStr("Flashbang");
		case WEAPON_HEGRENADE:
			return XorStr("HE Grenade");
		case WEAPON_SMOKEGRENADE:
			return XorStr("Smoke Grenade");
		case WEAPON_MOLOTOV:
			return XorStr("Molotov");
		case WEAPON_DECOY:
			return XorStr("Decoy");
		case WEAPON_INCGRENADE:
			return XorStr("Incendiary Grenade");
		case WEAPON_C4:
			return XorStr("C4");
		case WEAPON_KNIFE_T:
			return XorStr("KnifeT");
		case WEAPON_M4A1_SILENCER:
			return XorStr("M4A1-S");
		case WEAPON_USP_SILENCER:
			return XorStr("USP-S");
		case WEAPON_CZ75A:
			return XorStr("CZ75-Auto");
		case WEAPON_REVOLVER:
			return XorStr("R8 Revolver");
		case WEAPON_KNIFE_BAYONET:
			return XorStr("KNIFE_BAYONET");
		case WEAPON_KNIFE_M9_BAYONET:
			return XorStr("KNIFE_M9_BAYONET");
		case WEAPON_KNIFE_SURVIVAL_BOWIE:
			return XorStr("KNIFE_BOWIE");
		case WEAPON_KNIFE_BUTTERFLY:
			return XorStr("KNIFE_BUTTERFLY");
		case WEAPON_KNIFE_FALCHION:
			return XorStr("KNIFE_FALCHION");
		case WEAPON_KNIFE_FLIP:
			return XorStr("KNIFE_FLIP");
		case WEAPON_KNIFE_PUSH:
			return XorStr("KNIFE_PUSH");
		case WEAPON_KNIFE_TACTICAL:
			return XorStr("KNIFE_TACTICAL");
		default:
			return XorStr("none");
		}
}

void CConfig::Setup()
{

		SetupValue(g_Options.Ragebot.LagComp, false, XorStr("Ragebot"), XorStr("LagComp"));

		
		SetupValue(g_Options.Ragebot.AutoPistol, false, XorStr("Ragebot"), XorStr("AutoPistol"));
		SetupValue(g_Options.Ragebot.Ragebot_BodyKeyEnable, 0, XorStr("Ragebot"), XorStr("Ragebot_BodyKeyEnable"));
		SetupValue(g_Options.Ragebot.Ragebot_Knopka180, false, XorStr("Ragebot"), XorStr("Ragebot_Knopka180"));
		SetupValue(g_Options.Ragebot.Ragebot_Knopka180Val, 0, XorStr("Ragebot"), XorStr("Ragebot_Knopka180Val"));
		SetupValue(g_Options.Ragebot.Ragebot_Knopka180ValAA, 0, XorStr("Ragebot"), XorStr("Ragebot_Knopka180ValAA"));
		SetupValue(g_Options.Ragebot.Ragebot_MoonWalk, false, XorStr("Ragebot"), XorStr("Ragebot_MoonWalk"));
		SetupValue(g_Options.Ragebot.Ragebot_FakeWalk, false, XorStr("Ragebot"), XorStr("Ragebot_FakeWalk"));
		SetupValue(g_Options.Ragebot.Ragebot_FakeWalkKey, 0, XorStr("Ragebot"), XorStr("Ragebot_FakeWalkKey"));
		SetupValue(g_Options.Ragebot.Ragebot_BodyAimAfterHP, 30, XorStr("Ragebot"), XorStr("Ragebot_BodyAimAfterHP"));
		SetupValue(g_Options.Ragebot.BodyWhenFake, true, XorStr("Ragebot"), XorStr("BodyWhenFake"));
		SetupValue(g_Options.Ragebot.Ragebot_BodyAwp, true, XorStr("Ragebot"), XorStr("Ragebot_BodyAwp"));
		SetupValue(g_Options.Ragebot.Ragebot_AimbotEnabled, true, XorStr("Ragebot"), XorStr("Ragebot_AimbotEnabled"));
		SetupValue(g_Options.Ragebot.Ragebot_Selection, 0, XorStr("Ragebot"), XorStr("Ragebot_Selection"));
		SetupValue(g_Options.Ragebot.Ragebot_Hitbox, 6, XorStr("Ragebot"), XorStr("Ragebot_Hitbox"));
		SetupValue(g_Options.Ragebot.Ragebot_AutoShoot, true, XorStr("Ragebot"), XorStr("Ragebot_AutoShoot"));
		SetupValue(g_Options.Ragebot.Ragebot_Autoscope, true, XorStr("Ragebot"), XorStr("Ragebot_Autoscope"));
		SetupValue(g_Options.Ragebot.Ragebot_SilentAim, true, XorStr("Ragebot"), XorStr("Ragebot_SilentAim"));
		SetupValue(g_Options.Ragebot.Ragebot_Hitchance, 30.f, XorStr("Ragebot"), XorStr("Ragebot_Hitchance"));
		SetupValue(g_Options.Ragebot.Ragebot_MinDamage, 15.f, XorStr("Ragebot"), XorStr("Ragebot_MinDamage"));
		SetupValue(g_Options.Ragebot.Ragebot_Resolver, true, XorStr("Ragebot"), XorStr("Ragebot_Resolver"));
		SetupValue(g_Options.Ragebot.Ragebot_AutoWallMode, 1, XorStr("Ragebot"), XorStr("Ragebot_AutoWallMode"));
		SetupValue(g_Options.Ragebot.Ragebot_PreferBodyAim, 1, XorStr("Ragebot"), XorStr("Ragebot_PreferBodyAim"));
		SetupValue(g_Options.Ragebot.Ragebot_PositionAdjustment, true, XorStr("Ragebot"), XorStr("Ragebot_PositionAdjustment"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[0], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[0]"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[1], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[1]"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[2], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[2]"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[3], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[3]"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[4], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[4]"));
		SetupValue(g_Options.Ragebot.Ragebot_CustomHitscan[5], true, XorStr("Ragebot"), XorStr("Ragebot_CustomHitscan[5]"));
		SetupValue(g_Options.Ragebot.AntiAim_Enabled, true, XorStr("Ragebot"), XorStr("AntiAim_Enabled"));
		SetupValue(g_Options.Ragebot.AntiAim_EnabledMove, true, XorStr("Ragebot"), XorStr("AntiAim_EnabledMove"));
		SetupValue(g_Options.Ragebot.AntiAim_EnabledEdge, true, XorStr("Ragebot"), XorStr("AntiAim_EnabledEdge"));
		SetupValue(g_Options.Ragebot.AntiAim_Pitch, 0, XorStr("Ragebot"), XorStr("AntiAim_Pitch"));
		SetupValue(g_Options.Ragebot.AntiAim_Yaw, 0, XorStr("Ragebot"), XorStr("AntiAim_Yaw"));
		SetupValue(g_Options.Ragebot.AntiAim_FakeYaw, 0, XorStr("Ragebot"), XorStr("AntiAim_FakeYaw"));
		SetupValue(g_Options.Ragebot.AntiAim_AtTargets, false, XorStr("Ragebot"), XorStr("AntiAim_AtTargets"));
		SetupValue(g_Options.Ragebot.Ragebot_AddRealYaw, 0, XorStr("Ragebot"), XorStr("Ragebot_AddRealYaw"));
		SetupValue(g_Options.Ragebot.Ragebot_AddFakeYaw, 0, XorStr("Ragebot"), XorStr("Ragebot_AddFakeYaw"));


		SetupValue(g_Options.Ragebot.AntiAim_PitchMove, 0, XorStr("Ragebot"), XorStr("AntiAim_PitchMove"));
		SetupValue(g_Options.Ragebot.AntiAim_YawMove, 0, XorStr("Ragebot"), XorStr("AntiAim_YawMove"));
		SetupValue(g_Options.Ragebot.AntiAim_FakeYawMove, 0, XorStr("Ragebot"), XorStr("AntiAim_FakeYawMove"));
		SetupValue(g_Options.Ragebot.AntiAim_AtTargetsMove, false, XorStr("Ragebot"), XorStr("AntiAim_AtTargetsMove"));
		SetupValue(g_Options.Ragebot.Ragebot_AddRealYawMove, 0, XorStr("Ragebot"), XorStr("Ragebot_AddRealYawMove"));
		SetupValue(g_Options.Ragebot.Ragebot_AddFakeYawMove, 0, XorStr("Ragebot"), XorStr("Ragebot_AddFakeYawMove"));
		SetupValue(g_Options.Ragebot.AntiAim_PitchEdge, 0, XorStr("Ragebot"), XorStr("AntiAim_PitchEdge"));
		SetupValue(g_Options.Ragebot.AntiAim_YawEdge, 0, XorStr("Ragebot"), XorStr("AntiAim_YawEdge"));
		SetupValue(g_Options.Ragebot.AntiAim_FakeYawEdge, 0, XorStr("Ragebot"), XorStr("AntiAim_FakeYawEdge"));
		SetupValue(g_Options.Ragebot.Ragebot_AddRealYawEdge, 0, XorStr("Ragebot"), XorStr("Ragebot_AddRealYawEdge"));
		SetupValue(g_Options.Ragebot.Ragebot_AddFakeYawEdge, 0, XorStr("Ragebot"), XorStr("Ragebot_AddFakeYawEdge"));
		SetupValue(g_Options.Ragebot.Ragebot_LBYDELTA, 90.f, XorStr("Ragebot"), XorStr("Ragebot_LBYDELTA"));


		
		SetupValue(g_Options.Visuals.Enabled, true, XorStr("Visuals"), XorStr("Enabled"));
		SetupValue(g_Options.Visuals.Visuals_BoxEnabled, false, XorStr("Visuals"), XorStr("Visuals_BoxEnabled"));
		SetupValue(g_Options.Visuals.Visuals_BoxType, 0, XorStr("Visuals"), XorStr("Visuals_BoxType"));
		SetupValue(g_Options.Visuals.Visuals_Scoped, false, XorStr("Visuals"), XorStr("Visuals_Scoped"));
		SetupValue(g_Options.Visuals.Visuals_AmmoESP, false, XorStr("Visuals"), XorStr("Visuals_AmmoESP"));
		SetupValue(g_Options.Visuals.Visuals_AmmoESPType, 0, XorStr("Visuals"), XorStr("Visuals_AmmoESPType"));
		SetupValue(g_Options.Visuals.Visuals_EspTeam, false, XorStr("Visuals"), XorStr("Visuals_EspTeam"));
		SetupValue(g_Options.Visuals.Visuals_HealthBar, false, XorStr("Visuals"), XorStr("Visuals_HealthBar"));
		SetupValue(g_Options.Visuals.Visuals_HealthBarType, 0, XorStr("Visuals"), XorStr("Visuals_HealthBarType"));
		SetupValue(g_Options.Visuals.Visuals_Name, false, XorStr("Visuals"), XorStr("Visuals_Name"));
		SetupValue(g_Options.Visuals.Visuals_ArmorBar, false, XorStr("Visuals"), XorStr("Visuals_ArmorBar"));
		SetupValue(g_Options.Visuals.Visuals_Flashed, false, XorStr("Visuals"), XorStr("Visuals_Flashed"));
		SetupValue(g_Options.Visuals.Visuals_Defuser, false, XorStr("Visuals"), XorStr("Visuals_Defuser"));
		SetupValue(g_Options.Visuals.Visuals_Weapons, false, XorStr("Visuals"), XorStr("Visuals_Weapons"));
		SetupValue(g_Options.Visuals.Visuals_WeaponsType, 0, XorStr("Visuals"), XorStr("Visuals_WeaponsType"));


		SetupValue(g_Options.Visuals.Visuals_AimLines, false, XorStr("Visuals"), XorStr("Visuals_AimLines"));
		SetupValue(g_Options.Visuals.Visuals_Skeltal, false, XorStr("Visuals"), XorStr("Visuals_Skeltal"));
		SetupValue(g_Options.Visuals.Visuals_EngineRadar, false, XorStr("Visuals"), XorStr("Visuals_EngineRadar"));
		SetupValue(g_Options.Visuals.Visuals_DrawLinesAA, false, XorStr("Visuals"), XorStr("Visuals_DrawLinesAA"));
		SetupValue(g_Options.Visuals.Visuals_DroppedWeapons, false, XorStr("Visuals"), XorStr("Visuals_DroppedWeapons"));
		SetupValue(g_Options.Visuals.Visuals_NoRecoil, false, XorStr("Visuals"), XorStr("Visuals_NoRecoil"));
		SetupValue(g_Options.Visuals.Visuals_NoFlash, false, XorStr("Visuals"), XorStr("Visuals_NoFlash"));
		SetupValue(g_Options.Visuals.Visuals_NoSmoke, false, XorStr("Visuals"), XorStr("Visuals_NoSmoke"));
		SetupValue(g_Options.Visuals.Visuals_NoScope, false, XorStr("Visuals"), XorStr("Visuals_NoScope"));
		SetupValue(g_Options.Visuals.Visuals_NoSmokeVar, false, XorStr("Visuals"), XorStr("Visuals_NoSmokeVar"));
		SetupValue(g_Options.Visuals.Visuals_NoZoom, false, XorStr("Visuals"), XorStr("Visuals_NoZoom"));
		SetupValue(g_Options.Visuals.Visuals_NoPostProcess, false, XorStr("Visuals"), XorStr("Visuals_NoPostProcess"));
		SetupValue(g_Options.Visuals.lbyIndicator, false, XorStr("Visuals"), XorStr("lbyIndicator"));
		SetupValue(g_Options.Visuals.strelkiIndicator, false, XorStr("Visuals"), XorStr("strelkiIndicator"));

		SetupValue(g_Options.Visuals.Visuals_Chams, false, XorStr("Visuals"), XorStr("Visuals_Chams"));
		SetupValue(g_Options.Visuals.Visuals_ChamsTeam, false, XorStr("Visuals"), XorStr("Visuals_ChamsTeam"));
		SetupValue(g_Options.Visuals.Visuals_ChamsXQZ, false, XorStr("Visuals"), XorStr("Visuals_ChamsXQZ"));
		SetupValue(g_Options.Visuals.Visuals_GhostAngle, false, XorStr("Visuals"), XorStr("Visuals_GhostAngle"));
		SetupValue(g_Options.Visuals.Visuals_ChamsGuns, false, XorStr("Visuals"), XorStr("Visuals_ChamsGuns"));
		SetupValue(g_Options.Visuals.Visuals_Crosshair, false, XorStr("Visuals"), XorStr("Visuals_Crosshair"));
		SetupValue(g_Options.Visuals.Visuals_CrosshairDynamic, false, XorStr("Visuals"), XorStr("Visuals_CrosshairDynamic"));
		SetupValue(g_Options.Visuals.Visuals_Hitmarker, false, XorStr("Visuals"), XorStr("Visuals_Hitmarker"));
		SetupValue(g_Options.Visuals.Visuals_Spread, false, XorStr("Visuals"), XorStr("Visuals_Spread"));
		SetupValue(g_Options.Visuals.Visuals_Spread_Type, false, XorStr("Visuals"), XorStr("Visuals_Spread_Type"));
		SetupValue(g_Options.Visuals.Visuals_GrenadePrediction, false, XorStr("Visuals"), XorStr("Visuals_GrenadePrediction"));

		SetupValue(g_Options.Visuals.Visuals_C4, false, XorStr("Visuals"), XorStr("Visuals_C4"));
		SetupValue(g_Options.Visuals.Vis_Glow, false, XorStr("Visuals"), XorStr("Vis_Glow"));
		SetupValue(g_Options.Visuals.Vis_Glow_Team, false, XorStr("Visuals"), XorStr("Vis_Glow_Team"));
		SetupValue(g_Options.Visuals.Vis_Glow_Vis, false, XorStr("Visuals"), XorStr("Vis_Glow_Vis"));
		SetupValue(g_Options.Visuals.Visuals_NightMode, false, XorStr("Visuals"), XorStr("Visuals_NightMode"));
		SetupValue(g_Options.Visuals.Visuals_Asus, false, XorStr("Visuals"), XorStr("Visuals_Asus"));
		SetupValue(g_Options.Visuals.Visuals_DrawBeams, false, XorStr("Visuals"), XorStr("Visuals_DrawBeams"));
		SetupValue(g_Options.Visuals.Visuals_DrawBeamsDuration, 5.f, XorStr("Visuals"), XorStr("Visuals_DrawBeamsDuration"));
		SetupValue(g_Options.Visuals.Visuals_DrawBeamsSize, 3.f, XorStr("Visuals"), XorStr("Visuals_DrawBeamsSize"));
		SetupValue(g_Options.Visuals.Visuals_DrawCapsules, false, XorStr("Visuals"), XorStr("Visuals_DrawCapsules"));
		SetupValue(g_Options.Visuals.Visuals_DrawCapsulesDuration, 5.f, XorStr("Visuals"), XorStr("Visuals_DrawCapsulesDuration"));
		SetupValue(g_Options.Visuals.Visuals_DrawEventLog, false, XorStr("Visuals"), XorStr("Visuals_DrawEventLog"));

		SetupValue(g_Options.Visuals.SoundESP.Enabled, false, XorStr("Visuals.SoundESP"), XorStr("Enabled"));
		SetupValue(g_Options.Visuals.SoundESP.Distance, 800.f, XorStr("Visuals.SoundESP"), XorStr("Distance"));
		SetupValue(g_Options.Visuals.SoundESP.type, 0, XorStr("Visuals.SoundESP"), XorStr("type"));
		SetupValue(g_Options.Visuals.SoundESP.Animated, false, XorStr("Visuals.SoundESP"), XorStr("Animated"));
		SetupValue(g_Options.Visuals.SoundESP.visonly, false, XorStr("Visuals.SoundESP"), XorStr("No Visable Only"));
		SetupValue(g_Options.Visuals.SoundESP.Radius, 10.f, XorStr("Visuals.SoundESP"), XorStr("Radius"));

		SetupValue(g_Options.Visuals.Panels.Radar.ExternalRadar, false, XorStr("Visuals.Panels.Radar"), XorStr("ExternalRadar"));
		SetupValue(g_Options.Visuals.Panels.Radar.RadarStyle, 0, XorStr("Visuals.Panels.Radar"), XorStr("RadarStyle"));
		SetupValue(g_Options.Visuals.Panels.Radar.RadarDistance, 0.f, XorStr("Visuals.Panels.Radar"), XorStr("RadarDistance"));
		SetupValue(g_Options.Visuals.Panels.Radar.RadarVisibleOnly, false, XorStr("Visuals.Panels.Radar"), XorStr("RadarVisibleOnly"));
		SetupValue(g_Options.Visuals.Panels.Radar.RadarSmoke, false, XorStr("Visuals.Panels.Radar"), XorStr("RadarSmoke"));

		SetupValue(g_Options.Visuals.Visuals_DamageESP, false, XorStr("Visuals"), XorStr("Visuals_DamageESP"));

		SetupValue(g_Options.Misc.AntiCheats.AntiUntrusted, true, XorStr("Misc.AntiCheats"), XorStr("AntiUntrusted"));
		SetupValue(g_Options.Misc.FakeLag.Misc_FakeLag, 0, XorStr("Misc.FakeLag"), XorStr("Misc_FakeLag"));
		SetupValue(g_Options.Misc.FakeLag.Misc_InAirOnly, false, XorStr("Misc.FakeLag"), XorStr("Misc_InAirOnly"));
		SetupValue(g_Options.Misc.FakeLag.Misc_FakeLagFactor, 7, XorStr("Misc.FakeLag"), XorStr("Misc_FakeLagFactor"));
		SetupValue(g_Options.Misc.Misc_AutoAccept, false, XorStr("Misc"), XorStr("Misc_AutoAccept"));
		SetupValue(g_Options.Misc.Misc_KnifeBot, false, XorStr("Misc"), XorStr("Misc_KnifeBot"));
		SetupValue(g_Options.Misc.Misc_Ranks, false, XorStr("Misc"), XorStr("Misc_Ranks"));
		SetupValue(g_Options.Misc.Misc_AutoJump, true, XorStr("Misc"), XorStr("Misc_AutoJump"));
		SetupValue(g_Options.Misc.Misc_AutoStrafe, false, XorStr("Misc"), XorStr("Misc_AutoStrafe"));
		SetupValue(g_Options.Misc.Misc_AutoStraferMode, 0, XorStr("Misc"), XorStr("Misc_AutoStraferMode"));
		SetupValue(g_Options.Misc.Misc_Fov, 0, XorStr("Misc"), XorStr("Misc_Fov"));
		SetupValue(g_Options.Misc.ViewModelFov, 68, XorStr("Misc"), XorStr("ViewModelFov"));
		SetupValue(g_Options.Misc.Visuals_ThirdPerson, false, XorStr("Misc"), XorStr("Visuals_ThirdPerson"));
		SetupValue(g_Options.Misc.Visuals_ThirdPersonAngle, 0, XorStr("Misc"), XorStr("Visuals_ThirdPersonAngle"));
		SetupValue(g_Options.Misc.Visuals_ThirdPersonKey, 0, XorStr("Misc"), XorStr("Visuals_ThirdPersonKey"));
		SetupValue(g_Options.Misc.Visuals_ThirdPersonDistance, 150, XorStr("Misc"), XorStr("Visuals_ThirdPersonDistance"));

		

		SetupValue(g_Options.Misc.SpectatorList, false, XorStr("Misc"), XorStr("SpectatorList"));
		SetupValue(g_Options.Menu.Animations, false, XorStr("Menu"), XorStr("Animations"));


		SetupValue(g_Options.NewLegitbot.Triggerbot.Enabled, false, XorStr("Triggerbot"), XorStr("Enabled"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.AutoFire, false, XorStr("Triggerbot"), XorStr("AutoFire"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Key, 0, XorStr("Triggerbot"), XorStr("Key"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.HitChance, false, XorStr("Triggerbot"), XorStr("HitChance"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.HitChanceAmt, 0.f, XorStr("Triggerbot"), XorStr("HitChanceAmt"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Delay, 50, XorStr("Triggerbot"), XorStr("Delay"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Head, false, XorStr("Triggerbot.Filter"), XorStr("Head"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Chest, false, XorStr("Triggerbot.Filter"), XorStr("Chest"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Stomach, false, XorStr("Triggerbot.Filter"), XorStr("Stomach"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Arms, false, XorStr("Triggerbot.Filter"), XorStr("Arms"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Legs, false, XorStr("Triggerbot.Filter"), XorStr("Legs"));
		SetupValue(g_Options.NewLegitbot.Triggerbot.Filter.Friendly, false, XorStr("Triggerbot.Filter"), XorStr("Friendly"));


		SetupValue(g_Options.NewLegitbot.Aimbot.Enabled, false, XorStr("Legit"), XorStr("Legit.Enabled"));
		SetupValue(g_Options.NewLegitbot.Aimbot.AutoPistol, false, XorStr("Legit"), XorStr("Legit.AutoPistol"));
		SetupValue(g_Options.NewLegitbot.Aimbot.Key, 0, XorStr("Legit"), XorStr("Legit.Key"));
		SetupValue(g_Options.NewLegitbot.Aimbot.OnKey, false, XorStr("Legit"), XorStr("Legit.OnKey"));
		SetupValue(g_Options.NewLegitbot.Aimbot.DistanceBased, false, XorStr("Legit"), XorStr("Legit.DistanceBased"));
		SetupValue(g_Options.NewLegitbot.Aimbot.BackTracking, false, XorStr("Legit"), XorStr("Legit.BackTracking"));
		SetupValue(g_Options.NewLegitbot.Aimbot.FriendlyFire, false, XorStr("Legit"), XorStr("Legit.FriendlyFire"));
		SetupValue(g_Options.NewLegitbot.Aimbot.SmokeCheck, false, XorStr("Legit"), XorStr("Legit.SmokeCheck"));
		SetupValue(g_Options.NewLegitbot.Aimbot.bKillDelay, false, XorStr("Legit"), XorStr("Legit.bKillDelay"));
		SetupValue(g_Options.NewLegitbot.Aimbot.iKillDelay, 0.3f, XorStr("Legit"), XorStr("Legit.iKillDelay"));
		SetupValue(g_Options.NewLegitbot.Aimbot.JumpCheck, false, XorStr("Legit"), XorStr("Legit.JumpCheck"));
		SetupValue(g_Options.NewLegitbot.Aimbot.FlashCheck, false, XorStr("Legit"), XorStr("Legit.FlashCheck"));
		SetupValue(g_Options.NewLegitbot.Aimbot.FlashCheckAlpha, 0.0f, XorStr("Legit"), XorStr("Legit.FlashCheckAlpha"));
		SetupValue(g_Options.NewLegitbot.Aimbot.FastZoom, false, XorStr("Legit"), XorStr("Legit.FastZoom"));
		SetupValue(g_Options.NewLegitbot.Aimbot.DrawFOV, false, XorStr("Legit"), XorStr("Legit.DrawFOV"));
	

		
		for (int idNEW = 1; idNEW < 64; idNEW++)
		{
			if (idNEW == 5 || idNEW == 6 || idNEW == 12 || idNEW == 15 || idNEW == 18 || idNEW == 20 || idNEW == 21 || idNEW == 22 || idNEW == 23
				|| idNEW == 37 || idNEW == 41 || idNEW == 50 || idNEW == 51 || idNEW == 52 || idNEW == 53 || idNEW == 54 || idNEW == 55 || idNEW == 56 || idNEW == 57
				|| idNEW == 58)
				continue;
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Bone, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Bone"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Enabled, false, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Enabled"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].EndBullet, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.EndBullet"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Fov, 0.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Fov"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Nearest, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Nearest"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].pSilent, false, GetCFGNameChanger(idNEW, 0), XorStr("Legit.pSilent"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].NearestRCS, false, GetCFGNameChanger(idNEW, 0), XorStr("Legit.NearestRCS"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].pSilentFov, 0.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.pSilentFov"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].pSilentHitChance, 0.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.pSilentHitChance"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].RcsX, 1.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.RcsX"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].RcsY, 1.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.RcsY"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Smooth, 0.f, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Smooth"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].StartBullet, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.StartBullet"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].EndBullet, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.EndBullet"));
			
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].Aimtype, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.Aimtype"));
			SetupValue(g_Options.NewLegitbot.Weapon[idNEW].SmoothType, 0, GetCFGNameChanger(idNEW, 0), XorStr("Legit.SmoothType"));


		}



		
}
void CConfig::SetupValue(char &value, char def, std::string category, std::string name)
{
	value = def;
	chars.push_back(new ConfigValue<char>(category, name, &value));
}
void CConfig::SetupValue(int &value, int def, std::string category, std::string name)
{
	value = def;
	ints.push_back(new ConfigValue<int>(category, name, &value));
}

void CConfig::SetupValue(float &value, float def, std::string category, std::string name)
{
	value = def;
	floats.push_back(new ConfigValue<float>(category, name, &value));
}

void CConfig::SetupValue(bool &value, bool def, std::string category, std::string name)
{
	value = def;
	bools.push_back(new ConfigValue<bool>(category, name, &value));
}


#include <stdio.h>
void CConfig::Delete(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		if (Type == maincfg)
			sprintf(szCmd, "\\Spectro[maincfg]\\%s.ini", g_Options.Misc.configname);
		else
			sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		file = std::string(path) + szCmd;
	}

	DeleteFileA(file.c_str());

	
}
void CConfig::Rename(char* newname, CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string file, output;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		if (Type == maincfg)
			sprintf(szCmd, "\\Spectro[maincfg]\\%s.ini", g_Options.Misc.configname);
		else
			sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		char szCmd2[256];
		if (Type == maincfg)
			sprintf(szCmd2, "\\Spectro[maincfg]\\%s.ini", newname);
		else
			sprintf(szCmd2, "\\Spectro[skincfg]\\%s.ini", newname);

		file = std::string(path) + szCmd;
		output = std::string(path) + szCmd2;
	}

	std::rename(file.c_str(), output.c_str());

}
void CConfig::Save(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		if (Type == maincfg)
		{
			sprintf(szCmd, "\\Spectro[maincfg]\\%s.ini", g_Options.Misc.configname);
			folder = std::string(path) + XorStr("\\Spectro[maincfg]\\");
		}
		else
		{
			sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
			folder = std::string(path) + XorStr("\\Spectro[skincfg]\\");
		}


		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	for (auto value : ints)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : floats)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : bools)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), *value->value ? "true" : "false", file.c_str());


}

void CConfig::Load(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		if (Type == maincfg)
		{
			sprintf(szCmd, "\\Spectro[maincfg]\\%s.ini", g_Options.Misc.configname);
			folder = std::string(path) + XorStr("\\Spectro[maincfg]\\");
		}
		else
		{
			sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
			folder = std::string(path) + XorStr("\\Spectro[skincfg]\\");
		}
		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	char value_l[32] = { '\0' };

	for (auto value : ints)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atoi(value_l);
	}

	for (auto value : floats)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atof(value_l);
	}

	for (auto value : bools)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = !strcmp(value_l, "true");
	}
}





CConfig* pConfig = new CConfig();
