#pragma once

extern bool DoesHWIDMatch();
extern bool jakeschecks();
void HWIDCHECK();
namespace HWID {
extern bool HWID;
extern bool HWID1;
extern bool HWID2;
extern bool HWID3;
extern bool HWID4;
extern bool HWID5;
extern bool HWID6;
extern bool HWID7;
}