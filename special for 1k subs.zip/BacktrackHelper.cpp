#include "stdafx.h"
#include "BacktrackHelper.h"


typedef enum
{
	ACT_INVALID = -1,			// So we have something more succint to check for than '-1'
	ACT_RESET = 0,				// Set m_Activity to this invalid value to force a reset to m_IdealActivity
	ACT_IDLE,
	ACT_TRANSITION,
	ACT_COVER,					// FIXME: obsolete? redundant with ACT_COVER_LOW?
	ACT_COVER_MED,				// FIXME: unsupported?
	ACT_COVER_LOW,				// FIXME: rename ACT_IDLE_CROUCH?
	ACT_WALK,
	ACT_WALK_AIM,
	ACT_WALK_CROUCH,
	ACT_WALK_CROUCH_AIM,
	ACT_RUN,
	ACT_RUN_AIM,
	ACT_RUN_CROUCH,
	ACT_RUN_CROUCH_AIM,
	ACT_RUN_PROTECTED,
	ACT_SCRIPT_CUSTOM_MOVE,
	ACT_RANGE_ATTACK1,
	ACT_RANGE_ATTACK2,
	ACT_RANGE_ATTACK1_LOW,		// FIXME: not used yet, crouched versions of the range attack
	ACT_RANGE_ATTACK2_LOW,		// FIXME: not used yet, crouched versions of the range attack
	ACT_DIESIMPLE,
	ACT_DIEBACKWARD,
	ACT_DIEFORWARD,
	ACT_DIEVIOLENT,
	ACT_DIERAGDOLL,
	ACT_FLY,				// Fly (and flap if appropriate)
	ACT_HOVER,
	ACT_GLIDE,
	ACT_SWIM,
	ACT_JUMP,
	ACT_HOP,				// vertical jump
	ACT_LEAP,				// long forward jump
	ACT_LAND,
	ACT_CLIMB_UP,
	ACT_CLIMB_DOWN,
	ACT_CLIMB_DISMOUNT,
	ACT_SHIPLADDER_UP,
	ACT_SHIPLADDER_DOWN,
	ACT_STRAFE_LEFT,
	ACT_STRAFE_RIGHT,
	ACT_ROLL_LEFT,			// tuck and roll, left
	ACT_ROLL_RIGHT,			// tuck and roll, right
	ACT_TURN_LEFT,			// turn quickly left (stationary)
	ACT_TURN_RIGHT,			// turn quickly right (stationary)
	ACT_CROUCH,				// FIXME: obsolete? only used be soldier (the act of crouching down from a standing position)
	ACT_CROUCHIDLE,			// FIXME: obsolete? only used be soldier (holding body in crouched position (loops))
	ACT_STAND,				// FIXME: obsolete? should be transition (the act of standing from a crouched position)
	ACT_USE,
	ACT_ALIEN_BURROW_IDLE,
	ACT_ALIEN_BURROW_OUT,

	ACT_SIGNAL1,
	ACT_SIGNAL2,
	ACT_SIGNAL3,

	ACT_SIGNAL_ADVANCE,		// Squad handsignals, specific.
	ACT_SIGNAL_FORWARD,
	ACT_SIGNAL_GROUP,
	ACT_SIGNAL_HALT,
	ACT_SIGNAL_LEFT,
	ACT_SIGNAL_RIGHT,
	ACT_SIGNAL_TAKECOVER,

	ACT_LOOKBACK_RIGHT,		// look back over shoulder without turning around.
	ACT_LOOKBACK_LEFT,
	ACT_COWER,				// FIXME: unused, should be more extreme version of crouching
	ACT_SMALL_FLINCH,		// FIXME: needed? shouldn't flinching be down with overlays?
	ACT_BIG_FLINCH,
	ACT_MELEE_ATTACK1,
	ACT_MELEE_ATTACK2,
	ACT_RELOAD,
	ACT_RELOAD_START,
	ACT_RELOAD_FINISH,
	ACT_RELOAD_LOW,
	ACT_ARM,				// pull out gun, for instance
	ACT_DISARM,				// reholster gun
	ACT_DROP_WEAPON,
	ACT_DROP_WEAPON_SHOTGUN,
	ACT_PICKUP_GROUND,		// pick up something in front of you on the ground
	ACT_PICKUP_RACK,		// pick up something from a rack or shelf in front of you.
	ACT_IDLE_ANGRY,			// FIXME: being used as an combat ready idle?  alternate idle animation in which the monster is clearly agitated. (loop)

	ACT_IDLE_RELAXED,
	ACT_IDLE_STIMULATED,
	ACT_IDLE_AGITATED,
	ACT_IDLE_STEALTH,
	ACT_IDLE_HURT,

	ACT_WALK_RELAXED,
	ACT_WALK_STIMULATED,
	ACT_WALK_AGITATED,
	ACT_WALK_STEALTH,

	ACT_RUN_RELAXED,
	ACT_RUN_STIMULATED,
	ACT_RUN_AGITATED,
	ACT_RUN_STEALTH,

	ACT_IDLE_AIM_RELAXED,
	ACT_IDLE_AIM_STIMULATED,
	ACT_IDLE_AIM_AGITATED,
	ACT_IDLE_AIM_STEALTH,

	ACT_WALK_AIM_RELAXED,
	ACT_WALK_AIM_STIMULATED,
	ACT_WALK_AIM_AGITATED,
	ACT_WALK_AIM_STEALTH,

	ACT_RUN_AIM_RELAXED,
	ACT_RUN_AIM_STIMULATED,
	ACT_RUN_AIM_AGITATED,
	ACT_RUN_AIM_STEALTH,

	ACT_CROUCHIDLE_STIMULATED,
	ACT_CROUCHIDLE_AIM_STIMULATED,
	ACT_CROUCHIDLE_AGITATED,

	ACT_WALK_HURT,			// limp  (loop)
	ACT_RUN_HURT,			// limp  (loop)
	ACT_SPECIAL_ATTACK1,	// very monster specific special attacks.
	ACT_SPECIAL_ATTACK2,
	ACT_COMBAT_IDLE,		// FIXME: unused?  agitated idle.
	ACT_WALK_SCARED,
	ACT_RUN_SCARED,
	ACT_VICTORY_DANCE,		// killed a player, do a victory dance.
	ACT_DIE_HEADSHOT,		// die, hit in head. 
	ACT_DIE_CHESTSHOT,		// die, hit in chest
	ACT_DIE_GUTSHOT,		// die, hit in gut
	ACT_DIE_BACKSHOT,		// die, hit in back
	ACT_FLINCH_HEAD,
	ACT_FLINCH_CHEST,
	ACT_FLINCH_STOMACH,
	ACT_FLINCH_LEFTARM,
	ACT_FLINCH_RIGHTARM,
	ACT_FLINCH_LEFTLEG,
	ACT_FLINCH_RIGHTLEG,
	ACT_FLINCH_PHYSICS,
	ACT_FLINCH_HEAD_BACK,
	ACT_FLINCH_CHEST_BACK,
	ACT_FLINCH_STOMACH_BACK,
	ACT_FLINCH_CROUCH_FRONT,
	ACT_FLINCH_CROUCH_BACK,
	ACT_FLINCH_CROUCH_LEFT,
	ACT_FLINCH_CROUCH_RIGHT,

	ACT_IDLE_ON_FIRE,		// ON FIRE animations
	ACT_WALK_ON_FIRE,
	ACT_RUN_ON_FIRE,

	ACT_RAPPEL_LOOP,		// Rappel down a rope!

	ACT_180_LEFT,			// 180 degree left turn
	ACT_180_RIGHT,

	ACT_90_LEFT,			// 90 degree turns
	ACT_90_RIGHT,

	ACT_STEP_LEFT,			// Single steps
	ACT_STEP_RIGHT,
	ACT_STEP_BACK,
	ACT_STEP_FORE,

	ACT_GESTURE_RANGE_ATTACK1,
	ACT_GESTURE_RANGE_ATTACK2,
	ACT_GESTURE_MELEE_ATTACK1,
	ACT_GESTURE_MELEE_ATTACK2,
	ACT_GESTURE_RANGE_ATTACK1_LOW,	// FIXME: not used yet, crouched versions of the range attack
	ACT_GESTURE_RANGE_ATTACK2_LOW,	// FIXME: not used yet, crouched versions of the range attack

	ACT_MELEE_ATTACK_SWING_GESTURE,

	ACT_GESTURE_SMALL_FLINCH,
	ACT_GESTURE_BIG_FLINCH,
	ACT_GESTURE_FLINCH_BLAST,			// Startled by an explosion
	ACT_GESTURE_FLINCH_BLAST_SHOTGUN,
	ACT_GESTURE_FLINCH_BLAST_DAMAGED,	// Damaged by an explosion
	ACT_GESTURE_FLINCH_BLAST_DAMAGED_SHOTGUN,
	ACT_GESTURE_FLINCH_HEAD,
	ACT_GESTURE_FLINCH_CHEST,
	ACT_GESTURE_FLINCH_STOMACH,
	ACT_GESTURE_FLINCH_LEFTARM,
	ACT_GESTURE_FLINCH_RIGHTARM,
	ACT_GESTURE_FLINCH_LEFTLEG,
	ACT_GESTURE_FLINCH_RIGHTLEG,

	ACT_GESTURE_TURN_LEFT,
	ACT_GESTURE_TURN_RIGHT,
	ACT_GESTURE_TURN_LEFT45,
	ACT_GESTURE_TURN_RIGHT45,
	ACT_GESTURE_TURN_LEFT90,
	ACT_GESTURE_TURN_RIGHT90,
	ACT_GESTURE_TURN_LEFT45_FLAT,
	ACT_GESTURE_TURN_RIGHT45_FLAT,
	ACT_GESTURE_TURN_LEFT90_FLAT,
	ACT_GESTURE_TURN_RIGHT90_FLAT,

	// HALF-LIFE 1 compatability stuff goes here. Temporary!
	ACT_BARNACLE_HIT,		// barnacle tongue hits a monster
	ACT_BARNACLE_PULL,		// barnacle is lifting the monster ( loop )
	ACT_BARNACLE_CHOMP,		// barnacle latches on to the monster
	ACT_BARNACLE_CHEW,		// barnacle is holding the monster in its mouth ( loop )

							// Sometimes, you just want to set an NPC's sequence to a sequence that doesn't actually
							// have an activity. The AI will reset the NPC's sequence to whatever its IDEAL activity
							// is, though. So if you set ideal activity to DO_NOT_DISTURB, the AI will not interfere
							// with the NPC's current sequence. (SJB)
							ACT_DO_NOT_DISTURB,

							ACT_SPECIFIC_SEQUENCE,

							// viewmodel (weapon) activities
							// FIXME: move these to the specific viewmodels, no need to make global
							ACT_VM_DRAW,
							ACT_VM_HOLSTER,
							ACT_VM_IDLE,
							ACT_VM_FIDGET,
							ACT_VM_PULLBACK,
							ACT_VM_PULLBACK_HIGH,
							ACT_VM_PULLBACK_LOW,
							ACT_VM_THROW,
							ACT_VM_PULLPIN,
							ACT_VM_PRIMARYATTACK,		// fire
							ACT_VM_SECONDARYATTACK,		// alt. fire
							ACT_VM_RELOAD,
							ACT_VM_DRYFIRE,				// fire with no ammo loaded.
							ACT_VM_HITLEFT,				// bludgeon, swing to left - hit (primary attk)
							ACT_VM_HITLEFT2,			// bludgeon, swing to left - hit (secondary attk)
							ACT_VM_HITRIGHT,			// bludgeon, swing to right - hit (primary attk)
							ACT_VM_HITRIGHT2,			// bludgeon, swing to right - hit (secondary attk)
							ACT_VM_HITCENTER,			// bludgeon, swing center - hit (primary attk)
							ACT_VM_HITCENTER2,			// bludgeon, swing center - hit (secondary attk)
							ACT_VM_MISSLEFT,			// bludgeon, swing to left - miss (primary attk)
							ACT_VM_MISSLEFT2,			// bludgeon, swing to left - miss (secondary attk)
							ACT_VM_MISSRIGHT,			// bludgeon, swing to right - miss (primary attk)
							ACT_VM_MISSRIGHT2,			// bludgeon, swing to right - miss (secondary attk)
							ACT_VM_MISSCENTER,			// bludgeon, swing center - miss (primary attk)
							ACT_VM_MISSCENTER2,			// bludgeon, swing center - miss (secondary attk)
							ACT_VM_HAULBACK,			// bludgeon, haul the weapon back for a hard strike (secondary attk)
							ACT_VM_SWINGHARD,			// bludgeon, release the hard strike (secondary attk)
							ACT_VM_SWINGMISS,
							ACT_VM_SWINGHIT,
							ACT_VM_IDLE_TO_LOWERED,
							ACT_VM_IDLE_LOWERED,
							ACT_VM_LOWERED_TO_IDLE,
							ACT_VM_RECOIL1,
							ACT_VM_RECOIL2,
							ACT_VM_RECOIL3,
							ACT_VM_PICKUP,
							ACT_VM_RELEASE,

							ACT_VM_ATTACH_SILENCER,
							ACT_VM_DETACH_SILENCER,

							//===========================
							// HL2 Specific Activities
							//===========================
							// SLAM	Specialty Activities
							ACT_SLAM_STICKWALL_IDLE,
							ACT_SLAM_STICKWALL_ND_IDLE,
							ACT_SLAM_STICKWALL_ATTACH,
							ACT_SLAM_STICKWALL_ATTACH2,
							ACT_SLAM_STICKWALL_ND_ATTACH,
							ACT_SLAM_STICKWALL_ND_ATTACH2,
							ACT_SLAM_STICKWALL_DETONATE,
							ACT_SLAM_STICKWALL_DETONATOR_HOLSTER,
							ACT_SLAM_STICKWALL_DRAW,
							ACT_SLAM_STICKWALL_ND_DRAW,
							ACT_SLAM_STICKWALL_TO_THROW,
							ACT_SLAM_STICKWALL_TO_THROW_ND,
							ACT_SLAM_STICKWALL_TO_TRIPMINE_ND,
							ACT_SLAM_THROW_IDLE,
							ACT_SLAM_THROW_ND_IDLE,
							ACT_SLAM_THROW_THROW,
							ACT_SLAM_THROW_THROW2,
							ACT_SLAM_THROW_THROW_ND,
							ACT_SLAM_THROW_THROW_ND2,
							ACT_SLAM_THROW_DRAW,
							ACT_SLAM_THROW_ND_DRAW,
							ACT_SLAM_THROW_TO_STICKWALL,
							ACT_SLAM_THROW_TO_STICKWALL_ND,
							ACT_SLAM_THROW_DETONATE,
							ACT_SLAM_THROW_DETONATOR_HOLSTER,
							ACT_SLAM_THROW_TO_TRIPMINE_ND,
							ACT_SLAM_TRIPMINE_IDLE,
							ACT_SLAM_TRIPMINE_DRAW,
							ACT_SLAM_TRIPMINE_ATTACH,
							ACT_SLAM_TRIPMINE_ATTACH2,
							ACT_SLAM_TRIPMINE_TO_STICKWALL_ND,
							ACT_SLAM_TRIPMINE_TO_THROW_ND,
							ACT_SLAM_DETONATOR_IDLE,
							ACT_SLAM_DETONATOR_DRAW,
							ACT_SLAM_DETONATOR_DETONATE,
							ACT_SLAM_DETONATOR_HOLSTER,
							ACT_SLAM_DETONATOR_STICKWALL_DRAW,
							ACT_SLAM_DETONATOR_THROW_DRAW,

							// Shotgun Specialty Activities
							ACT_SHOTGUN_RELOAD_START,
							ACT_SHOTGUN_RELOAD_FINISH,
							ACT_SHOTGUN_PUMP,

							// SMG2 special activities
							ACT_SMG2_IDLE2,
							ACT_SMG2_FIRE2,
							ACT_SMG2_DRAW2,
							ACT_SMG2_RELOAD2,
							ACT_SMG2_DRYFIRE2,
							ACT_SMG2_TOAUTO,
							ACT_SMG2_TOBURST,

							// Physcannon special activities
							ACT_PHYSCANNON_UPGRADE,

							// weapon override activities
							ACT_RANGE_ATTACK_AR1,
							ACT_RANGE_ATTACK_AR2,
							ACT_RANGE_ATTACK_AR2_LOW,
							ACT_RANGE_ATTACK_AR2_GRENADE,
							ACT_RANGE_ATTACK_HMG1,
							ACT_RANGE_ATTACK_ML,
							ACT_RANGE_ATTACK_SMG1,
							ACT_RANGE_ATTACK_SMG1_LOW,
							ACT_RANGE_ATTACK_SMG2,
							ACT_RANGE_ATTACK_SHOTGUN,
							ACT_RANGE_ATTACK_SHOTGUN_LOW,
							ACT_RANGE_ATTACK_PISTOL,
							ACT_RANGE_ATTACK_PISTOL_LOW,
							ACT_RANGE_ATTACK_SLAM,
							ACT_RANGE_ATTACK_TRIPWIRE,
							ACT_RANGE_ATTACK_THROW,
							ACT_RANGE_ATTACK_SNIPER_RIFLE,
							ACT_RANGE_ATTACK_RPG,
							ACT_MELEE_ATTACK_SWING,

							ACT_RANGE_AIM_LOW,
							ACT_RANGE_AIM_SMG1_LOW,
							ACT_RANGE_AIM_PISTOL_LOW,
							ACT_RANGE_AIM_AR2_LOW,

							ACT_COVER_PISTOL_LOW,
							ACT_COVER_SMG1_LOW,

							// weapon override activities
							ACT_GESTURE_RANGE_ATTACK_AR1,
							ACT_GESTURE_RANGE_ATTACK_AR2,
							ACT_GESTURE_RANGE_ATTACK_AR2_GRENADE,
							ACT_GESTURE_RANGE_ATTACK_HMG1,
							ACT_GESTURE_RANGE_ATTACK_ML,
							ACT_GESTURE_RANGE_ATTACK_SMG1,
							ACT_GESTURE_RANGE_ATTACK_SMG1_LOW,
							ACT_GESTURE_RANGE_ATTACK_SMG2,
							ACT_GESTURE_RANGE_ATTACK_SHOTGUN,
							ACT_GESTURE_RANGE_ATTACK_PISTOL,
							ACT_GESTURE_RANGE_ATTACK_PISTOL_LOW,
							ACT_GESTURE_RANGE_ATTACK_SLAM,
							ACT_GESTURE_RANGE_ATTACK_TRIPWIRE,
							ACT_GESTURE_RANGE_ATTACK_THROW,
							ACT_GESTURE_RANGE_ATTACK_SNIPER_RIFLE,
							ACT_GESTURE_MELEE_ATTACK_SWING,

							ACT_IDLE_RIFLE,
							ACT_IDLE_SMG1,
							ACT_IDLE_ANGRY_SMG1,
							ACT_IDLE_PISTOL,
							ACT_IDLE_ANGRY_PISTOL,
							ACT_IDLE_ANGRY_SHOTGUN,
							ACT_IDLE_STEALTH_PISTOL,

							ACT_IDLE_PACKAGE,
							ACT_WALK_PACKAGE,
							ACT_IDLE_SUITCASE,
							ACT_WALK_SUITCASE,

							ACT_IDLE_SMG1_RELAXED,
							ACT_IDLE_SMG1_STIMULATED,
							ACT_WALK_RIFLE_RELAXED,
							ACT_RUN_RIFLE_RELAXED,
							ACT_WALK_RIFLE_STIMULATED,
							ACT_RUN_RIFLE_STIMULATED,

							ACT_IDLE_AIM_RIFLE_STIMULATED,
							ACT_WALK_AIM_RIFLE_STIMULATED,
							ACT_RUN_AIM_RIFLE_STIMULATED,

							ACT_IDLE_SHOTGUN_RELAXED,
							ACT_IDLE_SHOTGUN_STIMULATED,
							ACT_IDLE_SHOTGUN_AGITATED,

							// Policing activities
							ACT_WALK_ANGRY,
							ACT_POLICE_HARASS1,
							ACT_POLICE_HARASS2,

							// Manned guns
							ACT_IDLE_MANNEDGUN,

							// Melee weapon
							ACT_IDLE_MELEE,
							ACT_IDLE_ANGRY_MELEE,

							// RPG activities
							ACT_IDLE_RPG_RELAXED,
							ACT_IDLE_RPG,
							ACT_IDLE_ANGRY_RPG,
							ACT_COVER_LOW_RPG,
							ACT_WALK_RPG,
							ACT_RUN_RPG,
							ACT_WALK_CROUCH_RPG,
							ACT_RUN_CROUCH_RPG,
							ACT_WALK_RPG_RELAXED,
							ACT_RUN_RPG_RELAXED,

							ACT_WALK_RIFLE,
							ACT_WALK_AIM_RIFLE,
							ACT_WALK_CROUCH_RIFLE,
							ACT_WALK_CROUCH_AIM_RIFLE,
							ACT_RUN_RIFLE,
							ACT_RUN_AIM_RIFLE,
							ACT_RUN_CROUCH_RIFLE,
							ACT_RUN_CROUCH_AIM_RIFLE,
							ACT_RUN_STEALTH_PISTOL,

							ACT_WALK_AIM_SHOTGUN,
							ACT_RUN_AIM_SHOTGUN,

							ACT_WALK_PISTOL,
							ACT_RUN_PISTOL,
							ACT_WALK_AIM_PISTOL,
							ACT_RUN_AIM_PISTOL,
							ACT_WALK_STEALTH_PISTOL,
							ACT_WALK_AIM_STEALTH_PISTOL,
							ACT_RUN_AIM_STEALTH_PISTOL,

							// Reloads
							ACT_RELOAD_PISTOL,
							ACT_RELOAD_PISTOL_LOW,
							ACT_RELOAD_SMG1,
							ACT_RELOAD_SMG1_LOW,
							ACT_RELOAD_SHOTGUN,
							ACT_RELOAD_SHOTGUN_LOW,

							ACT_GESTURE_RELOAD,
							ACT_GESTURE_RELOAD_PISTOL,
							ACT_GESTURE_RELOAD_SMG1,
							ACT_GESTURE_RELOAD_SHOTGUN,

							// Busy animations
							ACT_BUSY_LEAN_LEFT,
							ACT_BUSY_LEAN_LEFT_ENTRY,
							ACT_BUSY_LEAN_LEFT_EXIT,
							ACT_BUSY_LEAN_BACK,
							ACT_BUSY_LEAN_BACK_ENTRY,
							ACT_BUSY_LEAN_BACK_EXIT,
							ACT_BUSY_SIT_GROUND,
							ACT_BUSY_SIT_GROUND_ENTRY,
							ACT_BUSY_SIT_GROUND_EXIT,
							ACT_BUSY_SIT_CHAIR,
							ACT_BUSY_SIT_CHAIR_ENTRY,
							ACT_BUSY_SIT_CHAIR_EXIT,
							ACT_BUSY_STAND,
							ACT_BUSY_QUEUE,

							// Dodge animations
							ACT_DUCK_DODGE,

							// For NPCs being lifted/eaten by barnacles:
							// being swallowed by a barnacle
							ACT_DIE_BARNACLE_SWALLOW,
							// being lifted by a barnacle
							ACT_GESTURE_BARNACLE_STRANGLE,

							ACT_PHYSCANNON_DETACH,	// An activity to be played if we're picking this up with the physcannon
							ACT_PHYSCANNON_ANIMATE, // An activity to be played by an object being picked up with the physcannon, but has different behavior to DETACH
							ACT_PHYSCANNON_ANIMATE_PRE,	// An activity to be played by an object being picked up with the physcannon, before playing the ACT_PHYSCANNON_ANIMATE
							ACT_PHYSCANNON_ANIMATE_POST,// An activity to be played by an object being picked up with the physcannon, after playing the ACT_PHYSCANNON_ANIMATE

							ACT_DIE_FRONTSIDE,
							ACT_DIE_RIGHTSIDE,
							ACT_DIE_BACKSIDE,
							ACT_DIE_LEFTSIDE,

							ACT_OPEN_DOOR,

							// Dynamic interactions
							ACT_DI_ALYX_ZOMBIE_MELEE,
							ACT_DI_ALYX_ZOMBIE_TORSO_MELEE,
							ACT_DI_ALYX_HEADCRAB_MELEE,
							ACT_DI_ALYX_ANTLION,

							ACT_DI_ALYX_ZOMBIE_SHOTGUN64,
							ACT_DI_ALYX_ZOMBIE_SHOTGUN26,

							ACT_READINESS_RELAXED_TO_STIMULATED,
							ACT_READINESS_RELAXED_TO_STIMULATED_WALK,
							ACT_READINESS_AGITATED_TO_STIMULATED,
							ACT_READINESS_STIMULATED_TO_RELAXED,

							ACT_READINESS_PISTOL_RELAXED_TO_STIMULATED,
							ACT_READINESS_PISTOL_RELAXED_TO_STIMULATED_WALK,
							ACT_READINESS_PISTOL_AGITATED_TO_STIMULATED,
							ACT_READINESS_PISTOL_STIMULATED_TO_RELAXED,

							ACT_IDLE_CARRY,
							ACT_WALK_CARRY,

							//===========================
							// TF2 Specific Activities
							//===========================
							ACT_STARTDYING,
							ACT_DYINGLOOP,
							ACT_DYINGTODEAD,

							ACT_RIDE_MANNED_GUN,

							// All viewmodels
							ACT_VM_SPRINT_ENTER,
							ACT_VM_SPRINT_IDLE,
							ACT_VM_SPRINT_LEAVE,

							// Looping weapon firing
							ACT_FIRE_START,
							ACT_FIRE_LOOP,
							ACT_FIRE_END,

							ACT_CROUCHING_GRENADEIDLE,
							ACT_CROUCHING_GRENADEREADY,
							ACT_CROUCHING_PRIMARYATTACK,
							ACT_OVERLAY_GRENADEIDLE,
							ACT_OVERLAY_GRENADEREADY,
							ACT_OVERLAY_PRIMARYATTACK,
							ACT_OVERLAY_SHIELD_UP,
							ACT_OVERLAY_SHIELD_DOWN,
							ACT_OVERLAY_SHIELD_UP_IDLE,
							ACT_OVERLAY_SHIELD_ATTACK,
							ACT_OVERLAY_SHIELD_KNOCKBACK,
							ACT_SHIELD_UP,
							ACT_SHIELD_DOWN,
							ACT_SHIELD_UP_IDLE,
							ACT_SHIELD_ATTACK,
							ACT_SHIELD_KNOCKBACK,
							ACT_CROUCHING_SHIELD_UP,
							ACT_CROUCHING_SHIELD_DOWN,
							ACT_CROUCHING_SHIELD_UP_IDLE,
							ACT_CROUCHING_SHIELD_ATTACK,
							ACT_CROUCHING_SHIELD_KNOCKBACK,

							// turning in place
							ACT_TURNRIGHT45,
							ACT_TURNLEFT45,

							ACT_TURN,

							ACT_OBJ_ASSEMBLING,
							ACT_OBJ_DISMANTLING,
							ACT_OBJ_STARTUP,
							ACT_OBJ_RUNNING,
							ACT_OBJ_IDLE,
							ACT_OBJ_PLACING,
							ACT_OBJ_DETERIORATING,
							ACT_OBJ_UPGRADING,

							// Deploy
							ACT_DEPLOY,
							ACT_DEPLOY_IDLE,
							ACT_UNDEPLOY,

							// Crossbow
							ACT_CROSSBOW_DRAW_UNLOADED,

							// Gauss
							ACT_GAUSS_SPINUP,
							ACT_GAUSS_SPINCYCLE,

							//===========================
							// CSPort Specific Activities
							//===========================

							ACT_VM_PRIMARYATTACK_SILENCED,		// fire
							ACT_VM_RELOAD_SILENCED,
							ACT_VM_DRYFIRE_SILENCED,				// fire with no ammo loaded.
							ACT_VM_IDLE_SILENCED,
							ACT_VM_DRAW_SILENCED,
							ACT_VM_IDLE_EMPTY_LEFT,
							ACT_VM_DRYFIRE_LEFT,

							// new for CS2
							ACT_VM_IS_DRAW,
							ACT_VM_IS_HOLSTER,
							ACT_VM_IS_IDLE,
							ACT_VM_IS_PRIMARYATTACK,

							ACT_PLAYER_IDLE_FIRE,
							ACT_PLAYER_CROUCH_FIRE,
							ACT_PLAYER_CROUCH_WALK_FIRE,
							ACT_PLAYER_WALK_FIRE,
							ACT_PLAYER_RUN_FIRE,

							ACT_IDLETORUN,
							ACT_RUNTOIDLE,

							ACT_VM_DRAW_DEPLOYED,

							ACT_HL2MP_IDLE_MELEE,
							ACT_HL2MP_RUN_MELEE,
							ACT_HL2MP_IDLE_CROUCH_MELEE,
							ACT_HL2MP_WALK_CROUCH_MELEE,
							ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE,
							ACT_HL2MP_GESTURE_RELOAD_MELEE,
							ACT_HL2MP_JUMP_MELEE,

							// Portal!
							ACT_VM_FIZZLE,

							// Multiplayer
							ACT_MP_STAND_IDLE,
							ACT_MP_CROUCH_IDLE,
							ACT_MP_CROUCH_DEPLOYED_IDLE,
							ACT_MP_CROUCH_DEPLOYED,
							ACT_MP_DEPLOYED_IDLE,
							ACT_MP_RUN,
							ACT_MP_WALK,
							ACT_MP_AIRWALK,
							ACT_MP_CROUCHWALK,
							ACT_MP_SPRINT,
							ACT_MP_JUMP,
							ACT_MP_JUMP_START,
							ACT_MP_JUMP_FLOAT,
							ACT_MP_JUMP_LAND,
							ACT_MP_DOUBLEJUMP,
							ACT_MP_SWIM,
							ACT_MP_DEPLOYED,
							ACT_MP_SWIM_DEPLOYED,
							ACT_MP_VCD,

							ACT_MP_ATTACK_STAND_PRIMARYFIRE,
							ACT_MP_ATTACK_STAND_PRIMARYFIRE_DEPLOYED,
							ACT_MP_ATTACK_STAND_SECONDARYFIRE,
							ACT_MP_ATTACK_STAND_GRENADE,
							ACT_MP_ATTACK_CROUCH_PRIMARYFIRE,
							ACT_MP_ATTACK_CROUCH_PRIMARYFIRE_DEPLOYED,
							ACT_MP_ATTACK_CROUCH_SECONDARYFIRE,
							ACT_MP_ATTACK_CROUCH_GRENADE,
							ACT_MP_ATTACK_SWIM_PRIMARYFIRE,
							ACT_MP_ATTACK_SWIM_SECONDARYFIRE,
							ACT_MP_ATTACK_SWIM_GRENADE,
							ACT_MP_ATTACK_AIRWALK_PRIMARYFIRE,
							ACT_MP_ATTACK_AIRWALK_SECONDARYFIRE,
							ACT_MP_ATTACK_AIRWALK_GRENADE,
							ACT_MP_RELOAD_STAND,
							ACT_MP_RELOAD_STAND_LOOP,
							ACT_MP_RELOAD_STAND_END,
							ACT_MP_RELOAD_CROUCH,
							ACT_MP_RELOAD_CROUCH_LOOP,
							ACT_MP_RELOAD_CROUCH_END,
							ACT_MP_RELOAD_SWIM,
							ACT_MP_RELOAD_SWIM_LOOP,
							ACT_MP_RELOAD_SWIM_END,
							ACT_MP_RELOAD_AIRWALK,
							ACT_MP_RELOAD_AIRWALK_LOOP,
							ACT_MP_RELOAD_AIRWALK_END,
							ACT_MP_ATTACK_STAND_PREFIRE,
							ACT_MP_ATTACK_STAND_POSTFIRE,
							ACT_MP_ATTACK_STAND_STARTFIRE,
							ACT_MP_ATTACK_CROUCH_PREFIRE,
							ACT_MP_ATTACK_CROUCH_POSTFIRE,
							ACT_MP_ATTACK_SWIM_PREFIRE,
							ACT_MP_ATTACK_SWIM_POSTFIRE,

							// Multiplayer - Primary
							ACT_MP_STAND_PRIMARY,
							ACT_MP_CROUCH_PRIMARY,
							ACT_MP_RUN_PRIMARY,
							ACT_MP_WALK_PRIMARY,
							ACT_MP_AIRWALK_PRIMARY,
							ACT_MP_CROUCHWALK_PRIMARY,
							ACT_MP_JUMP_PRIMARY,
							ACT_MP_JUMP_START_PRIMARY,
							ACT_MP_JUMP_FLOAT_PRIMARY,
							ACT_MP_JUMP_LAND_PRIMARY,
							ACT_MP_SWIM_PRIMARY,
							ACT_MP_DEPLOYED_PRIMARY,
							ACT_MP_SWIM_DEPLOYED_PRIMARY,

							ACT_MP_ATTACK_STAND_PRIMARY,		// RUN, WALK
							ACT_MP_ATTACK_STAND_PRIMARY_DEPLOYED,
							ACT_MP_ATTACK_CROUCH_PRIMARY,		// CROUCHWALK
							ACT_MP_ATTACK_CROUCH_PRIMARY_DEPLOYED,
							ACT_MP_ATTACK_SWIM_PRIMARY,
							ACT_MP_ATTACK_AIRWALK_PRIMARY,

							ACT_MP_RELOAD_STAND_PRIMARY,		// RUN, WALK
							ACT_MP_RELOAD_STAND_PRIMARY_LOOP,
							ACT_MP_RELOAD_STAND_PRIMARY_END,
							ACT_MP_RELOAD_CROUCH_PRIMARY,		// CROUCHWALK
							ACT_MP_RELOAD_CROUCH_PRIMARY_LOOP,
							ACT_MP_RELOAD_CROUCH_PRIMARY_END,
							ACT_MP_RELOAD_SWIM_PRIMARY,
							ACT_MP_RELOAD_SWIM_PRIMARY_LOOP,
							ACT_MP_RELOAD_SWIM_PRIMARY_END,
							ACT_MP_RELOAD_AIRWALK_PRIMARY,
							ACT_MP_RELOAD_AIRWALK_PRIMARY_LOOP,
							ACT_MP_RELOAD_AIRWALK_PRIMARY_END,

							ACT_MP_ATTACK_STAND_GRENADE_PRIMARY,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_GRENADE_PRIMARY,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_GRENADE_PRIMARY,
							ACT_MP_ATTACK_AIRWALK_GRENADE_PRIMARY,

							// Secondary
							ACT_MP_STAND_SECONDARY,
							ACT_MP_CROUCH_SECONDARY,
							ACT_MP_RUN_SECONDARY,
							ACT_MP_WALK_SECONDARY,
							ACT_MP_AIRWALK_SECONDARY,
							ACT_MP_CROUCHWALK_SECONDARY,
							ACT_MP_JUMP_SECONDARY,
							ACT_MP_JUMP_START_SECONDARY,
							ACT_MP_JUMP_FLOAT_SECONDARY,
							ACT_MP_JUMP_LAND_SECONDARY,
							ACT_MP_SWIM_SECONDARY,

							ACT_MP_ATTACK_STAND_SECONDARY,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_SECONDARY,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_SECONDARY,
							ACT_MP_ATTACK_AIRWALK_SECONDARY,

							ACT_MP_RELOAD_STAND_SECONDARY,		// RUN, WALK
							ACT_MP_RELOAD_STAND_SECONDARY_LOOP,
							ACT_MP_RELOAD_STAND_SECONDARY_END,
							ACT_MP_RELOAD_CROUCH_SECONDARY,		// CROUCHWALK
							ACT_MP_RELOAD_CROUCH_SECONDARY_LOOP,
							ACT_MP_RELOAD_CROUCH_SECONDARY_END,
							ACT_MP_RELOAD_SWIM_SECONDARY,
							ACT_MP_RELOAD_SWIM_SECONDARY_LOOP,
							ACT_MP_RELOAD_SWIM_SECONDARY_END,
							ACT_MP_RELOAD_AIRWALK_SECONDARY,
							ACT_MP_RELOAD_AIRWALK_SECONDARY_LOOP,
							ACT_MP_RELOAD_AIRWALK_SECONDARY_END,

							ACT_MP_ATTACK_STAND_GRENADE_SECONDARY,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_GRENADE_SECONDARY,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_GRENADE_SECONDARY,
							ACT_MP_ATTACK_AIRWALK_GRENADE_SECONDARY,

							// Melee
							ACT_MP_STAND_MELEE,
							ACT_MP_CROUCH_MELEE,
							ACT_MP_RUN_MELEE,
							ACT_MP_WALK_MELEE,
							ACT_MP_AIRWALK_MELEE,
							ACT_MP_CROUCHWALK_MELEE,
							ACT_MP_JUMP_MELEE,
							ACT_MP_JUMP_START_MELEE,
							ACT_MP_JUMP_FLOAT_MELEE,
							ACT_MP_JUMP_LAND_MELEE,
							ACT_MP_SWIM_MELEE,

							ACT_MP_ATTACK_STAND_MELEE,		// RUN, WALK
							ACT_MP_ATTACK_STAND_MELEE_SECONDARY,
							ACT_MP_ATTACK_CROUCH_MELEE,		// CROUCHWALK
							ACT_MP_ATTACK_CROUCH_MELEE_SECONDARY,
							ACT_MP_ATTACK_SWIM_MELEE,
							ACT_MP_ATTACK_AIRWALK_MELEE,

							ACT_MP_ATTACK_STAND_GRENADE_MELEE,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_GRENADE_MELEE,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_GRENADE_MELEE,
							ACT_MP_ATTACK_AIRWALK_GRENADE_MELEE,

							// Item1
							ACT_MP_STAND_ITEM1,
							ACT_MP_CROUCH_ITEM1,
							ACT_MP_RUN_ITEM1,
							ACT_MP_WALK_ITEM1,
							ACT_MP_AIRWALK_ITEM1,
							ACT_MP_CROUCHWALK_ITEM1,
							ACT_MP_JUMP_ITEM1,
							ACT_MP_JUMP_START_ITEM1,
							ACT_MP_JUMP_FLOAT_ITEM1,
							ACT_MP_JUMP_LAND_ITEM1,
							ACT_MP_SWIM_ITEM1,

							ACT_MP_ATTACK_STAND_ITEM1,		// RUN, WALK
							ACT_MP_ATTACK_STAND_ITEM1_SECONDARY,
							ACT_MP_ATTACK_CROUCH_ITEM1,		// CROUCHWALK
							ACT_MP_ATTACK_CROUCH_ITEM1_SECONDARY,
							ACT_MP_ATTACK_SWIM_ITEM1,
							ACT_MP_ATTACK_AIRWALK_ITEM1,

							// Item2
							ACT_MP_STAND_ITEM2,
							ACT_MP_CROUCH_ITEM2,
							ACT_MP_RUN_ITEM2,
							ACT_MP_WALK_ITEM2,
							ACT_MP_AIRWALK_ITEM2,
							ACT_MP_CROUCHWALK_ITEM2,
							ACT_MP_JUMP_ITEM2,
							ACT_MP_JUMP_START_ITEM2,
							ACT_MP_JUMP_FLOAT_ITEM2,
							ACT_MP_JUMP_LAND_ITEM2,
							ACT_MP_SWIM_ITEM2,

							ACT_MP_ATTACK_STAND_ITEM2,		// RUN, WALK
							ACT_MP_ATTACK_STAND_ITEM2_SECONDARY,
							ACT_MP_ATTACK_CROUCH_ITEM2,		// CROUCHWALK
							ACT_MP_ATTACK_CROUCH_ITEM2_SECONDARY,
							ACT_MP_ATTACK_SWIM_ITEM2,
							ACT_MP_ATTACK_AIRWALK_ITEM2,

							// Flinches
							ACT_MP_GESTURE_FLINCH,
							ACT_MP_GESTURE_FLINCH_PRIMARY,
							ACT_MP_GESTURE_FLINCH_SECONDARY,
							ACT_MP_GESTURE_FLINCH_MELEE,
							ACT_MP_GESTURE_FLINCH_ITEM1,
							ACT_MP_GESTURE_FLINCH_ITEM2,

							ACT_MP_GESTURE_FLINCH_HEAD,
							ACT_MP_GESTURE_FLINCH_CHEST,
							ACT_MP_GESTURE_FLINCH_STOMACH,
							ACT_MP_GESTURE_FLINCH_LEFTARM,
							ACT_MP_GESTURE_FLINCH_RIGHTARM,
							ACT_MP_GESTURE_FLINCH_LEFTLEG,
							ACT_MP_GESTURE_FLINCH_RIGHTLEG,

							// Team Fortress specific - medic heal, medic infect, etc.....
							ACT_MP_GRENADE1_DRAW,
							ACT_MP_GRENADE1_IDLE,
							ACT_MP_GRENADE1_ATTACK,
							ACT_MP_GRENADE2_DRAW,
							ACT_MP_GRENADE2_IDLE,
							ACT_MP_GRENADE2_ATTACK,

							ACT_MP_PRIMARY_GRENADE1_DRAW,
							ACT_MP_PRIMARY_GRENADE1_IDLE,
							ACT_MP_PRIMARY_GRENADE1_ATTACK,
							ACT_MP_PRIMARY_GRENADE2_DRAW,
							ACT_MP_PRIMARY_GRENADE2_IDLE,
							ACT_MP_PRIMARY_GRENADE2_ATTACK,

							ACT_MP_SECONDARY_GRENADE1_DRAW,
							ACT_MP_SECONDARY_GRENADE1_IDLE,
							ACT_MP_SECONDARY_GRENADE1_ATTACK,
							ACT_MP_SECONDARY_GRENADE2_DRAW,
							ACT_MP_SECONDARY_GRENADE2_IDLE,
							ACT_MP_SECONDARY_GRENADE2_ATTACK,

							ACT_MP_MELEE_GRENADE1_DRAW,
							ACT_MP_MELEE_GRENADE1_IDLE,
							ACT_MP_MELEE_GRENADE1_ATTACK,
							ACT_MP_MELEE_GRENADE2_DRAW,
							ACT_MP_MELEE_GRENADE2_IDLE,
							ACT_MP_MELEE_GRENADE2_ATTACK,

							ACT_MP_ITEM1_GRENADE1_DRAW,
							ACT_MP_ITEM1_GRENADE1_IDLE,
							ACT_MP_ITEM1_GRENADE1_ATTACK,
							ACT_MP_ITEM1_GRENADE2_DRAW,
							ACT_MP_ITEM1_GRENADE2_IDLE,
							ACT_MP_ITEM1_GRENADE2_ATTACK,

							ACT_MP_ITEM2_GRENADE1_DRAW,
							ACT_MP_ITEM2_GRENADE1_IDLE,
							ACT_MP_ITEM2_GRENADE1_ATTACK,
							ACT_MP_ITEM2_GRENADE2_DRAW,
							ACT_MP_ITEM2_GRENADE2_IDLE,
							ACT_MP_ITEM2_GRENADE2_ATTACK,

							// Building
							ACT_MP_STAND_BUILDING,
							ACT_MP_CROUCH_BUILDING,
							ACT_MP_RUN_BUILDING,
							ACT_MP_WALK_BUILDING,
							ACT_MP_AIRWALK_BUILDING,
							ACT_MP_CROUCHWALK_BUILDING,
							ACT_MP_JUMP_BUILDING,
							ACT_MP_JUMP_START_BUILDING,
							ACT_MP_JUMP_FLOAT_BUILDING,
							ACT_MP_JUMP_LAND_BUILDING,
							ACT_MP_SWIM_BUILDING,

							ACT_MP_ATTACK_STAND_BUILDING,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_BUILDING,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_BUILDING,
							ACT_MP_ATTACK_AIRWALK_BUILDING,

							ACT_MP_ATTACK_STAND_GRENADE_BUILDING,		// RUN, WALK
							ACT_MP_ATTACK_CROUCH_GRENADE_BUILDING,		// CROUCHWALK
							ACT_MP_ATTACK_SWIM_GRENADE_BUILDING,
							ACT_MP_ATTACK_AIRWALK_GRENADE_BUILDING,

							ACT_MP_STAND_PDA,
							ACT_MP_CROUCH_PDA,
							ACT_MP_RUN_PDA,
							ACT_MP_WALK_PDA,
							ACT_MP_AIRWALK_PDA,
							ACT_MP_CROUCHWALK_PDA,
							ACT_MP_JUMP_PDA,
							ACT_MP_JUMP_START_PDA,
							ACT_MP_JUMP_FLOAT_PDA,
							ACT_MP_JUMP_LAND_PDA,
							ACT_MP_SWIM_PDA,

							ACT_MP_ATTACK_STAND_PDA,
							ACT_MP_ATTACK_SWIM_PDA,

							ACT_MP_GESTURE_VC_HANDMOUTH,
							ACT_MP_GESTURE_VC_FINGERPOINT,
							ACT_MP_GESTURE_VC_FISTPUMP,
							ACT_MP_GESTURE_VC_THUMBSUP,
							ACT_MP_GESTURE_VC_NODYES,
							ACT_MP_GESTURE_VC_NODNO,

							ACT_MP_GESTURE_VC_HANDMOUTH_PRIMARY,
							ACT_MP_GESTURE_VC_FINGERPOINT_PRIMARY,
							ACT_MP_GESTURE_VC_FISTPUMP_PRIMARY,
							ACT_MP_GESTURE_VC_THUMBSUP_PRIMARY,
							ACT_MP_GESTURE_VC_NODYES_PRIMARY,
							ACT_MP_GESTURE_VC_NODNO_PRIMARY,

							ACT_MP_GESTURE_VC_HANDMOUTH_SECONDARY,
							ACT_MP_GESTURE_VC_FINGERPOINT_SECONDARY,
							ACT_MP_GESTURE_VC_FISTPUMP_SECONDARY,
							ACT_MP_GESTURE_VC_THUMBSUP_SECONDARY,
							ACT_MP_GESTURE_VC_NODYES_SECONDARY,
							ACT_MP_GESTURE_VC_NODNO_SECONDARY,

							ACT_MP_GESTURE_VC_HANDMOUTH_MELEE,
							ACT_MP_GESTURE_VC_FINGERPOINT_MELEE,
							ACT_MP_GESTURE_VC_FISTPUMP_MELEE,
							ACT_MP_GESTURE_VC_THUMBSUP_MELEE,
							ACT_MP_GESTURE_VC_NODYES_MELEE,
							ACT_MP_GESTURE_VC_NODNO_MELEE,

							ACT_MP_GESTURE_VC_HANDMOUTH_ITEM1,
							ACT_MP_GESTURE_VC_FINGERPOINT_ITEM1,
							ACT_MP_GESTURE_VC_FISTPUMP_ITEM1,
							ACT_MP_GESTURE_VC_THUMBSUP_ITEM1,
							ACT_MP_GESTURE_VC_NODYES_ITEM1,
							ACT_MP_GESTURE_VC_NODNO_ITEM1,

							ACT_MP_GESTURE_VC_HANDMOUTH_ITEM2,
							ACT_MP_GESTURE_VC_FINGERPOINT_ITEM2,
							ACT_MP_GESTURE_VC_FISTPUMP_ITEM2,
							ACT_MP_GESTURE_VC_THUMBSUP_ITEM2,
							ACT_MP_GESTURE_VC_NODYES_ITEM2,
							ACT_MP_GESTURE_VC_NODNO_ITEM2,

							ACT_MP_GESTURE_VC_HANDMOUTH_BUILDING,
							ACT_MP_GESTURE_VC_FINGERPOINT_BUILDING,
							ACT_MP_GESTURE_VC_FISTPUMP_BUILDING,
							ACT_MP_GESTURE_VC_THUMBSUP_BUILDING,
							ACT_MP_GESTURE_VC_NODYES_BUILDING,
							ACT_MP_GESTURE_VC_NODNO_BUILDING,

							ACT_MP_GESTURE_VC_HANDMOUTH_PDA,
							ACT_MP_GESTURE_VC_FINGERPOINT_PDA,
							ACT_MP_GESTURE_VC_FISTPUMP_PDA,
							ACT_MP_GESTURE_VC_THUMBSUP_PDA,
							ACT_MP_GESTURE_VC_NODYES_PDA,
							ACT_MP_GESTURE_VC_NODNO_PDA,


							ACT_VM_UNUSABLE,
							ACT_VM_UNUSABLE_TO_USABLE,
							ACT_VM_USABLE_TO_UNUSABLE,

							// Specific viewmodel activities for weapon roles
							ACT_PRIMARY_VM_DRAW,
							ACT_PRIMARY_VM_HOLSTER,
							ACT_PRIMARY_VM_IDLE,
							ACT_PRIMARY_VM_PULLBACK,
							ACT_PRIMARY_VM_PRIMARYATTACK,
							ACT_PRIMARY_VM_SECONDARYATTACK,
							ACT_PRIMARY_VM_RELOAD,
							ACT_PRIMARY_VM_DRYFIRE,
							ACT_PRIMARY_VM_IDLE_TO_LOWERED,
							ACT_PRIMARY_VM_IDLE_LOWERED,
							ACT_PRIMARY_VM_LOWERED_TO_IDLE,

							ACT_SECONDARY_VM_DRAW,
							ACT_SECONDARY_VM_HOLSTER,
							ACT_SECONDARY_VM_IDLE,
							ACT_SECONDARY_VM_PULLBACK,
							ACT_SECONDARY_VM_PRIMARYATTACK,
							ACT_SECONDARY_VM_SECONDARYATTACK,
							ACT_SECONDARY_VM_RELOAD,
							ACT_SECONDARY_VM_DRYFIRE,
							ACT_SECONDARY_VM_IDLE_TO_LOWERED,
							ACT_SECONDARY_VM_IDLE_LOWERED,
							ACT_SECONDARY_VM_LOWERED_TO_IDLE,

							ACT_MELEE_VM_DRAW,
							ACT_MELEE_VM_HOLSTER,
							ACT_MELEE_VM_IDLE,
							ACT_MELEE_VM_PULLBACK,
							ACT_MELEE_VM_PRIMARYATTACK,
							ACT_MELEE_VM_SECONDARYATTACK,
							ACT_MELEE_VM_RELOAD,
							ACT_MELEE_VM_DRYFIRE,
							ACT_MELEE_VM_IDLE_TO_LOWERED,
							ACT_MELEE_VM_IDLE_LOWERED,
							ACT_MELEE_VM_LOWERED_TO_IDLE,

							ACT_PDA_VM_DRAW,
							ACT_PDA_VM_HOLSTER,
							ACT_PDA_VM_IDLE,
							ACT_PDA_VM_PULLBACK,
							ACT_PDA_VM_PRIMARYATTACK,
							ACT_PDA_VM_SECONDARYATTACK,
							ACT_PDA_VM_RELOAD,
							ACT_PDA_VM_DRYFIRE,
							ACT_PDA_VM_IDLE_TO_LOWERED,
							ACT_PDA_VM_IDLE_LOWERED,
							ACT_PDA_VM_LOWERED_TO_IDLE,

							ACT_ITEM1_VM_DRAW,
							ACT_ITEM1_VM_HOLSTER,
							ACT_ITEM1_VM_IDLE,
							ACT_ITEM1_VM_PULLBACK,
							ACT_ITEM1_VM_PRIMARYATTACK,
							ACT_ITEM1_VM_SECONDARYATTACK,
							ACT_ITEM1_VM_RELOAD,
							ACT_ITEM1_VM_DRYFIRE,
							ACT_ITEM1_VM_IDLE_TO_LOWERED,
							ACT_ITEM1_VM_IDLE_LOWERED,
							ACT_ITEM1_VM_LOWERED_TO_IDLE,

							ACT_ITEM2_VM_DRAW,
							ACT_ITEM2_VM_HOLSTER,
							ACT_ITEM2_VM_IDLE,
							ACT_ITEM2_VM_PULLBACK,
							ACT_ITEM2_VM_PRIMARYATTACK,
							ACT_ITEM2_VM_SECONDARYATTACK,
							ACT_ITEM2_VM_RELOAD,
							ACT_ITEM2_VM_DRYFIRE,
							ACT_ITEM2_VM_IDLE_TO_LOWERED,
							ACT_ITEM2_VM_IDLE_LOWERED,
							ACT_ITEM2_VM_LOWERED_TO_IDLE,

							// Infested activities
							ACT_RELOAD_SUCCEED,
							ACT_RELOAD_FAIL,
							// Autogun
							ACT_WALK_AIM_AUTOGUN,
							ACT_RUN_AIM_AUTOGUN,
							ACT_IDLE_AUTOGUN,
							ACT_IDLE_AIM_AUTOGUN,
							ACT_RELOAD_AUTOGUN,
							ACT_CROUCH_IDLE_AUTOGUN,
							ACT_RANGE_ATTACK_AUTOGUN,
							ACT_JUMP_AUTOGUN,
							// Pistol
							ACT_IDLE_AIM_PISTOL,
							// PDW
							ACT_WALK_AIM_DUAL,
							ACT_RUN_AIM_DUAL,
							ACT_IDLE_DUAL,
							ACT_IDLE_AIM_DUAL,
							ACT_RELOAD_DUAL,
							ACT_CROUCH_IDLE_DUAL,
							ACT_RANGE_ATTACK_DUAL,
							ACT_JUMP_DUAL,
							// Shotgun
							ACT_IDLE_SHOTGUN,
							ACT_IDLE_AIM_SHOTGUN,
							ACT_CROUCH_IDLE_SHOTGUN,
							ACT_JUMP_SHOTGUN,
							// Rifle
							ACT_IDLE_AIM_RIFLE,
							ACT_RELOAD_RIFLE,
							ACT_CROUCH_IDLE_RIFLE,
							ACT_RANGE_ATTACK_RIFLE,
							ACT_JUMP_RIFLE,

							// Infested General AI
							ACT_SLEEP,
							ACT_WAKE,

							// Shield Bug
							ACT_FLICK_LEFT,
							ACT_FLICK_LEFT_MIDDLE,
							ACT_FLICK_RIGHT_MIDDLE,
							ACT_FLICK_RIGHT,
							ACT_SPINAROUND,

							// Mortar Bug
							ACT_PREP_TO_FIRE,
							ACT_FIRE,
							ACT_FIRE_RECOVER,

							// Shaman
							ACT_SPRAY,

							// Boomer
							ACT_PREP_EXPLODE,
							ACT_EXPLODE,

							// this is the end of the global activities, private per-monster activities start here.
							LAST_SHARED_ACTIVITY,
} Activity;

template<class T, class U>
inline T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;
	else if (in >= high)
		return high;
	else
		return in;
}
#define TICK_INTERVAL			( Interfaces.pGlobalVars->interval_per_tick )
#define TIME_TO_TICKS( dt )		( floorf(( 0.5f + (float)(dt) / TICK_INTERVAL ) ) )
#define TICKS_TO_TIME( t )		( TICK_INTERVAL *( t ) )
CBacktrackHelper* g_BacktrackHelper = new CBacktrackHelper;


ConVar* minupdate;
ConVar* maxupdate;
ConVar * updaterate;
ConVar * interprate;
ConVar* cmin;
ConVar* cmax;
ConVar* interp;
float CBacktrackHelper::GetEstimateServerTime()
{
	double v0; // st7@0
	INetChannelInfo* v1; // esi@1
	INetChannelInfo* v2; // eax@1
	float v3; // ST08_4@1
	float v4; // ST0C_4@1

	v1 = (INetChannelInfo*)Interfaces.pEngine->GetNetChannelInfo();
	v2 = (INetChannelInfo*)Interfaces.pEngine->GetNetChannelInfo();

	v3 = v1->GetAvgLatency(1);
	v4 = v2->GetAvgLatency(0);

	//return floorf(((v3 + v4) / g_pGlobals->interval_per_tick) + 0.5f) + 1 + G::UserCmdForBacktracking->tick_count;*/

	return v3 + v4 + TICKS_TO_TIME(1) + TICKS_TO_TIME(Hacks.CurrentCmd->tick_count);

}
float CBacktrackHelper::GetNetworkLatency()
{
	// Get true latency
	INetChannelInfo *nci = Interfaces.pEngine->GetNetChannelInfo();
	if (nci)
	{
		//float IncomingLatency = nci->GetAvgLatency(FLOW_INCOMING); //ppl say use only this one, but meh
		float OutgoingLatency = nci->GetLatency(0);
		return OutgoingLatency;
	}
	return 0.0f;
}
float CBacktrackHelper::GetLerpTime()
{
	if (!minupdate)
		minupdate = Interfaces.g_ICVars->FindVar(XorStr("sv_minupdaterate"));
	if (!maxupdate)
		maxupdate = Interfaces.g_ICVars->FindVar(XorStr("sv_maxupdaterate"));
	if (!updaterate)
		updaterate = Interfaces.g_ICVars->FindVar(XorStr("cl_updaterate"));
	if (!interprate)
		interprate = Interfaces.g_ICVars->FindVar(XorStr("cl_interp_ratio"));
	if (!cmin)
		cmin = Interfaces.g_ICVars->FindVar(XorStr("sv_client_min_interp_ratio"));
	if (!cmax)
		cmax = Interfaces.g_ICVars->FindVar(XorStr("sv_client_max_interp_ratio"));
	if (!interp)
		interp = Interfaces.g_ICVars->FindVar(XorStr("cl_interp"));

	float UpdateRate = updaterate->GetValue();
	float LerpRatio = interprate->GetValue();

	return max(LerpRatio / UpdateRate, interp->GetValue());
}


void CBacktrackHelper::UpdateBacktrackRecords(CBaseEntity* pPlayer)
{
	int i = pPlayer->GetIndex();



	for (int j = g_BacktrackHelper->PlayerRecord[i].records.size() - 1; j >= 0; j--)
	{
		float lerptime = g_BacktrackHelper->GetLerpTime();
		float desired_time = g_BacktrackHelper->PlayerRecord[i].records.at(j).m_flSimulationTime + lerptime;
		float estimated_time = g_BacktrackHelper->GetEstimateServerTime();


		float SV_MAXUNLAG = 1.0f;


		float latency = g_BacktrackHelper->GetNetworkLatency();
		float m_flLerpTime = g_BacktrackHelper->GetLerpTime();
		float correct = clamp<float>(latency + m_flLerpTime, 0.0f, SV_MAXUNLAG);

		float deltaTime = correct - (estimated_time + lerptime - desired_time);

		if (fabs(deltaTime) > 0.2f)
			g_BacktrackHelper->PlayerRecord[i].records.erase(g_BacktrackHelper->PlayerRecord[i].records.begin() + j);
	}


	static Vector old_origin[64];



	if (PlayerRecord[i].records.size() > 0 && pPlayer->GetSimulationTime() == PlayerRecord[i].records.back().m_flSimulationTime) //already got such a record
		return;

	if (PlayerRecord[i].records.size() > 0 && PlayerRecord[i].records.back().m_flSimulationTime > pPlayer->GetSimulationTime())//Invalid lag record, maybe from diffrent game?
	{
		PlayerRecord[i].records.clear();
		return;
	}

	Vector cur_origin = pPlayer->GetAbsOrigin();

	Vector v = cur_origin - old_origin[i];

	bool breaks_lagcomp = v.LengthSqr() > 4096.f;

	old_origin[i] = cur_origin;

	//if (breaks_lagcomp)
	//{
	//add a bool to tick_record called extrapolate and set it to true here, then don't return but let the aimbot extrapolate, for now we just skip that
	//return;
	//}




	tick_record new_record;

	new_record.needs_extrapolation = breaks_lagcomp;

	static float OldLower[64];


	PlayerRecord[i].LowerBodyYawTarget = pPlayer->pelvisangs();




	new_record.m_angEyeAngles = pPlayer->GetEyeAngles();
	new_record.m_flCycle = pPlayer->GetCycle();
	new_record.m_flSimulationTime = pPlayer->GetSimulationTime();
	new_record.m_flAnimTime = pPlayer->GetAnimationTime();
	new_record.bLowerBodyYawUpdated = false;
	new_record.m_nSequence = pPlayer->GetSequence();
	new_record.m_vecOrigin = pPlayer->GetAbsOrigin();
	new_record.m_vecVelocity = pPlayer->GetVecVelocity();
	new_record.m_nFlags = pPlayer->GetFlags();
	new_record.m_flUpdateTime = Interfaces.pGlobalVars->curtime;
	new_record.backtrack_time = new_record.m_flSimulationTime + GetLerpTime();

	if (PlayerRecord[i].LowerBodyYawTarget != OldLower[i] || (pPlayer->GetFlags() & FL_ONGROUND && pPlayer->GetVecOrigin().Length() > 29.f))
		new_record.bLowerBodyYawUpdated = true;

	for (int i = 0; i < 24; i++)
		new_record.m_flPoseParameter[i] = *(float*)((DWORD)pPlayer + offsets.m_flPoseParameter + sizeof(float) * i);

	int sequence = pPlayer->GetSequence();
	if (sequence == Activity::ACT_PLAYER_IDLE_FIRE || sequence == Activity::ACT_PLAYER_RUN_FIRE || sequence == Activity::ACT_PLAYER_WALK_FIRE || sequence == Activity::ACT_PLAYER_CROUCH_FIRE || sequence == Activity::ACT_PLAYER_CROUCH_WALK_FIRE)
	{
		new_record.shot_in_that_record = true;
	}

	pPlayer->SetupBones(new_record.boneMatrix, 128, 0x00000100, Interfaces.pGlobalVars->curtime);



	OldLower[i] = PlayerRecord[i].LowerBodyYawTarget;

	PlayerRecord[i].records.push_back(new_record);

}
void CBacktrackHelper::UpdateExtrapolationRecords(CBaseEntity* pPlayer)
{
	int index = pPlayer->GetIndex();
	if (pPlayer->GetSimulationTime() == this->SimRecord[index][0].simulation_time)
		return;

	for (int i = 7; i > 0; i--)
	{
		this->SimRecord[index][i].acceleration = this->SimRecord[index][i - 1].acceleration;
		this->SimRecord[index][i].origin = this->SimRecord[index][i - 1].origin;
		this->SimRecord[index][i].simulation_time = this->SimRecord[index][i - 1].simulation_time;
		this->SimRecord[index][i].update_time = this->SimRecord[index][i - 1].update_time;
		this->SimRecord[index][i].velocity = this->SimRecord[index][i - 1].velocity;
	}

	this->SimRecord[index][0].simulation_time = pPlayer->GetSimulationTime();
	this->SimRecord[index][0].update_time = Interfaces.pGlobalVars->curtime;
	this->SimRecord[index][0].origin = pPlayer->GetAbsOrigin();

	int lost_ticks = TIME_TO_TICKS(this->SimRecord[index][0].simulation_time) - TIME_TO_TICKS(this->SimRecord[index][1].simulation_time);

	this->SimRecord[index][0].simulation_time_increasment_per_tick = (this->SimRecord[index][0].simulation_time - this->SimRecord[index][1].simulation_time) / lost_ticks;

	/*calculate velocity by ourselves*/
	Vector velocity = this->SimRecord[index][0].origin - this->SimRecord[index][1].origin;
	/*divide through lost ticks to get the velocity per tick*/
	velocity /= lost_ticks;

	this->SimRecord[index][0].velocity = pPlayer->GetVecVelocity();//velocity;

}