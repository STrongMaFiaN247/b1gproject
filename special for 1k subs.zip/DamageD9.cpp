
#include "DamageESP.h"
#include "RenderD9.h"
namespace DamageESP
{
	std::array<FloatingText, MAX_FLOATING_TEXTS> floatingTexts;
	int floatingTextsIdx = 0;

	void HandleGameEvent(IGameEvent* pEvent)
	{
		if (!g_Options.Visuals.Visuals_DamageESP || !(Interfaces.pEngine->IsInGame() && Interfaces.pEngine->IsConnected() && G::LocalPlayer))
			return;

		const char *name = pEvent->GetName();

		static Vector lastImpactPos = Vector(0, 0, 0);

		if (!strcmp(name, ("player_hurt")))
		{
			float curTime =  Interfaces.pGlobalVars->curtime;

			int userid = pEvent->GetInt(("userid"));
			int attackerid = pEvent->GetInt(("attacker"));
			int dmg_health = pEvent->GetInt(("dmg_health"));
			int hitgroup = pEvent->GetInt(("hitgroup"));

			CBaseEntity *entity = Interfaces.pEntList->GetClientEntity(Interfaces.pEngine->GetPlayerForUserID(userid));
			CBaseEntity *attacker = Interfaces.pEntList->GetClientEntity(Interfaces.pEngine->GetPlayerForUserID(attackerid));

			if (!entity || attacker != G::LocalPlayer)
				return;

			FloatingText txt;
			txt.startTime = curTime;
			txt.hitgroup = hitgroup;
			txt.hitPosition = lastImpactPos;
			txt.damage = dmg_health;
			txt.randomIdx = rand() % 5;
			txt.valid = true;

			floatingTexts[floatingTextsIdx++ % MAX_FLOATING_TEXTS] = txt;
		}
		else if (!strcmp(name, ("bullet_impact")))
		{
			int userid = pEvent->GetInt(("userid"));
			float x = pEvent->GetFloat(("x"));
			float y = pEvent->GetFloat(("y"));
			float z = pEvent->GetFloat(("z"));

			CBaseEntity *entity = Interfaces.pEntList->GetClientEntity(Interfaces.pEngine->GetPlayerForUserID(userid));

			if (!entity || entity != G::LocalPlayer)
				return;

			lastImpactPos = Vector(x, y, z);
		}
	}

	void Draw()
	{
		if (!g_Options.Visuals.Visuals_DamageESP)
			return;

		
		for (int i = 0; i < MAX_FLOATING_TEXTS; i++)
		{
			FloatingText *txt = &floatingTexts[i % MAX_FLOATING_TEXTS];

			if (!txt->valid)
				continue;

			float endTime = txt->startTime + 1.1f;

			if (endTime < Interfaces.pGlobalVars->curtime)
			{
				txt->valid = false;
				continue;
			}

			Vector screen;

			if (render->WorldToScreen(txt->hitPosition, screen))
			{
				float t = 1.0f - (endTime - Interfaces.pGlobalVars->curtime) / (endTime - txt->startTime);

				screen.y -= t * (35.0f);
				screen.x -= (float)txt->randomIdx * t * 3.0f;

				char msg[12];
				sprintf_s(msg, 12, "-%dHP", txt->damage);

				int width = render->GetTextWitdh(msg, render->fntVerdana10);

				render->DrawStringWithFont(render->fntVerdana10, screen.x - width / 2, screen.y - 11 + 1, D3D_COLOR_BLACK((int)((1.0f - t) * (float)255)), msg);

				render->DrawStringWithFont(render->fntVerdana10, screen.x - width / 2, screen.y - 11, D3DCOLOR_ARGB(Hacks.Colors.DamageESP.a(), Hacks.Colors.DamageESP.r(), Hacks.Colors.DamageESP.g(), Hacks.Colors.DamageESP.b()), msg);
			}
		}
	}
};
