#pragma once
#include "../stdafx.h"

#define INRANGE(x, a, b)	(x >= a && x <= b)
#define GETBITS(x)			(INRANGE((x&(~0x20)),'A','F') ? ((x&(~0x20)) - 'A' + 0xa) : (INRANGE(x,'0','9') ? x - '0' : 0))
#define GETBYTE(x)			(GETBITS(x[0]) << 4 | GETBITS(x[1]))


class CUtils
{
public:

	uintptr_t FindMemoryPattern(HANDLE ModuleHandle, char* strpattern, int length)
	{
		//double startfilter = QPCTime();
		//Filter out junk and get a clean hex version of the signature
		unsigned char *signature = new unsigned char[length + 1];
		bool *skippable = new bool[length + 1];
		int signaturelength = 0;
		for (int byteoffset = 0; byteoffset < length - 1; byteoffset += 2)
		{
			char charhex[4]; //4 to keep sscanf happy
			*(short*)charhex = *(short*)&strpattern[byteoffset];
			if (charhex[0] != ' ')
			{
				if (charhex[0] == '?')
				{
					signature[signaturelength] = '?';
					skippable[signaturelength] = true;
				}
				else
				{
					//Convert ascii to hex
					charhex[2] = NULL; //add null terminator
					signature[signaturelength] = (unsigned char)std::stoul(charhex, nullptr, 16);

					//sscanf(charhex, "%x", &signature[signaturelength]);
					skippable[signaturelength] = false;
				}
				signaturelength++;
			}
		}
		//double timetakentofilter = QPCTime() - startfilter;

		//Search for the hex signature in memory
		int searchoffset = 0;
		int maxoffset = signaturelength - 1;
		//double timetakentosearch = 0.0;
		//double startsearch = QPCTime();
#if 0
		uintptr_t adr = (uintptr_t)ModuleHandle;
		while (1)
		{
			try {
				unsigned char hextosearch = signature[searchoffset];
				bool skip = hextosearch == '?';
				if (ReadByte(adr) == hextosearch || skip)
				{
					searchoffset++;
					if (searchoffset > maxoffset)
					{
						delete[] signature;
						//timetakentosearch = QPCTime() - startsearch;
						return adr - maxoffset; //FOUND OFFSET!
					}
				}
				else
				{
					searchoffset = 0;
				}
			}
			catch (...) {
				break;
			}
			adr++;
		}
#else
		MODULEINFO dllinfo;
		GetModuleInformation(GetCurrentProcess(), (HMODULE)ModuleHandle, &dllinfo, sizeof(MODULEINFO));
		DWORD endadr = (DWORD)ModuleHandle + dllinfo.SizeOfImage;
		DWORD adrafterfirstmatch = NULL;
		for (DWORD adr = (DWORD)ModuleHandle; adr < endadr; adr++)
		{
			//if (adr == ((DWORD)ModuleHandle + 0x43F57C))
			//	printf("test");

			if (skippable[searchoffset] || *(char*)adr == signature[searchoffset] || *(unsigned char*)adr == signature[searchoffset])
			{
				if (searchoffset == 0)
				{
					adrafterfirstmatch = adr + 1;
				}
				searchoffset++;
				if (searchoffset > maxoffset)
				{
					delete[] signature;
					delete[] skippable;
					//timetakentosearch = QPCTime() - startsearch;
					return adr - maxoffset; //FOUND OFFSET!
				}
			}
			else if (adrafterfirstmatch)
			{
				adr = adrafterfirstmatch;
				searchoffset = 0;
				adrafterfirstmatch = NULL;
			}
		}
#endif
		//timetakentosearch = QPCTime() - startsearch;
		delete[] signature;
		delete[] skippable;
		return NULL; //NOT FOUND!
	}

	inline DWORD FindPatternAimbot(char *pattern, char *mask, DWORD offset, char *moduleName)
	{
		HMODULE hModule;
		MODULEINFO moduleInfo;
		DWORD dModule, dModuleSize;

		hModule = GetModuleHandle(moduleName);
		GetModuleInformation(GetCurrentProcess(), hModule, &moduleInfo, sizeof(MODULEINFO));

		dModule = (DWORD)moduleInfo.lpBaseOfDll;
		dModuleSize = moduleInfo.SizeOfImage;

		DWORD start = dModule;
		DWORD end = dModule + dModuleSize;

		int patternLength = strlen(mask);
		bool found = false;

		for (DWORD i = start; i < end - patternLength; i++)
		{
			found = true;

			for (int idx = 0; idx < patternLength; idx++)
			{
				if (*(mask + idx) == 'x' && *(pattern + idx) != *(char*)(i + idx))
				{
					found = false;
					break;
				}
			}

			if (found)
				return i + offset;
		}
		return NULL;
	}

	std::string GetWorkingPath()
	{
		char szPath[MAX_PATH];

		GetModuleFileNameA(0, szPath, MAX_PATH);

		std::string path(szPath);

		return path.substr(0, path.find_last_of("\\") + 1);
	}
	bool IsFileExists(const std::string& name)
	{
		struct stat buffer;
		return (stat(name.c_str(), &buffer) == 0);
	}
	std::uint8_t* PatternScan(void* module, const char* signature)
	{


		static auto pattern_to_byte = [](const char* pattern) {
			auto bytes = std::vector<int>{};
			auto start = const_cast<char*>(pattern);
			auto end = const_cast<char*>(pattern) + strlen(pattern);

			for (auto current = start; current < end; ++current) {
				if (*current == '?') {
					++current;
					if (*current == '?')
						++current;
					bytes.push_back(-1);
				}
				else {
					bytes.push_back(strtoul(current, &current, 16));
				}
			}
			return bytes;
		};

		auto dosHeader = (PIMAGE_DOS_HEADER)module;
		auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)module + dosHeader->e_lfanew);

		auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
		auto patternBytes = pattern_to_byte(signature);
		auto scanBytes = reinterpret_cast<std::uint8_t*>(module);

		auto s = patternBytes.size();
		auto d = patternBytes.data();

		for (auto i = 0ul; i < sizeOfImage - s; ++i) {
			bool found = true;
			for (auto j = 0ul; j < s; ++j) {
				if (scanBytes[i + j] != d[j] && d[j] != -1) {
					found = false;
					break;
				}
			}
			if (found) {
				return &scanBytes[i];
			}
		}

	
		return nullptr;
	}
	uintptr_t FindSig(std::string moduleName, std::string pattern)
	{
		const char* daPattern = pattern.c_str();
		uintptr_t firstMatch = 0;
		uintptr_t moduleBase = (uintptr_t)GetModuleHandleA(moduleName.c_str());
		MODULEINFO miModInfo; GetModuleInformation(GetCurrentProcess(), (HMODULE)moduleBase, &miModInfo, sizeof(MODULEINFO));
		uintptr_t moduleEnd = moduleBase + miModInfo.SizeOfImage;
		for (uintptr_t pCur = moduleBase; pCur < moduleEnd; pCur++)
		{
			if (!*daPattern)
				return firstMatch;

			if (*(PBYTE)daPattern == '\?' || *(BYTE*)pCur == GETBYTE(daPattern))
			{
				if (!firstMatch)
					firstMatch = pCur;

				if (!daPattern[2])
					return firstMatch;

				if (*(PWORD)daPattern == '\?\?' || *(PBYTE)daPattern != '\?')
					daPattern += 3;

				else
					daPattern += 2;
			}
			else
			{
				daPattern = pattern.c_str();
				firstMatch = 0;
			}
		}
		return 0;
	}

	uint64_t FindPatternIDA(const char* szModule, const char* szSignature)
	{
		//CREDITS: learn_more


		MODULEINFO modInfo;
		GetModuleInformation(GetCurrentProcess(), GetModuleHandleA(szModule), &modInfo, sizeof(MODULEINFO));
		DWORD startAddress = (DWORD)modInfo.lpBaseOfDll;
		DWORD endAddress = startAddress + modInfo.SizeOfImage;
		const char* pat = szSignature;
		DWORD firstMatch = 0;
		for (DWORD pCur = startAddress; pCur < endAddress; pCur++) {
			if (!*pat) return firstMatch;
			if (*(PBYTE)pat == ('\?') || *(BYTE*)pCur == GETBYTE(pat)) {
				if (!firstMatch) firstMatch = pCur;
				if (!pat[2]) return firstMatch;
				if (*(PWORD)pat == ('\?\?') || *(PBYTE)pat != ('\?')) pat += 3;
				else pat += 2;    //one ?
			}
			else {
				pat = szSignature;
				firstMatch = 0;
			}
		}
		return NULL;
	}
	DWORD FindPattern(std::string moduleName, std::string pattern)
	{
		const char* pat = pattern.c_str();
		DWORD firstMatch = 0;
		DWORD rangeStart = (DWORD)GetModuleHandleA(moduleName.c_str());
		MODULEINFO miModInfo;
		GetModuleInformation(GetCurrentProcess(), (HMODULE)rangeStart, &miModInfo, sizeof(MODULEINFO));
		DWORD rangeEnd = rangeStart + miModInfo.SizeOfImage;
		for (DWORD pCur = rangeStart; pCur < rangeEnd; pCur++)
		{
			if (!*pat)
				return firstMatch;

			if (*(PBYTE)pat == '\?' || *(BYTE*)pCur == GETBYTE(pat))
			{
				if (!firstMatch)
					firstMatch = pCur;

				if (!pat[2])
					return firstMatch;

				if (*(PWORD)pat == '\?\?' || *(PBYTE)pat != '\?')
					pat += 3;

				else
					pat += 2; //one ?
			}
			else
			{
				pat = pattern.c_str();
				firstMatch = 0;
			}
		}
		return NULL;
	}

	ULONG PatternSearch(std::string sModuleName, PBYTE pbPattern, std::string sMask, ULONG uCodeBase, ULONG uSizeOfCode)
	{
		BOOL bPatternDidMatch = FALSE;
		HMODULE hModule = GetModuleHandle(sModuleName.c_str());

		if (!hModule)
			return 0x0;

		PIMAGE_DOS_HEADER pDsHeader = PIMAGE_DOS_HEADER(hModule);
		PIMAGE_NT_HEADERS pPeHeader = PIMAGE_NT_HEADERS(LONG(hModule) + pDsHeader->e_lfanew);
		PIMAGE_OPTIONAL_HEADER pOptionalHeader = &pPeHeader->OptionalHeader;

		if (uCodeBase == 0x0)
			uCodeBase = (ULONG)hModule + pOptionalHeader->BaseOfCode;

		if (uSizeOfCode == 0x0)
			uSizeOfCode = pOptionalHeader->SizeOfCode;

		ULONG uArraySize = sMask.length();

		if (!uCodeBase || !uSizeOfCode || !uArraySize)
			return 0x0;

		for (size_t i = uCodeBase; i <= uCodeBase + uSizeOfCode; i++)
		{
			for (size_t t = 0; t < uArraySize; t++)
			{
				if (*((PBYTE)i + t) == pbPattern[t] || sMask.c_str()[t] == '?')
					bPatternDidMatch = TRUE;

				else
				{
					bPatternDidMatch = FALSE;
					break;
				}
			}

			if (bPatternDidMatch)
				return i;
		}

		return 0x0;
	}

	HMODULE GetModuleHandleSafe(const char* pszModuleName)
	{
		HMODULE hmModuleHandle = nullptr;

		do
		{
			hmModuleHandle = GetModuleHandle(pszModuleName);
			Sleep(1);
		} while (hmModuleHandle == nullptr);

		return hmModuleHandle;
	}


	
};

extern CUtils Utils;
