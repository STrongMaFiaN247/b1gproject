#pragma once
#include "stdafx.h"
class CBaseEntity;
class IClientUnknown;
class IClientNetworkable;
class CEntityList
{
public:
	/*virtual void Function0();

	virtual void Function1();

	virtual void Function2();

	virtual CBaseEntity* GetClientEntity( int entnum );

	virtual CBaseEntity* GetClientEntityFromHandle(CBaseHandle hEnt ) = 0;

	virtual int NumberOfEntities( bool bIncludeNonNetworkable ) = 0;

	virtual int GetHighestEntityIndex( void );

	virtual void SetMaxEntities( int maxents );

	virtual int GetMaxEntities();*/


	virtual IClientNetworkable* GetClientNetworkable(int entindex) = 0;
	virtual IClientNetworkable* GetClientNetworkableFromHandle(CBaseHandle entity_handle) = 0;
	virtual IClientUnknown* GetClientUnknownFromHandle(CBaseHandle entity_handle) = 0;
	virtual CBaseEntity* GetClientEntity(int entindex) = 0;
	virtual CBaseEntity* GetClientEntityFromHandle(CBaseHandle entity_handle) = 0;
	virtual int NumberOfEntities(bool include_non_networkable) = 0;
	virtual int GetHighestEntityIndex(void) = 0;
	virtual void SetMaxEntities(int maxents) = 0;
	virtual int GetMaxEntities() = 0;
};
