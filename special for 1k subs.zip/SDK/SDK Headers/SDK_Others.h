#pragma once
#include "stdafx.h"

class CHudChat {
public:
	void ChatPrintf(const char* fmt, ...) {
		va_list va_alist;
		char* szBuffer = new char[2048];
		va_start(va_alist, fmt);
		int len = vsprintf_s(szBuffer, sizeof(szBuffer), fmt, va_alist);
		va_end(va_alist);
		szBuffer[len] = '\0';
		//Util::GetVFunc<void(__cdecl*)(void*, int, int, const char*)>(this, 26)(this, 0, 0, szBuffer);
	}
	

	void ChatPrintfW(const wchar_t* fmt, ...) {
		va_list va_alist;
		wchar_t* wszBuffer = new wchar_t[2048];
		va_start(va_alist, fmt);
		int len = vswprintf_s(wszBuffer, 2048, fmt, va_alist);
		va_end(va_alist);
		wszBuffer[len] = L'\0';
		//Util::GetVFunc<void(__thiscall*)(void*, int, int, const wchar_t*)>(this, 27)(this, 0, 0, wszBuffer);
	}


};

class IClientModeShared {
public:
	char __pad[0x1C];
	CHudChat* m_pChatElement;
};
inline void VectorSubtract( const Vector& a, const Vector& b, Vector& c )
{
	CHECK_VALID(a);
	CHECK_VALID(b);
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	c.z = a.z - b.z;
}

//SRC SDK VECTORADD
inline void VectorAdd( const Vector& a, const Vector& b, Vector& c )
{
	CHECK_VALID(a);
	CHECK_VALID(b);
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	c.z = a.z + b.z;
}

class bf_write
{
public:
	bf_write();

	// nMaxBits can be used as the number of bits in the buffer. 
	// It must be <= nBytes*8. If you leave it at -1, then it's set to nBytes * 8.
	bf_write( void* pData, int nBytes, int nMaxBits = -1 );

	bf_write( const char* pDebugName, void* pData, int nBytes, int nMaxBits = -1 );

	// Start writing to the specified buffer.
	// nMaxBits can be used as the number of bits in the buffer. 
	// It must be <= nBytes*8. If you leave it at -1, then it's set to nBytes * 8.
	void StartWriting( void* pData, int nBytes, int iStartBit = 0, int nMaxBits = -1 );

	// Restart buffer writing.
	void Reset();

	// Get the base pointer.
	unsigned char* GetBasePointer()
	{
		return ( unsigned char* )m_pData;
	}

	// Enable or disable assertion on overflow. 99% of the time, it's a bug that we need to catch,
	// but there may be the occasional buffer that is allowed to overflow gracefully.
	void SetAssertOnOverflow( bool bAssert );

	// This can be set to assign a name that gets output if the buffer overflows.
	const char* GetDebugName();

	void SetDebugName( const char* pDebugName );

	// Seek to a specific position.
public:

	void SeekToBit( int bitPos );

	// Bit functions.
public:

	void WriteOneBit( int nValue );

	void WriteOneBitNoCheck( int nValue );

	void WriteOneBitAt( int iBit, int nValue );

	// Write signed or unsigned. Range is only checked in debug.
	void WriteUBitLong( unsigned int data, int numbits, bool bCheckRange = true );

	void WriteSBitLong( int data, int numbits );

	// Tell it whether or not the data is unsigned. If it's signed,
	// cast to unsigned before passing in (it will cast back inside).
	void WriteBitLong( unsigned int data, int numbits, bool bSigned );

	// Write a list of bits in.
	bool WriteBits( const void* pIn, int nBits );

	// writes an unsigned integer with variable bit length
	void WriteUBitVar( unsigned int data );

	// writes a varint encoded integer
	void WriteVarInt32( uint32 data );

	void WriteVarInt64( uint64 data );

	void WriteSignedVarInt32( int32 data );

	void WriteSignedVarInt64( int64 data );

	int ByteSizeVarInt32( uint32 data );

	int ByteSizeVarInt64( uint64 data );

	int ByteSizeSignedVarInt32( int32 data );

	int ByteSizeSignedVarInt64( int64 data );

	// Copy the bits straight out of pIn. This seeks pIn forward by nBits.
	// Returns an error if this buffer or the read buffer overflows.
	bool WriteBitsFromBuffer( class bf_read* pIn, int nBits );

	void WriteBitAngle( float fAngle, int numbits );

	void WriteBitCoord( const float f );

	void WriteBitCoordMP( const float f, bool bIntegral, bool bLowPrecision );

	void WriteBitFloat( float val );

	void WriteBitVec3Coord( const Vector& fa );

	void WriteBitNormal( float f );

	void WriteBitVec3Normal( const Vector& fa );

	void WriteBitAngles( const Vector& fa );

	// Byte functions.
public:

	void WriteChar( int val );

	void WriteByte( int val );

	void WriteShort( int val );

	void WriteWord( int val );

	void WriteLong( long val );

	void WriteLongLong( int64 val );

	void WriteFloat( float val );

	bool WriteBytes( const void* pBuf, int nBytes );

	// Returns false if it overflows the buffer.
	bool WriteString( const char* pStr );

	// Status.
public:

	// How many bytes are filled in?
	int GetNumBytesWritten() const;

	int GetNumBitsWritten() const;

	int GetMaxNumBits();

	int GetNumBitsLeft();

	int GetNumBytesLeft();

	unsigned char* GetData();

	const unsigned char* GetData() const;

	// Has the buffer overflowed?
	bool CheckForOverflow( int nBits );

	inline bool IsOverflowed() const
	{
		return m_bOverflow;
	}

	void SetOverflowFlag();

public:
	// The current buffer.
	unsigned long* m_pData;
	int m_nDataBytes;
	int m_nDataBits;

	// Where we are in the buffer.
	int m_iCurBit;

private:

	// Errors?
	bool m_bOverflow;

	bool m_bAssertOnOverflow;
	const char* m_pDebugName;
};

enum weapons
{
	weapon_deagle = 1,
	weapon_elite = 2,
	weapon_fiveseven = 3,
	weapon_glock = 4,
	weapon_ak47 = 7,
	weapon_aug = 8,
	weapon_awp = 9,
	weapon_famas = 10,
	weapon_g3sg1 = 11,
	weapon_galilar = 13,
	weapon_m249 = 14,
	weapon_m4a1 = 16,
	weapon_mac10 = 17,
	weapon_p90 = 19,
	weapon_ump = 24,
	weapon_xm1014 = 25,
	weapon_bizon = 26,
	weapon_mag7 = 27,
	weapon_negev = 28,
	weapon_sawedoff = 29,
	weapon_tec9 = 30,
	weapon_taser = 31,
	weapon_hkp2000 = 32,
	weapon_mp7 = 33,
	weapon_mp9 = 34,
	weapon_nova = 35,
	weapon_p250 = 36,
	weapon_scar20 = 38,
	weapon_sg556 = 39,
	weapon_ssg08 = 40,
	weapon_knife = 42,
	weapon_flashbang = 43,
	weapon_hegrenade = 44,
	weapon_smokegrenade = 45,
	weapon_molotov = 46,
	weapon_decoy = 47,
	weapon_incgrenade = 48,
	weapon_c4 = 49,
	weapon_knife_t = 59,
	weapon_m4a1_silencer = 60,
	weapon_usp_silencer = 61,
	weapon_cz75a = 63,
	weapon_revolver = 64,
	weapon_bayonet = 500,
	weapon_knife_flip = 505,
	weapon_knife_gut = 506,
	weapon_knife_karambit = 507,
	weapon_knife_m9_bayonet = 508,
	weapon_knife_tactical = 509,
	weapon_knife_falchion = 512,
	weapon_knife_survival_bowie = 514,
	weapon_knife_butterfly = 515,
	weapon_knife_push = 516
};

enum EClassIds
{
	_CAI_BaseNPC = 0,
	_CAK47,
	_CBaseAnimating,
	_CBaseAnimatingOverlay,
	_CBaseAttributableItem,
	_CBaseButton,
	_CBaseCombatCharacter,
	_CBaseCombatWeapon,
	_CBaseCSGrenade,
	_CBaseCSGrenadeProjectile,
	_CBaseDoor,
	_CBaseEntity,
	_CBaseFlex,
	_CBaseGrenade,
	_CBaseParticleEntity,
	_CBasePlayer,
	_CBasePropDoor,
	_CBaseTeamObjectiveResource,
	_CBaseTempEntity,
	_CBaseToggle,
	_CBaseTrigger,
	_CBaseViewModel,
	_CBaseVPhysicsTrigger,
	_CBaseWeaponWorldModel,
	_CBeam,
	_CBeamSpotlight,
	_CBoneFollower,
	_CBreakableProp,
	_CBreakableSurface,
	_CC4,
	_CCascadeLight,
	_CChicken,
	_CColorCorrection,
	_CColorCorrectionVolume,
	_CCSGameRulesProxy,
	_CCSPlayer,
	_CCSPlayerResource,
	_CCSRagdoll,
	_CCSTeam,
	_CDEagle,
	_CDecoyGrenade,
	_CDecoyProjectile,
	_CDynamicLight,
	_CDynamicProp,
	_CEconEntity,
	_CEmbers,
	_CEntityDissolve,
	_CEntityFlame,
	_CEntityFreezing,
	_CEntityParticleTrail,
	_CEnvAmbientLight,
	_CEnvDetailController,
	_CEnvDOFController,
	_CEnvParticleScript,
	_CEnvProjectedTexture,
	_CEnvQuadraticBeam,
	_CEnvScreenEffect,
	_CEnvScreenOverlay,
	_CEnvTonemapController,
	_CEnvWind,
	_CFireCrackerBlast,
	_CFireSmoke,
	_CFireTrail,
	_CFish,
	_CFlashbang,
	_CFogController,
	_CFootstepControl,
	_CFunc_Dust,
	_CFunc_LOD,
	_CFuncAreaPortalWindow,
	_CFuncBrush,
	_CFuncConveyor,
	_CFuncLadder,
	_CFuncMonitor,
	_CFuncMoveLinear,
	_CFuncOccluder,
	_CFuncReflectiveGlass,
	_CFuncRotating,
	_CFuncSmokeVolume,
	_CFuncTrackTrain,
	_CGameRulesProxy,
	_CHandleTest,
	_CHEGrenade,
	_CHostage,
	_CHostageCarriableProp,
	_CIncendiaryGrenade,
	_CInferno,
	_CInfoLadderDismount,
	_CInfoOverlayAccessor,
	_CItem_Healthshot,
	_CKnife,
	_CKnifeGG,
	_CLightGlow,
	_CMaterialModifyControl,
	_CMolotovGrenade,
	_CMolotovProjectile,
	_CMovieDisplay,
	_CParticleFire,
	_CParticlePerformanceMonitor,
	_CParticleSystem,
	_CPhysBox,
	_CPhysBoxMultiplayer,
	_CPhysicsProp,
	_CPhysicsPropMultiplayer,
	_CPhysMagnet,
	_CPlantedC4,
	_CPlasma,
	_CPlayerResource,
	_CPointCamera,
	_CPointCommentaryNode,
	_CPoseController,
	_CPostProcessController,
	_CPrecipitation,
	_CPrecipitationBlocker,
	_CPredictedViewModel,
	_CProp_Hallucination,
	_CPropDoorRotating,
	_CPropJeep,
	_CPropVehicleDriveable,
	_CRagdollManager,
	_CRagdollProp,
	_CRagdollPropAttached,
	_CRopeKeyframe,
	_CSCAR17,
	_CSceneEntity,
	_CSensorGrenade,
	_CSensorGrenadeProjectile,
	_CShadowControl,
	_CSlideshowDisplay,
	_CSmokeGrenade,
	_CSmokeGrenadeProjectile,
	_CSmokeStack,
	_CSpatialEntity,
	_CSpotlightEnd,
	_CSprite,
	_CSpriteOriented,
	_CSpriteTrail,
	_CStatueProp,
	_CSteamJet,
	_CSun,
	_CSunlightShadowControl,
	_CTeam,
	_CTeamplayRoundBasedRulesProxy,
	_CTEArmorRicochet,
	_CTEBaseBeam,
	_CTEBeamEntPoint,
	_CTEBeamEnts,
	_CTEBeamFollow,
	_CTEBeamLaser,
	_CTEBeamPoints,
	_CTEBeamRing,
	_CTEBeamRingPoint,
	_CTEBeamSpline,
	_CTEBloodSprite,
	_CTEBloodStream,
	_CTEBreakModel,
	_CTEBSPDecal,
	_CTEBubbles,
	_CTEBubbleTrail,
	_CTEClientProjectile,
	_CTEDecal,
	_CTEDust,
	_CTEDynamicLight,
	_CTEEffectDispatch,
	_CTEEnergySplash,
	_CTEExplosion,
	_CTEFireBullets,
	_CTEFizz,
	_CTEFootprintDecal,
	_CTEFoundryHelpers,
	_CTEGaussExplosion,
	_CTEGlowSprite,
	_CTEImpact,
	_CTEKillPlayerAttachments,
	_CTELargeFunnel,
	_CTEMetalSparks,
	_CTEMuzzleFlash,
	_CTEParticleSystem,
	_CTEPhysicsProp,
	_CTEPlantBomb,
	_CTEPlayerAnimEvent,
	_CTEPlayerDecal,
	_CTEProjectedDecal,
	_CTERadioIcon,
	_CTEShatterSurface,
	_CTEShowLine,
	_CTesla,
	_CTESmoke,
	_CTESparks,
	_CTESprite,
	_CTESpriteSpray,
	_CTest_ProxyToggle_Networkable,
	_CTestTraceline,
	_CTEWorldDecal,
	_CTriggerPlayerMovement,
	_CTriggerSoundOperator,
	_CVGuiScreen,
	_CVoteController,
	_CWaterBullet,
	_CWaterLODControl,
	_CWeaponAug,
	_CWeaponAWP,
	_CWeaponBaseItem,
	_CWeaponBizon,
	_CWeaponCSBase,
	_CWeaponCSBaseGun,
	_CWeaponCycler,
	_CWeaponElite,
	_CWeaponFamas,
	_CWeaponFiveSeven,
	_CWeaponG3SG1,
	_CWeaponGalil,
	_CWeaponGalilAR,
	_CWeaponGlock,
	_CWeaponHKP2000,
	_CWeaponM249,
	_CWeaponM3,
	_CWeaponM4A1,
	_CWeaponMAC10,
	_CWeaponMag7,
	_CWeaponMP5Navy,
	_CWeaponMP7,
	_CWeaponMP9,
	_CWeaponNegev,
	_CWeaponNOVA,
	_CWeaponP228,
	_CWeaponP250,
	_CWeaponP90,
	_CWeaponSawedoff,
	_CWeaponSCAR20,
	_CWeaponScout,
	_CWeaponSG550,
	_CWeaponSG552,
	_CWeaponSG556,
	_CWeaponSSG08,
	_CWeaponTaser,
	_CWeaponTec9,
	_CWeaponTMP,
	_CWeaponUMP45,
	_CWeaponUSP,
	_CWeaponXM1014,
	_CWorld,
	_DustTrail,
	_MovieExplosion,
	_ParticleSmokeGrenade,
	_RocketTrail,
	_SmokeTrail,
	_SporeExplosion,
	_SporeTrail,
};

/*//USERCMD OFFSETS
#define USERCMDOFFSET 0xEC
#define VERIFIEDCMDOFFSET 0xF0
#define MULTIPLAYER_BACKUP 150
#define CURRENTCOMMANDOFFSET 0x16E8
#define CURRENTPLAYERCOMMANDOFFSET 0x1640
#define PREIDCTIONSEEDOFFSET 0x30
#define PREDICTIONPLAYEROFFSET 0x54
#define GLOBALSOFFSET 0x1B
#define WEAPONDATA_MAXRANGEOFFSET 0x77C
#define WEAPONDATA_DAMAGEOFFSET 0x778
#define WEAPONDATA_RANGEMODIFIEROFFSET 0x780
#define WEAPONDATA_PENETRATIONPOWEROFFSET 0x774
#define INPUTOFFSET 0x5F
#define GETSPREADOFFSET 0x740
#define GETCONEOFFSET 0x744
#define UPDATEACCURACYPENALTYOFFSET 0x748
#define WEAPONIDOFFSET 0x6D8
#define WEAPONDATAOFFSET 0x708
#define GETNAMEOFFSET 0x5CC
#define APPSYSTEMFACTORYOFFSET 0x3D
#define CLIENTFACTORYOFFSET 0x75
#define GLOWINDEXOFFSET 0x1DB8*/

//LIFESTATE
#define	LIFE_ALIVE				0
#define	LIFE_DYING				1
#define	LIFE_DEAD				2
#define LIFE_RESPAWNABLE		3
#define LIFE_DISCARDBODY		4

//Player flags
#define	FL_ONGROUND				(1<<0)	// At rest / on the ground
#define FL_DUCKING				(1<<1)	// Player flag -- Player is fully crouched
#define	FL_WATERJUMP			(1<<3)	// player jumping out of water
#define FL_ONTRAIN				(1<<4) // Player is _controlling_ a train, so movement commands should be ignored on client during prediction.
#define FL_INRAIN				(1<<5)	// Indicates the entity is standing in rain
#define FL_FROZEN				(1<<6) // Player is frozen for 3rd person camera
#define FL_ATCONTROLS			(1<<7) // Player can't move, but keeps key inputs for controlling another entity
#define	FL_CLIENT				(1<<8)	// Is a player
#define FL_FAKECLIENT			(1<<9)	// Fake client, simulated server side; don't send network messages to them
#define	FL_INWATER				(1<<10)	// In water

//USERCMD BUTTONS
#define IN_ATTACK		(1 << 0)
#define IN_JUMP			(1 << 1)
#define IN_DUCK			(1 << 2)
#define IN_FORWARD		(1 << 3)
#define IN_BACK			(1 << 4)
#define IN_USE			(1 << 5)
#define IN_CANCEL		(1 << 6)
#define IN_LEFT			(1 << 7)
#define IN_RIGHT		(1 << 8)
#define IN_MOVELEFT		(1 << 9)
#define IN_MOVERIGHT	(1 << 10)
#define IN_ATTACK2		(1 << 11)
#define IN_RUN			(1 << 12)
#define IN_RELOAD		(1 << 13)
#define IN_ALT1			(1 << 14)
#define IN_ALT2			(1 << 15)
#define IN_SCORE		(1 << 16)   // Used by client.dll for when scoreboard is held down
#define IN_SPEED		(1 << 17)	// Player is holding the speed key
#define IN_WALK			(1 << 18)	// Player holding walk key
#define IN_ZOOM			(1 << 19)	// Zoom key for HUD zoom
#define IN_WEAPON1		(1 << 20)	// weapon defines these bits
#define IN_WEAPON2		(1 << 21)	// weapon defines these bits
#define IN_BULLRUSH		(1 << 22)
#define IN_GRENADE1		(1 << 23)	// grenade 1
#define IN_GRENADE2		(1 << 24)	// grenade 2

enum ClientFrameStage_t
{
	FRAME_UNDEFINED = -1, // (haven't run any frames yet)
	FRAME_START,

	// A network packet is being recieved
	FRAME_NET_UPDATE_START,
	// Data has been received and we're going to start calling PostDataUpdate
	FRAME_NET_UPDATE_POSTDATAUPDATE_START,
	// Data has been received and we've called PostDataUpdate on all data recipients
	FRAME_NET_UPDATE_POSTDATAUPDATE_END,
	// We've received all packets, we can now do interpolation, prediction, etc..
	FRAME_NET_UPDATE_END,

	// We're about to start rendering the scene
	FRAME_RENDER_START,
	// We've finished rendering the scene.
	FRAME_RENDER_END
};

struct mstudiobbox_t
{
	int bone;
	int group; // intersection group
	Vector bbmin; // bounding box 
	Vector bbmax;
	int hitboxnameindex; // offset to the name of the hitbox.
	int pad[3];
	float radius;
	int pad2[4];
	char* getHitboxName()
	{
		if( hitboxnameindex == 0 )
			return "";

		return ( ( char* )this ) + hitboxnameindex;
	}
};

struct mstudiohitboxset_t
{
	int sznameindex;

	inline char* const pszName( void ) const
	{
		return ( ( char* )this ) + sznameindex;
	}

	int numhitboxes;
	int hitboxindex;

	inline mstudiobbox_t* pHitbox( int i ) const
	{
		return ( mstudiobbox_t* )( ( ( BYTE* )this ) + hitboxindex ) + i;
	};

};

struct mstudiobone_t
{
	int sznameindex;

	inline char* const GetName( void ) const
	{
		return ( ( char * )this ) + sznameindex;
	}

	int parent;
	int bonecontroller[6];

	Vector pos;
	float quat[4];
	Vector rot;
	Vector posscale;
	Vector rotscale;

	matrix3x4 poseToBone;
	float qAlignment[4];
	int flags;
	int proctype;
	int procindex; // procedural rule
	mutable int physicsbone; // index into physically simulated bone
	inline void* GetProcedure() const
	{
		if( procindex == 0 )
			return nullptr;
		else
			return ( void * )( ( ( byte * )this ) + procindex );
	};

	int surfacepropidx; // index into string tablefor property name
	inline char* const GetSurfaceProps( void ) const
	{
		return ( ( char * )this ) + surfacepropidx;
	}

	int contents; // See BSPFlags.h for the contents flags

	int unused[8]; // remove as appropriate
};

struct studiohdr_t
{
	int id;
	int version;

	int checksum;

	char name[64];
	int length;

	Vector eyeposition;

	Vector illumposition;

	Vector hull_min;
	Vector hull_max;

	Vector view_bbmin;
	Vector view_bbmax;

	int flags;

	int numbones;
	int boneindex;

	inline mstudiobone_t* GetBone( int i ) const
	{
		return ( mstudiobone_t * )( ( ( byte * )this ) + boneindex ) + i;
	};

	//	inline mstudiobone_t *pBone(int i) const { Assert(i >= 0 && i < numbones); return (mstudiobone_t *)(((byte *)this) + boneindex) + i; };

	int numbonecontrollers;
	int bonecontrollerindex;

	int numhitboxsets;
	int hitboxsetindex;

	mstudiohitboxset_t* GetHitboxSet( int i ) const
	{
		return ( mstudiohitboxset_t* )( ( ( byte* )this ) + hitboxsetindex ) + i;
	}
	inline mstudiobbox_t *pHitbox(int i, int set) const
	{
		mstudiohitboxset_t const *s = GetHitboxSet(set);
		if (!s)
			return NULL;

		return s->pHitbox(i);
	};
	inline mstudiobbox_t* GetHitbox( int i, int set ) const
	{
		mstudiohitboxset_t const* s = GetHitboxSet( set );

		if( !s )
			return nullptr;

		return s->pHitbox( i );
	}

	inline int GetHitboxCount( int set ) const
	{
		mstudiohitboxset_t const* s = GetHitboxSet( set );

		if( !s )
			return 0;

		return s->numhitboxes;
	}

	int numlocalanim;
	int localanimindex;

	int numlocalseq;
	int localseqindex;

	mutable int activitylistversion;
	mutable int eventsindexed;

	int numtextures;
	int textureindex;

	int numcdtextures;
	int cdtextureindex;

	int numskinref;
	int numskinfamilies;
	int skinindex;

	int numbodyparts;
	int bodypartindex;

	int numlocalattachments;
	int localattachmentindex;

	int numlocalnodes;
	int localnodeindex;
	int localnodenameindex;

	int numflexdesc;
	int flexdescindex;

	int numflexcontrollers;
	int flexcontrollerindex;

	int numflexrules;
	int flexruleindex;

	int numikchains;
	int ikchainindex;

	int nummouths;
	int mouthindex;

	int numlocalposeparameters;
	int localposeparamindex;

	int surfacepropindex;

	int keyvalueindex;
	int keyvaluesize;

	int numlocalikautoplaylocks;
	int localikautoplaylockindex;

	float mass;
	int contents;

	int numincludemodels;
	int includemodelindex;

	mutable void* virtualModel;

	int szanimblocknameindex;
	int numanimblocks;
	int animblockindex;

	mutable void* animblockModel;

	int bonetablebynameindex;

	void* pVertexBase;
	void* pIndexBase;

	byte constdirectionallightdot;

	byte rootLOD;

	byte numAllowedRootLODs;

	byte unused[1];

	int unused4;

	int numflexcontrollerui;
	int flexcontrolleruiindex;
	float flVertAnimFixedPointScale;
	int unused3[1];
	int studiohdr2index;
	int unused2[1];
};

class CBaseEntity;

typedef struct
{
	byte r, g, b, a;
} color32;


class CClockDriftMgr
{
public:
	float m_ClockOffsets[17];   //0x0000
	uint32_t m_iCurClockOffset; //0x0044
	uint32_t m_nServerTick;     //0x0048
	uint32_t m_nClientTick;     //0x004C
}; //Size: 0x0050
class CBaseClientState
{
public:
	void ForceFullUpdate()
	{
		*(uint32_t*)((uintptr_t)this + 0x174) = -1;
	}

	char pad_0000[156];             //0x0000
	uint32_t m_NetChannel;          //0x009C
	uint32_t m_nChallengeNr;        //0x00A0
	char pad_00A4[100];             //0x00A4
	uint32_t m_nSignonState;        //0x0108
	char pad_010C[8];               //0x010C
	float m_flNextCmdTime;          //0x0114
	uint32_t m_nServerCount;        //0x0118
	uint32_t m_nCurrentSequence;    //0x011C
	char pad_0120[8];               //0x0120
	CClockDriftMgr m_ClockDriftMgr; //0x0128
	uint32_t m_nDeltaTick;          //0x0178
	bool m_bPaused;                 //0x017C
	char pad_017D[3];               //0x017D
	uint32_t m_nViewEntity;         //0x0180
	uint32_t m_nPlayerSlot;         //0x0184
	char m_szLevelName[260];        //0x0188
	char m_szLevelNameShort[40];    //0x028C
	char m_szGroupName[40];         //0x02B4
	char pad_02DC[52];              //0x02DC
	uint32_t m_nMaxClients;         //0x0310
	char pad_0314[18820];           //0x0314
	float m_flLastServerTickTime;   //0x4C98
	bool insimulation;              //0x4C9C
	char pad_4C9D[3];               //0x4C9D
	uint32_t oldtickcount;          //0x4CA0
	float m_tickRemainder;          //0x4CA4
	float m_frameTime;              //0x4CA8
	uint32_t lastoutgoingcommand;   //0x4CAC
	uint32_t chokedcommands;        //0x4CB0
	uint32_t last_command_ack;      //0x4CB4
	uint32_t command_ack;           //0x4CB8
	uint32_t m_nSoundSequence;      //0x4CBC
	char pad_4CC0[80];              //0x4CC0
	Vector viewangles;              //0x4D10
};