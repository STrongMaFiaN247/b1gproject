#pragma once
#include "../../stdafx.h"
#include <array>
#include "../../Offsets.h"
#include "CTrace.h"
#define BONE_USED_BY_HITBOX 0x00000100



class CAnimationLayer
{
public:
	char  pad_0000[20];
	uint32_t m_nOrder; //0x0014
	uint32_t m_nSequence; //0x0018
	float_t m_flPrevCycle; //0x001C
	float_t m_flWeight; //0x0020
	float_t m_flWeightDeltaRate; //0x0024
	float_t m_flPlaybackRate; //0x0028
	float_t m_flCycle; //0x002C
	void *m_pOwner; //0x0030 // player's thisptr
	char  pad_0038[4]; //0x0034
}; //Size: 0x0038

enum
{
	deagle = 1,
	p2000 = 32,
	fiveseven = 3,
	glock = 4,
	dualelites = 2,
	ak = 7,
	aug = 8,
	awp = 9,
	famas = 10,
	g3sg1 = 11,
	galil = 13,
	p250 = 36,
	tec9 = 30,
	m249 = 14,
	m4 = 16,
	mac10 = 17,
	p90 = 19,
	ump45 = 24,
	ppbizon = 26,
	negev = 28,
	mp7 = 33,
	mp9 = 34,
	scar30 = 38,
	sg553 = 39,
	ssg08 = 40,
	goldknife = 41,
	ctknife = 42,
	tknife = 59,
	flashgren = 43,
	hegren = 44,
	smoke = 45,
	molotov = 46,
	incendiary = 48,
	decoygren = 47,
	bomb = 49,
	nova = 35,
	xm1014 = 25,
	sawedoff = 29,
	mag7 = 27,
	zeus = 31
};

enum eWeaponType1
{
	WEAPON_NONE,
	WEAPON_DEAGLE = 1,
	WEAPON_ELITE = 2,
	WEAPON_FIVESEVEN = 3,
	WEAPON_GLOCK = 4,
	WEAPON_AK47 = 7,
	WEAPON_AUG = 8,
	WEAPON_AWP = 9,
	WEAPON_FAMAS = 10,
	WEAPON_G3SG1 = 11,
	WEAPON_GALILAR = 13,
	WEAPON_M249 = 14,
	WEAPON_M4A1 = 16,
	WEAPON_MAC10 = 17,
	WEAPON_P90 = 19,
	WEAPON_UMP45 = 24,
	WEAPON_XM1014 = 25,
	WEAPON_BIZON = 26,
	WEAPON_MAG7 = 27,
	WEAPON_NEGEV = 28,
	WEAPON_SAWEDOFF = 29,
	WEAPON_TEC9 = 30,
	WEAPON_TASER = 31,
	WEAPON_HKP2000 = 32,
	WEAPON_MP7 = 33,
	WEAPON_MP9 = 34,
	WEAPON_NOVA = 35,
	WEAPON_P250 = 36,
	WEAPON_SCAR20 = 38,
	WEAPON_SG556 = 39,
	WEAPON_SSG08 = 40,
	WEAPON_KNIFE = 42,
	WEAPON_FLASHBANG = 43,
	WEAPON_HEGRENADE = 44,
	WEAPON_SMOKEGRENADE = 45,
	WEAPON_MOLOTOV = 46,
	WEAPON_DECOY = 47,
	WEAPON_INCGRENADE = 48,
	WEAPON_C4 = 49,
	WEAPON_KNIFE_T = 59,
	WEAPON_M4A1_SILENCER = 60,
	WEAPON_USP_SILENCER = 61,
	WEAPON_CZ75A = 63,
	WEAPON_REVOLVER = 64,
	WEAPON_KNIFE_BAYONET = 500,
	WEAPON_KNIFE_FLIP = 505,
	WEAPON_KNIFE_GUT = 506,
	WEAPON_KNIFE_KARAMBIT = 507,
	WEAPON_KNIFE_M9_BAYONET = 508,
	WEAPON_KNIFE_TACTICAL = 509,
	WEAPON_KNIFE_FALCHION = 512,
	WEAPON_KNIFE_SURVIVAL_BOWIE = 514,
	WEAPON_KNIFE_BUTTERFLY = 515,
	WEAPON_KNIFE_PUSH = 516
};


enum class CSGOHitboxID
{
	HITBOX_HEAD,
	HITBOX_NECK,
	HITBOX_PELVIS,
	HITBOX_BELLY,
	HITBOX_THORAX,
	HITBOX_LOWER_CHEST,
	HITBOX_UPPER_CHEST,
	HITBOX_RIGHT_THIGH,
	HITBOX_LEFT_THIGH,
	HITBOX_RIGHT_CALF,
	HITBOX_LEFT_CALF,
	HITBOX_RIGHT_FOOT,
	HITBOX_LEFT_FOOT,
	HITBOX_RIGHT_HAND,
	HITBOX_LEFT_HAND,
	HITBOX_RIGHT_UPPER_ARM,
	HITBOX_RIGHT_FOREARM,
	HITBOX_LEFT_UPPER_ARM,
	HITBOX_LEFT_FOREARM,
	HITBOX_MAX
};
class CCSBomb
{
public:
	float GetC4DefuseCountDown();
};

class CBaseEntity;

class CCSWeaponInfo
{
public:
	char _0x0000[20];
	__int32 max_clip;	//0x0014 
	char _0x0018[12];
	__int32 max_reserved_ammo;	//0x0024 
	char _0x0028[96];
	char* hud_name;//0x0088 
	char* weapon_name;	//0x008C 
	char _0x0090[60];
	__int32 type;//0x00CC 
	__int32 price;//0x00D0 
	__int32 reward;//0x00D4 
	char _0x00D8[20];
	BYTE full_auto;//0x00EC 
	char _0x00ED[3];
	__int32 damage;//0x00F0 
	float armor_ratio;	//0x00F4 
	__int32 bullets;	//0x00F8 
	float penetration;	//0x00FC 
	char _0x0100[8];
	float range;//0x0108 
	float range_modifier;//0x010C 
	char _0x0110[16];
	BYTE silencer;//0x0120 
	char _0x0121[15];
	float max_speed;	//0x0130 
	float max_speed_alt;//0x0134 
	char _0x0138[76];
	__int32 recoil_seed;//0x0184 
	char _0x0188[32];

};


class CBaseCombatWeapon;

struct datamap_t;
class typedescription_t;

enum
{
	TD_OFFSET_NORMAL = 0,
	TD_OFFSET_PACKED = 1,

	// Must be last
	TD_OFFSET_COUNT,
};

class typedescription_t
{
public:
	int32_t fieldType; //0x0000
	char* fieldName; //0x0004
	int fieldOffset[TD_OFFSET_COUNT]; //0x0008
	int16_t fieldSize_UNKNWN; //0x0010
	int16_t flags_UNKWN; //0x0012
	char pad_0014[12]; //0x0014
	datamap_t* td; //0x0020
	char pad_0024[24]; //0x0024
}; //Size: 0x003C
struct datamap_t
{
	typedescription_t    *dataDesc;
	int                    dataNumFields;
	char const            *dataClassName;
	datamap_t            *baseMap;

	bool                chains_validated;
	// Have the "packed" offsets been computed
	bool                packed_offsets_computed;
	int                    packed_size;
};

struct VarMapping_t;
#define OFFSET_FUNC_GET_MAKE(TYPE,NAME,OFFSET) inline TYPE& NAME() { return *(TYPE*)((uintptr_t)this + OFFSET); }
#define OFFSET_FUNC_SET_MAKE(TYPE,NAME,VAL,OFFSET) inline void NAME(TYPE VAL) { *(TYPE*)((uintptr_t)this + OFFSET) = VAL; }
#define OFFSET_FUNC_MAKE_BUFFER(TYPE,SIZE,NAME,BUFFER,OFFSET) void NAME(TYPE *BUFFER) { byte *ptr = (byte*)this + OFFSET; memcpy(BUFFER, ptr, SIZE);BUFFER[SIZE-1]='\0'; }
#define OFFSET_FUNC_GET_SET_MAKE(TYPE,NAME,OFFSET) OFFSET_FUNC_GET_MAKE(TYPE,Get##NAME,OFFSET) OFFSET_FUNC_SET_MAKE(TYPE,Set##NAME,val,OFFSET)
class CBaseEntity : public IClientUnknown, public IClientRenderable, public IClientNetworkable
{
public:
	void SetAbsAngles(const Vector &angles);
	void SetAbsOrigin(const Vector &origin);

	
	OFFSET_FUNC_GET_SET_MAKE(float, DuckAmount3, 0x2F9C)

	std::array<float, 24> &m_flPoseParameter();
	
	CAnimationLayer *GetAnimOverlaysAARec()
	{
		return *(CAnimationLayer**)((DWORD)this + 10608);
	}
	CAnimationLayer *CBaseEntity::GetAnimOverlayAARec(int index)
	{
		if (index < 15)
			return &GetAnimOverlaysAARec()[index];
		else
			return NULL;
	}
	CBaseHandle GetObserverTarget();
	void InvalidateBoneCache();
	int GetSequence();
	VarMapping_t *VarMapping();
	int GetSequenceActivity(int sequence);
	bool IsEnemy();
	bool IsVisible(int bone);
	bool IsVisibleVector(Vector bone);
	IClientRenderable* GetRenderable();
	int DrawModelChams(int flags, uint8_t alpha);
	IClientNetworkable* GetNetworkable();
	Vector GetAbsOrigin();
	CBaseHandle* GetWearables();
	void SetModelIndexVirtual(int index);
	Vector GetNetworkOrigin();
	Vector GetVecOrigin();
	Vector GetVecViewOffset();
	Vector GetEyeAngles();
	Vector* GetEyeAnglesPointer();
	Vector& GetAbsAnglesNew();
	player_info_t GetPlayerInfo();
	bool IsDormant();
	int GetIndex();
	int GetTickBase(void);
	bool BombDefused();
	float BombTimer();
	bool IsPlayer();
	bool IsWeapon();
	bool IsHostage();
	bool IsChicken();
	int GetHealth();
	bool isAlive();
	int GetFlags();
	int GetTeam();
	float GetFlashDuration();
	int GetHitboxSet();
	bool IsFlashed();
	Vector GetVecVelocity();
	Vector GetPunchAngle();
	Vector* GetPunchAnglePtr();
	float GetSimulationTime();
	Vector* GetViewPunchAnglePtr();
	bool GetScope();
	int GetShootsField();
	CBaseCombatWeapon* GetActiveBaseCombatWeapon();
	bool SetupBones(matrix3x4* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime);
	Vector GetBonePos(int i);
	Vector GetEyePosition();
	int GetArmor();
	bool IsDefusing();
	bool HasHelmet();
	bool HasKit();
	bool HasGunGameImmunity();
	Vector BBMin();
	Vector BBMax();
	bool m_bIsScoped();
	int GetMoveType();
	float pelvisangs();
	Vector WorldSpaceCenter();
	CBaseHandle* GetWeaponsZ()
	{
		return reinterpret_cast<CBaseHandle*>(uintptr_t(this) + 0x00002DE8);
	}
};

class CBaseCombatWeapon : public CBaseEntity
{
public:
	std::string GetWeaponName();
	CBaseHandle GetOwnerHandle();
	float GetPostponeFireReadyTime();
	float NextPrimaryAttack();

	const char* GetName();

	short* GetItemDefinitionIndex();
	void UpdateAccuracyPenalty();
	float GetInaccuracy();
	float GetSpread();
	int ammo();
	//int ammo2();
	bool HasAmmo();
	bool isPistol();
	bool isShotgun();
	bool isSniper();
	bool isScoped();
	bool isAWP();
	bool IsGun();
	bool isRifle();
	bool isSmgW();
	bool isMachineW();
	bool IsNade();
	int BulletSize();
	float hitchance();
	bool IsMiscWeapon();
	bool IsGrenade();
	bool IsKnife();
	bool IsReloading();
	CCSWeaponInfo* GetCSWpnData();

	int& GetModelIndex();
	model_t* GetModel();


	float GetAccuracyPenalty()
	{
		return *reinterpret_cast<float*>((DWORD)this + 0x32E0);
	}
};





class CBaseCSGrenade : CBaseCombatWeapon
{
public:
	float GetPinPulled();
	float GetThrowTime();
};

class CBaseAttributableItem : public CBaseEntity {
public:
	
	CBaseHandle GetWorldModel() {
		
		return *(CBaseHandle*)((DWORD)this + 0x31F4);
	}
	IClientNetworkable* GetNetworkable();
	void SetModelIndex(int index);
	void PreDataUpdate(int updateType);
	short* GetItemDefinitionIndex();

	int* GetItemIDHigh();
	int* GetItemIDLow();
	int* GetEntityQuality();

	char* GetCustomName();
	int* GetOriginalOwnerXuidLow();
	int* GetOriginalOwnerXuidHigh();
	int* GetFallbackPaintKit();
	int* GetFallbackSeed();
	float* GetFallbackWear();
	int* GetFallbackStatTrak();
	unsigned int* GetAccountID();


	bool IsKnife()
	{
		int iWeaponID = *this->GetItemDefinitionIndex();
		return (iWeaponID == tknife || iWeaponID == ctknife
			|| iWeaponID == goldknife || iWeaponID == 59 || iWeaponID == 41
			|| iWeaponID == 500 || iWeaponID == 505 || iWeaponID == 506
			|| iWeaponID == 507 || iWeaponID == 508 || iWeaponID == 509
			|| iWeaponID == 515);
	}
	
};




class CBaseViewModel : public CBaseEntity {
public:
	inline int GetModelIndex() {
		// DT_BaseViewModel -> m_nModelIndex
		return *(int*)((DWORD)this + 0x254);
	}

	inline DWORD GetOwner() {
		// DT_BaseViewModel -> m_hOwner
		return *(PDWORD)((DWORD)this + 0x29BC);
	}

	inline DWORD GetWeapon() {
		// DT_BaseViewModel -> m_hWeapon
		return *(PDWORD)((DWORD)this + 0x29B8);
	}
};