#include "../stdafx.h"
#include <unordered_map>
//------------------------------------------------------------
// Classes to help the parsing of the netvars
//------------------------------------------------------------
#pragma region Helper classes



void UTIL_TraceLine( Vector& vecAbsStart, Vector& vecAbsEnd, unsigned int mask, const IHandleEntity* ignore, int collisionGroup, trace_t* ptr )
{
	Ray_t ray;
	ray.Init( vecAbsStart, vecAbsEnd );
	CTraceFilter traceFilter;
	traceFilter.pSkip = ( void* )ignore;
	Interfaces.pTrace->TraceRay( ray, mask, &traceFilter, ptr );
}
FORCEINLINE float DotProductDistanceToRay(const Vector& a, const Vector& b)
{
	return (a.x * b.x + a.y * b.y + a.z * b.z);
}

float DistanceToRay( const Vector& pos, const Vector& rayStart, const Vector& rayEnd, float* along = nullptr, Vector* pointOnRay = nullptr )
{
	Vector to = pos - rayStart;
	Vector dir = rayEnd - rayStart;
	float length = dir.NormalizeInPlace();

	float rangeAlong = DotProductDistanceToRay( dir, to );
	if( along )
	{
		*along = rangeAlong;
	}

	float range;

	if( rangeAlong < 0.0f )
	{
		// off start point
		range = -( pos - rayStart ).Length();

		if( pointOnRay )
		{
			*pointOnRay = rayStart;
		}
	}
	else if( rangeAlong > length )
	{
		// off end point
		range = -( pos - rayEnd ).Length();

		if( pointOnRay )
		{
			*pointOnRay = rayEnd;
		}
	}
	else // within ray bounds
	{
		Vector onRay = rayStart + ( dir.operator*( rangeAlong ) );
		range = ( pos - onRay ).Length();

		if( pointOnRay )
		{
			*pointOnRay = onRay;
		}
	}

	return range;
}

void UTIL_ClipTraceToPlayers( Vector& vecAbsStart, Vector& vecAbsEnd, unsigned int mask, ITraceFilter* filter, trace_t* tr )
{
	trace_t playerTrace;
	Ray_t ray;
	float smallestFraction = tr->fraction;
	const float maxRange = 60.0f;

	ray.Init( vecAbsStart, vecAbsEnd );

	for( int k = 1; k < 65; ++k )
	{
		CBaseEntity* player = Interfaces.pEntList->GetClientEntity( k );

		if( !player || !player->isAlive() || player == G::LocalPlayer)
			continue;

		if( player->IsDormant() )
			continue;

		if( filter && filter->ShouldHitEntity( player, mask ) == false )
			continue;

		float range = DistanceToRay( player->WorldSpaceCenter(), vecAbsStart, vecAbsEnd );
		if( range < 0.0f || range > maxRange )
			continue;

		Interfaces.pTrace->ClipRayToEntity( ray, mask | CONTENTS_HITBOX, player, &playerTrace );
		if( playerTrace.fraction < smallestFraction )
		{
			// we shortened the ray - save off the trace
			*tr = playerTrace;
			smallestFraction = playerTrace.fraction;
		}
	}
}
bool TraceToExit(Vector& end, trace_t& tr, Vector start, Vector vEnd, trace_t* trace)
{
	typedef bool(__fastcall* TraceToExitFn)(Vector&, trace_t&, float, float, float, float, float, float, trace_t*);
//	static DWORD TraceToExit = Utils.PatternSearch("client.dll", (BYTE*)"\x55\x8B\xEC\x83\xEC\x30\xF3\x0F\x10\x75", "xxxxxxxxxx", NULL, NULL);
	static TraceToExitFn TraceToExit = (TraceToExitFn)Utils.FindPatternIDA("client.dll", "55 8B EC 83 EC 30 F3 0F 10 75");

	if (!TraceToExit)
		return false;

	float start_y = start.y, start_z = start.z, start_x = start.x, dir_y = vEnd.y, dir_x = vEnd.x, dir_z = vEnd.z;
	_asm
	{
		push trace
		push dir_z
		push dir_y
		push dir_x
		push start_z
		push start_y
		push start_x
		mov edx, tr
		mov ecx, end
		call TraceToExit
		add esp, 0x1C
	}

}

CBaseCombatWeapon* CBaseEntity::GetActiveBaseCombatWeapon()
{
	//CANCRUSH
	CBaseHandle pWeepEhandle  = *reinterpret_cast<CBaseHandle*>(uintptr_t(this) + 0x2EE8);
	return ( CBaseCombatWeapon* )( Interfaces.pEntList->GetClientEntityFromHandle(pWeepEhandle));
}
