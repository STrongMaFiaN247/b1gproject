#pragma once
#include "../stdafx.h"

class bf_read;
class bf_write;
typedef unsigned char uint8;
typedef unsigned char BYTE;
typedef unsigned char byte;

#if !defined( INETCHANNELINFO_H )
#define INETCHANNELINFO_H
#ifdef _WIN32
#pragma once
#endif

#define FLOW_OUTGOING	0
#define FLOW_INCOMING	1
#define MAX_FLOWS		2		// in & out

class INetChannelInfo
{
public:

	enum
	{
		GENERIC = 0, // must be first and is default group
		LOCALPLAYER, // bytes for local player entity update
		OTHERPLAYERS, // bytes for other players update
		ENTITIES, // all other entity bytes
		SOUNDS, // game sounds
		EVENTS, // event messages
		USERMESSAGES, // user messages
		ENTMESSAGES, // entity messages
		VOICE, // voice data
		STRINGTABLE, // a stringtable update
		MOVE, // client move cmds
		STRINGCMD, // string command
		SIGNON, // various signondata
		TOTAL, // must be last and is not a real group
	};

	virtual const char* GetName( void ) const = 0; // get channel name
	virtual const char* GetAddress( void ) const = 0; // get channel IP address as string
	virtual float GetTime( void ) const = 0; // current net time
	virtual float GetTimeConnected( void ) const = 0; // get connection time in seconds
	virtual int GetBufferSize( void ) const = 0; // netchannel packet history size
	virtual int GetDataRate( void ) const = 0; // send data rate in byte/sec

	virtual bool IsLoopback( void ) const = 0; // true if loopback channel
	virtual bool IsTimingOut( void ) const = 0; // true if timing out
	virtual bool IsPlayback( void ) const = 0; // true if demo playback

	virtual float GetLatency( int flow ) const = 0; // current latency (RTT), more accurate but jittering
	virtual float GetAvgLatency( int flow ) const = 0; // average packet latency in seconds
	virtual float GetAvgLoss( int flow ) const = 0; // avg packet loss[0..1]
	virtual float GetAvgChoke( int flow ) const = 0; // avg packet choke[0..1]
	virtual float GetAvgData( int flow ) const = 0; // data flow in bytes/sec
	virtual float GetAvgPackets( int flow ) const = 0; // avg packets/sec
	virtual int GetTotalData( int flow ) const = 0; // total flow in/out in bytes
	virtual int GetSequenceNr( int flow ) const = 0; // last send seq number
	virtual bool IsValidPacket( int flow, int frame_number ) const = 0; // true if packet was not lost/dropped/chocked/flushed
	virtual float GetPacketTime( int flow, int frame_number ) const = 0; // time when packet was send
	virtual int GetPacketBytes( int flow, int frame_number, int group ) const = 0; // group size of this packet
	virtual bool GetStreamProgress( int flow, int* received, int* total ) const = 0; // TCP progress if transmitting
	virtual float GetTimeSinceLastReceived( void ) const = 0; // get time since last recieved packet in seconds
	virtual float GetCommandInterpolationAmount( int flow, int frame_number ) const = 0;

	virtual void GetPacketResponseLatency( int flow, int frame_number, int* pnLatencyMsecs, int* pnChoke ) const = 0;

	virtual void GetRemoteFramerate( float* pflFrameTime, float* pflFrameTimeStdDeviation ) const = 0;

	virtual float GetTimeoutSeconds() const = 0;
};

#endif // INETCHANNELINFO_H

class KeyValues
{
public:
	char _pad[0x20];//csgo, for css its a diff size
};



/*template< typename Fn >
inline Fn getvfunc( const void* inst, size_t index, size_t offset = 0 )
{
	if( !inst && offset == 0 )
		return NULL;

	return reinterpret_cast< Fn >( getvtable( inst, offset )[ index ] );
}*/
/*template< typename T >
inline T getvfunc(void* vTable, int iIndex)
{
	return (*(T**)vTable)[iIndex];
}*/

template<typename T>
__forceinline static T getvfunc(void *base, int index)
{
	DWORD *vTabella = *(DWORD**)base;
	return (T)vTabella[index];
}

typedef float matrix3x4[3][4];
typedef float matrix4x4[4][4];

typedef void* (__cdecl* CreateInterface_t)( const char*, int* );

typedef void* (*CreateInterfaceFn)( const char* pName, int* pReturnCode );

typedef __int16 int16;
typedef unsigned __int16 uint16;
typedef __int32 int32;
typedef unsigned __int32 uint32;
typedef __int64 int64;
typedef unsigned __int64 uint64;
typedef float vec_t;

class VMatrix;

/*//USERCMD OFFSETS
#define USERCMDOFFSET 0xEC
#define VERIFIEDCMDOFFSET 0xF0
#define MULTIPLAYER_BACKUP 150
#define CURRENTCOMMANDOFFSET 0x16E8
#define CURRENTPLAYERCOMMANDOFFSET 0x1640
#define PREIDCTIONSEEDOFFSET 0x30
#define PREDICTIONPLAYEROFFSET 0x54
#define GLOBALSOFFSET 0x53
#define WEAPONDATA_MAXRANGEOFFSET 0x77C
#define WEAPONDATA_DAMAGEOFFSET 0x778
#define WEAPONDATA_RANGEMODIFIEROFFSET 0x780
#define WEAPONDATA_PENETRATIONPOWEROFFSET 0x774
#define INPUTOFFSET 0x5F
#define GETSPREADOFFSET 0x740
#define GETCONEOFFSET 0x744
#define UPDATEACCURACYPENALTYOFFSET 0x748
#define WEAPONIDOFFSET 0x6D8
#define WEAPONDATAOFFSET 0x708
#define GETNAMEOFFSET 0x5CC
#define APPSYSTEMFACTORYOFFSET 0x3D
#define CLIENTFACTORYOFFSET 0x75
#define GLOWINDEXOFFSET 0x1DB8*/

//LIFESTATE
#define	LIFE_ALIVE				0
#define	LIFE_DYING				1
#define	LIFE_DEAD				2
#define LIFE_RESPAWNABLE		3
#define LIFE_DISCARDBODY		4

//Player flags
#define	FL_ONGROUND				(1<<0)	// At rest / on the ground
#define FL_DUCKING				(1<<1)	// Player flag -- Player is fully crouched
#define	FL_WATERJUMP			(1<<3)	// player jumping out of water
#define FL_ONTRAIN				(1<<4) // Player is _controlling_ a train, so movement commands should be ignored on client during prediction.
#define FL_INRAIN				(1<<5)	// Indicates the entity is standing in rain
#define FL_FROZEN				(1<<6) // Player is frozen for 3rd person camera
#define FL_ATCONTROLS			(1<<7) // Player can't move, but keeps key inputs for controlling another entity
#define	FL_CLIENT				(1<<8)	// Is a player
#define FL_FAKECLIENT			(1<<9)	// Fake client, simulated server side; don't send network messages to them
#define	FL_INWATER				(1<<10)	// In water

/* MOVE TYPES */
enum MoveType_t
{
	MOVETYPE_NONE = 0,
	MOVETYPE_ISOMETRIC,
	MOVETYPE_WALK,
	MOVETYPE_STEP,
	MOVETYPE_FLY,
	MOVETYPE_FLYGRAVITY,
	MOVETYPE_VPHYSICS,
	MOVETYPE_PUSH,
	MOVETYPE_NOCLIP,
	MOVETYPE_LADDER,
	MOVETYPE_OBSERVER,
	MOVETYPE_CUSTOM,
	MOVETYPE_LAST = MOVETYPE_CUSTOM,
	MOVETYPE_MAX_BITS = 4
};

//USERCMD BUTTONS
#define IN_ATTACK		(1 << 0)
#define IN_JUMP			(1 << 1)
#define IN_DUCK			(1 << 2)
#define IN_FORWARD		(1 << 3)
#define IN_BACK			(1 << 4)
#define IN_USE			(1 << 5)
#define IN_CANCEL		(1 << 6)
#define IN_LEFT			(1 << 7)
#define IN_RIGHT		(1 << 8)
#define IN_MOVELEFT		(1 << 9)
#define IN_MOVERIGHT	(1 << 10)
#define IN_ATTACK2		(1 << 11)
#define IN_RUN			(1 << 12)
#define IN_RELOAD		(1 << 13)
#define IN_ALT1			(1 << 14)
#define IN_ALT2			(1 << 15)
#define IN_SCORE		(1 << 16)   // Used by client.dll for when scoreboard is held down
#define IN_SPEED		(1 << 17)	// Player is holding the speed key
#define IN_WALK			(1 << 18)	// Player holding walk key
#define IN_ZOOM			(1 << 19)	// Zoom key for HUD zoom
#define IN_WEAPON1		(1 << 20)	// weapon defines these bits
#define IN_WEAPON2		(1 << 21)	// weapon defines these bits
#define IN_BULLRUSH		(1 << 22)
#define IN_GRENADE1		(1 << 23)	// grenade 1
#define IN_GRENADE2		(1 << 24)	// grenade 2

#include "SDK Headers/SDK_Others.h"

class ISurface;
class IPanel;
class HLCLient;
class CEntityList;
class CEngineClient;
class CInput;
class CGlowObjectManager;
class IVModelInfo;
class IVModelRender;
class CPrediction;
class CGameMovement;
class IMoveHelper;
class CGlobalVars;
class IEngineTrace;
class IPhysicsSurfaceProps;
class CDebugOverlay;
class IMaterialSystem;;
class IVRenderView;
class ICVar;
class ICvar2;
class CEffects;
class IGameEventManager2;
class IViewRender;
class IStudioRender;
class IViewRenderBeams;
class CInputSystem;
class CBaseClientState;
class IEngineSound;

#define VENGINE_CLIENT_INTERFACE_VERSION "VEngineClient014"
#define CLIENT_DLL_INTERFACE_VERSION "VClient018"
#define VCLIENTENTITYLIST_INTERFACE_VERSION "VClientEntityList003"
#define VSTUDIORENDER_INTERFACE_VERSION "VStudioRender026"
#define VGUIPANEL_INTERFACE_VERSION "VGUI_Panel009"
#define VSURFACE_INTERFACE_VERSION "VGUI_Surface031"
#define VDEBUGOVERLAY_INTERFACE_VERSION "VDebugOverlay004"
#define ENGINETRACECLIENT_INTERFACE_VERSION "EngineTraceClient004"
#define vMODELINFOCLIENT_INTERFACE_VERSION "VModelInfoClient004"
#define VENGINEMODEL_INTERFACE_VERSION "VEngineModel016"
#define INTERFACEVERSION_GAMEEVENTSMANAGER2 "GAMEEVENTSMANAGER002"
#define INTERFACEVERSION_VCLIENTPREDICTION "VClientPrediction001"
#define INTERFACEVERSION_VENGINECVAR "VEngineCvar007"
#define INTERFACEVERSION_VENGINEEFFECTS "VEngineEffects001"
#define INTERFACEVERSION_GAMEMOVEMENT "GameMovement001"
#define INTERFACEVERSION_VPHYSICSSURFACEPROPS "VPhysicsSurfaceProps001"
#define INTERFACEVERSION_INPUTSYSTEMVERSION "InputSystemVersion001"
#define INTERFACEVERSION_VMATERIALSYSTEM "VMaterialSystem080"
#define INTERFACEVERSION_VENGINERENDERVIEW "VEngineRenderView014"
#define INTERFACEVERSION_VENGINESOUND "IEngineSoundClient003"
class CInterfaces
{
private:
	typedef void* (*CreateInterface_t) (const char*, int*);

	template <class T> inline T* CaptureInterface(CreateInterface_t create_interface_fn, const char* version) {
		return static_cast<T*>(create_interface_fn(version, nullptr));
	}

public:
	void CreateInterfaces()
	{
		auto vguimatsurface = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("vguimatsurface.dll"), "CreateInterface"));
		auto vgui2 = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("vgui2.dll"), "CreateInterface"));
		auto engine = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("engine.dll"), "CreateInterface"));
		auto client = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("client.dll"), "CreateInterface"));
		auto studiorender = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("studiorender.dll"), "CreateInterface"));
		auto vstdlib = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("vstdlib.dll"), "CreateInterface"));
		auto materialsystem = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("materialsystem.dll"), "CreateInterface"));
		auto inputsystem = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("inputsystem.dll"), "CreateInterface"));
		auto vphysics = reinterpret_cast<CreateInterface_t>(GetProcAddress(GetModuleHandleA("vphysics.dll"), "CreateInterface"));


		pSurface		= CaptureInterface<ISurface>(vguimatsurface, VSURFACE_INTERFACE_VERSION);
		pPanel			= CaptureInterface<IPanel>(vgui2, VGUIPANEL_INTERFACE_VERSION);
		pEngine			= CaptureInterface<CEngineClient>(engine, VENGINE_CLIENT_INTERFACE_VERSION);
		pClient			= CaptureInterface<HLCLient>(client, CLIENT_DLL_INTERFACE_VERSION);
		g_pStudioRender = CaptureInterface<IStudioRender>(studiorender, VSTUDIORENDER_INTERFACE_VERSION);
		pEntList		= CaptureInterface<CEntityList>(client, VCLIENTENTITYLIST_INTERFACE_VERSION);
		g_pDebugOverlay = CaptureInterface<CDebugOverlay>(engine, VDEBUGOVERLAY_INTERFACE_VERSION);
		pTrace			= CaptureInterface<IEngineTrace>(engine, ENGINETRACECLIENT_INTERFACE_VERSION);
		g_pModelInfo	= CaptureInterface<IVModelInfo>(engine, vMODELINFOCLIENT_INTERFACE_VERSION);
		g_pModelRender	= CaptureInterface<IVModelRender>(engine, VENGINEMODEL_INTERFACE_VERSION);
		g_GameEventMgr	= CaptureInterface<IGameEventManager2>(engine, INTERFACEVERSION_GAMEEVENTSMANAGER2);
		g_pPred			= CaptureInterface<CPrediction>(client, INTERFACEVERSION_VCLIENTPREDICTION);
		g_ICVars		= CaptureInterface<ICVar>(vstdlib, INTERFACEVERSION_VENGINECVAR);
		pEffects		= CaptureInterface<CEffects>(engine, INTERFACEVERSION_VENGINEEFFECTS);
		g_pGameMovement = CaptureInterface<CGameMovement>(client, INTERFACEVERSION_GAMEMOVEMENT);
		pPhysProps		= CaptureInterface<IPhysicsSurfaceProps>(vphysics, INTERFACEVERSION_VPHYSICSSURFACEPROPS);
		g_pInputSystem	= CaptureInterface<CInputSystem>(inputsystem, INTERFACEVERSION_INPUTSYSTEMVERSION);
		pMaterialSystem = CaptureInterface<IMaterialSystem>(materialsystem, INTERFACEVERSION_VMATERIALSYSTEM);
		g_pRenderView	= CaptureInterface<IVRenderView>(engine, INTERFACEVERSION_VENGINERENDERVIEW);
		s_EngineSound	= CaptureInterface<IEngineSound>(engine, INTERFACEVERSION_VENGINESOUND);
		pClientMode		= **(IClientModeShared***)((*(DWORD**)pClient)[10] + 0x5);
		pGlobalVars		= **reinterpret_cast< CGlobalVars*** > ((*reinterpret_cast< uintptr_t** > (pClient))[0] + 0x1B);
		g_pBeams		= *reinterpret_cast< IViewRenderBeams** >(Utils.FindSig(XorStr("client.dll"), XorStr("A1 ? ? ? ? 56 8B F1 B9 ? ? ? ? FF 50 08")) + 0x1);
		pInput			= (CInput*)*(DWORD*)(Utils.FindPatternIDA("client.dll", "B9 ? ? ? ? F3 0F 11 04 24 FF 50 10") + 0x1);
		g_pMoveHelper	= **(IMoveHelper***)(Utils.FindPatternIDA(XorStr("client.dll"), XorStr("8B 0D ? ? ? ? 8B 46 08 68")) + 0x2);

	}

	ISurface* pSurface;
	IClientModeShared* pClientMode;
	IPanel* pPanel;
	HLCLient* pClient;
	CEntityList* pEntList;
	CEngineClient* pEngine;
	CInput* pInput;
	CGlowObjectManager* g_pGlowObjectManager;
	IVModelInfo* g_pModelInfo;
	IVModelRender* g_pModelRender;
	CPrediction* g_pPred;
	CGameMovement* g_pGameMovement;
	IMoveHelper* g_pMoveHelper;
	CGlobalVars* pGlobalVars;
	IEngineTrace* pTrace;
	IPhysicsSurfaceProps* pPhysProps;
	CDebugOverlay* g_pDebugOverlay;
	IMaterialSystem* pMaterialSystem;
	IVRenderView* g_pRenderView;
	ICVar* g_ICVars;
	IGameEventManager2* g_GameEventMgr;
	IStudioRender* g_pStudioRender;
	IViewRenderBeams* g_pBeams;
	CInputSystem* g_pInputSystem;
	CEffects* pEffects;
	IEngineSound* s_EngineSound;
};

extern CInterfaces Interfaces;

#include "Math.h"

#include "SDK Headers/Valve/checksum_crc.h"
//#include "SDK Headers/Valve/dt_recv2.h"
#include "SDK Headers/NetVars.h"

#include "SDK Headers/ISurface.h"
#include "SDK Headers/CClient.h"
#include "SDK Headers/EngineClient.h"
#include "SDK Headers/Entitys.h"
#include "SDK Headers/EntList.h"
#include "SDK Headers/DebugOverlay.h"
#include "SDK Headers/CTrace.h"
#include "SDK Headers/IVRenderView.h"
#include "SDK Headers/CModelInfo.h"
#include "SDK Headers/CInput.h"
#include "SDK Headers/ICVars.h"
#include "SDK Headers/CGlobleVars.h"
#include "SDK Headers/CGameMovement.h"
#include "SDK Headers/CPred.h"

void UTIL_TraceLine( Vector& vecAbsStart, Vector& vecAbsEnd, unsigned int mask, const IHandleEntity* ignore, int collisionGroup, trace_t* ptr );

void UTIL_ClipTraceToPlayers( Vector& vecAbsStart, Vector& vecAbsEnd, unsigned int mask, ITraceFilter* filter, trace_t* tr );

bool TraceToExit( Vector& end, trace_t& tr, Vector start, Vector vEnd, trace_t* trace );
bool TraceToExit2(Vector& vecEnd, trace_t* pEnterTrace, Vector vecStart, Vector vecDir, trace_t* pExitTrace);
//bool TraceToExit2(Vector& vecEnd, trace_t* pEnterTrace, Vector vecStart, Vector vecDir, trace_t* pExitTrace);
/* FIRE BULLET DATA */
struct FireBulletData
{
	FireBulletData( const Vector& eye_pos ) : src( eye_pos )
	{
	}

	Vector src;
	trace_t enter_trace;
	Vector direction;
	CTraceFilter filter;
	float trace_length;
	float trace_length_remaining;
	float current_damage;
	int penetrate_count;
};

/* HITGROUP DEFINITIONS */
#define		HITGROUP_GENERIC    0
#define		HITGROUP_HEAD       1
#define		HITGROUP_CHEST      2
#define		HITGROUP_STOMACH    3
#define		HITGROUP_LEFTARM    4
#define		HITGROUP_RIGHTARM   5
#define		HITGROUP_LEFTLEG    6
#define		HITGROUP_RIGHTLEG   7
#define		HITGROUP_GEAR       10

typedef bool (*ShouldHitFunc_t)( IHandleEntity* pHandleEntity, int contentsMask );

enum class CSGOClassID
{
	CTestTraceline = 189,
	CTEWorldDecal = 190,
	CTESpriteSpray = 187,
	CTESprite = 186,
	CTESparks = 185,
	CTESmoke = 184,
	CTEShowLine = 182,
	CTEProjectedDecal = 179,
	CTEPlayerDecal = 178,
	CTEPhysicsProp = 175,
	CTEParticleSystem = 174,
	CTEMuzzleFlash = 173,
	CTELargeFunnel = 171,
	CTEKillPlayerAttachments = 170,
	CTEImpact = 169,
	CTEGlowSprite = 168,
	CTEShatterSurface = 181,
	CTEFootprintDecal = 165,
	CTEFizz = 164,
	CTEExplosion = 162,
	CTEEnergySplash = 161,
	CTEEffectDispatch = 160,
	CTEDynamicLight = 159,
	CTEDecal = 157,
	CTEClientProjectile = 156,
	CTEBubbleTrail = 155,
	CTEBubbles = 154,
	CTEBSPDecal = 153,
	CTEBreakModel = 152,
	CTEBloodStream = 151,
	CTEBloodSprite = 150,
	CTEBeamSpline = 149,
	CTEBeamRingPoint = 148,
	CTEBeamRing = 147,
	CTEBeamPoints = 146,
	CTEBeamLaser = 145,
	CTEBeamFollow = 144,
	CTEBeamEnts = 143,
	CTEBeamEntPoint = 142,
	CTEBaseBeam = 141,
	CTEArmorRicochet = 140,
	CTEMetalSparks = 172,
	CSteamJet = 135,
	CSmokeStack = 128,
	DustTrail = 238,
	CFireTrail = 62,
	SporeTrail = 244,
	SporeExplosion = 243,
	RocketTrail = 241,
	SmokeTrail = 242,
	CPropVehicleDriveable = 117,
	ParticleSmokeGrenade = 240,
	CParticleFire = 96,
	MovieExplosion = 239,
	CTEGaussExplosion = 167,
	CEnvQuadraticBeam = 55,
	CEmbers = 45,
	CEnvWind = 59,
	CPrecipitation = 111,
	CPrecipitationBlocker = 112,
	CBaseTempEntity = 18,
	NextBotCombatCharacter = 0,
	CBaseAttributableItem = 4,
	CEconEntity = 44,
	CWeaponXM1014 = 236,
	CWeaponTaser = 231,
	CSmokeGrenade = 126,
	CWeaponSG552 = 228,
	CWeaponSawedoff = 224,
	CWeaponNOVA = 220,
	CIncendiaryGrenade = 85,
	CMolotovGrenade = 93,
	CWeaponM3 = 212,
	CKnifeGG = 90,
	CKnife = 89,
	CHEGrenade = 82,
	CFlashbang = 64,
	CWeaponElite = 203,
	CDecoyGrenade = 40,
	CDEagle = 39,
	CWeaponUSP = 235,
	CWeaponM249 = 211,
	CWeaponUMP45 = 234,
	CWeaponTMP = 233,
	CWeaponTec9 = 232,
	CWeaponSSG08 = 230,
	CWeaponSG556 = 229,
	CWeaponSG550 = 227,
	CWeaponScout = 226,
	CWeaponSCAR20 = 225,
	CSCAR17 = 122,
	CWeaponP90 = 223,
	CWeaponP250 = 222,
	CWeaponP228 = 221,
	CWeaponNegev = 219,
	CWeaponMP9 = 218,
	CWeaponMP7 = 217,
	CWeaponMP5Navy = 216,
	CWeaponMag7 = 215,
	CWeaponMAC10 = 214,
	CWeaponM4A1 = 213,
	CWeaponHKP2000 = 210,
	CWeaponGlock = 209,
	CWeaponGalilAR = 208,
	CWeaponGalil = 207,
	CWeaponG3SG1 = 206,
	CWeaponFiveSeven = 205,
	CWeaponFamas = 204,
	CWeaponBizon = 199,
	CWeaponAWP = 198,
	CWeaponAug = 197,
	CAK47 = 1,
	CWeaponCSBaseGun = 201,
	CWeaponCSBase = 200,
	CC4 = 29,
	CBaseCSGrenade = 8,
	CSmokeGrenadeProjectile = 127,
	CMolotovProjectile = 94,
	CDecoyProjectile = 41,
	CFireCrackerBlast = 60,
	CInferno = 86,
	CChicken = 31,
	CFootstepControl = 66,
	CCSGameRulesProxy = 34,
	CWeaponCubemap = 0,
	CWeaponCycler = 202,
	CTEPlantBomb = 176,
	CTEFireBullets = 163,
	CTERadioIcon = 180,
	CPlantedC4 = 105,
	CCSTeam = 38,
	CCSPlayerResource = 36,
	CCSPlayer = 35,
	CCSRagdoll = 37,
	CTEPlayerAnimEvent = 177,
	CHostage = 83,
	CHostageCarriableProp = 84,
	CBaseCSGrenadeProjectile = 9,
	CHandleTest = 81,
	CTeamplayRoundBasedRulesProxy = 139,
	CSpriteTrail = 133,
	CSpriteOriented = 132,
	CSprite = 131,
	CRagdollPropAttached = 120,
	CRagdollProp = 119,
	CPredictedViewModel = 113,
	CPoseController = 109,
	CGameRulesProxy = 80,
	CInfoLadderDismount = 87,
	CFuncLadder = 72,
	CTEFoundryHelpers = 166,
	CEnvDetailController = 51,
	CWorld = 237,
	CWaterLODControl = 196,
	CWaterBullet = 195,
	CVoteController = 194,
	CVGuiScreen = 193,
	CPropJeep = 116,
	CPropVehicleChoreoGeneric = 0,
	CTriggerSoundOperator = 192,
	CBaseVPhysicsTrigger = 22,
	CTriggerPlayerMovement = 191,
	CBaseTrigger = 20,
	CTest_ProxyToggle_Networkable = 188,
	CTesla = 183,
	CBaseTeamObjectiveResource = 17,
	CTeam = 138,
	CSunlightShadowControl = 137,
	CSun = 136,
	CParticlePerformanceMonitor = 97,
	CSpotlightEnd = 130,
	CSpatialEntity = 129,
	CSlideshowDisplay = 125,
	CShadowControl = 124,
	CSceneEntity = 123,
	CRopeKeyframe = 121,
	CRagdollManager = 118,
	CPhysicsPropMultiplayer = 102,
	CPhysBoxMultiplayer = 100,
	CPropDoorRotating = 115,
	CBasePropDoor = 16,
	CDynamicProp = 43,
	CProp_Hallucination = 114,
	CPostProcessController = 110,
	CPointCommentaryNode = 108,
	CPointCamera = 107,
	CPlayerResource = 106,
	CPlasma = 105,
	CPhysMagnet = 103,
	CPhysicsProp = 101,
	CStatueProp = 134,
	CPhysBox = 99,
	CParticleSystem = 98,
	CMovieDisplay = 95,
	CMaterialModifyControl = 92,
	CLightGlow = 91,
	CInfoOverlayAccessor = 88,
	CFuncTrackTrain = 79,
	CFuncSmokeVolume = 78,
	CFuncRotating = 77,
	CFuncReflectiveGlass = 76,
	CFuncOccluder = 75,
	CFuncMoveLinear = 74,
	CFuncMonitor = 73,
	CFunc_LOD = 68,
	CTEDust = 158,
	CFunc_Dust = 67,
	CFuncConveyor = 71,
	CFuncBrush = 70,
	CBreakableSurface = 28,
	CFuncAreaPortalWindow = 69,
	CFish = 63,
	CFireSmoke = 61,
	CEnvTonemapController = 58,
	CEnvScreenEffect = 56,
	CEnvScreenOverlay = 57,
	CEnvProjectedTexture = 54,
	CEnvParticleScript = 53,
	CFogController = 65,
	CEnvDOFController = 52,
	CCascadeLight = 30,
	CEnvAmbientLight = 50,
	CEntityParticleTrail = 49,
	CEntityFreezing = 48,
	CEntityFlame = 47,
	CEntityDissolve = 46,
	CDynamicLight = 42,
	CColorCorrectionVolume = 33,
	CColorCorrection = 32,
	CBreakableProp = 27,
	CBeamSpotlight = 25,
	CBaseButton = 5,
	CBaseToggle = 19,
	CBasePlayer = 15,
	CBaseFlex = 12,
	CBaseEntity = 11,
	CBaseDoor = 10,
	CBaseCombatCharacter = 6,
	CBaseAnimatingOverlay = 3,
	CBoneFollower = 26,
	CBaseAnimating = 2,
	CAI_BaseNPC = 0,
	CBeam = 24,
	CBaseViewModel = 21,
	CBaseParticleEntity = 14,
	CBaseGrenade = 13,
	CBaseCombatWeapon = 7,
	CBaseWeaponWorldModel = 23
};



enum
{
	CURRENTMAP_DEDUST2,
	CURRENTMAP_DEMIRAGE,
	CURRENTMAP_DECACHE,
	CURRENTMAP_DEOVERPASS,
	CURRENTMAP_COBBLE,
	CURRENTMAP_DEINFERNO,
	CURRENTMAP_DENUKE,
	CURRENTMAP_DETRAIN,
};