#include "stdafx.h"
#include "NameSpace.h"
#include "imgui\imgui.h"
#include "imgui\imgui_internal.h"
#include "imgui\dx9\imgui_dx9.h"
#include "Parser.h"
#include "SkinChanger-KentMeister.h"
#include "ConfigSkins.h"
#include "ColorCFG.h"
#include "RenderD9.h"
int BulletSizeByMenu(int id)
{
	short WeaponId = id;
	switch (WeaponId)
	{
	case WEAPON_ELITE:
	case WEAPON_MAC10:
	case WEAPON_M4A1:
	case WEAPON_AK47:
	case WEAPON_MP7:
	case WEAPON_MP9:
	case WEAPON_SG556:
	case WEAPON_AUG:
		return 30;
	case WEAPON_NEGEV:
		return 150;
	case WEAPON_M249:
		return 100;
	case WEAPON_REVOLVER:
		return 8;
	case WEAPON_M4A1_SILENCER:
	case WEAPON_GLOCK:
	case WEAPON_SCAR20:
	case WEAPON_G3SG1:
		return 20;
	case WEAPON_DEAGLE:
		return 7;
	case WEAPON_P90:
		return 50;
	case WEAPON_UMP45:
		return 25;
	case WEAPON_SSG08:
	case WEAPON_AWP:
		return 10;
	case WEAPON_GALILAR:
		return 35;
	case WEAPON_FAMAS:
		return 25;
	case WEAPON_CZ75A:
	case WEAPON_USP_SILENCER:
		return 12;
	case WEAPON_HKP2000:
	case WEAPON_P250:
		return 13;
	case WEAPON_TEC9:
		return 24;
	case WEAPON_NOVA:
		return 8;
	case WEAPON_XM1014:
	case WEAPON_SAWEDOFF:
		return 7;
	case WEAPON_MAG7:
		return 5;
	case WEAPON_BIZON:
		return 64;
	default:
		return 100;

	}

}

bool IsKnifeForMenu(int id)
{
	short iWeaponID = id;
	return (iWeaponID == 42 || iWeaponID == 59 || iWeaponID == 41
		|| iWeaponID == 500 || iWeaponID == 505 || iWeaponID == 506
		|| iWeaponID == 507 || iWeaponID == 508 || iWeaponID == 509
		|| iWeaponID == 515);
}

#define SliderIntFST(x1,x2,x3,x4) ImGui::PushItemWidth(120); ImGui::SliderInt(x1, &x2, x3, x4); ImGui::PopItemWidth();
#define SliderFloatFST(x1,x2,x3,x4) ImGui::PushItemWidth(120); ImGui::SliderFloat(x1, &x2, x3, x4); ImGui::PopItemWidth();
#define SliderFloatFSTCustom(x1,x2,x3,x4,x5) ImGui::PushItemWidth(x5); ImGui::SliderFloat(x1, &x2, x3, x4); ImGui::PopItemWidth();
#define IM_ARRAYSIZE(_ARR)  ((int)(sizeof(_ARR)/sizeof(*_ARR)))
// Menu Includes Futures
#include "icons/TitleBar.h"
#include "icons/LegitBar.h"
#include "icons/RageBar.h"
#include "icons/VisualsBar.h"
#include "icons/MiscBar.h"
IDirect3DTexture9 *TittleBar = nullptr;
IDirect3DTexture9 *LegitTabImg = nullptr;
IDirect3DTexture9 *RageTabImg = nullptr;
IDirect3DTexture9 *VisualsTabImg = nullptr;
IDirect3DTexture9 *MiscTabImg = nullptr;

int windowWidth = 800;
int windowHeight = 425;

int windowWidth2 = 650;
int windowHeight2 = 485;

int curWidth = windowWidth;
int curHeight = windowHeight;


void DeclareToSave(int col[4], CColor meme)
{
	col[0] = meme.r(); col[1] = meme.g(); col[2] = meme.b(); col[3] = meme.a();
}

#define DeclareToLoad(x1,x2) x2 = CColor(x1[0],x1[1],x1[2],x1[3])

bool ColorPickerNew(float* col, bool alphabar)
{
	const int EDGE_SIZE = 200; // = int(ImGui::GetWindowWidth() * 0.75f);
	const ImVec2 SV_PICKER_SIZE = ImVec2(EDGE_SIZE, EDGE_SIZE);
	const float SPACING = ImGui::GetStyle().ItemInnerSpacing.x;
	const float HUE_PICKER_WIDTH = 20.f;
	const float CROSSHAIR_SIZE = 7.0f;

	ImColor color(col[0], col[1], col[2]);
	bool value_changed = false;

	ImDrawList* draw_list = ImGui::GetWindowDrawList();

	ImVec2 picker_pos = ImGui::GetCursorScreenPos();

	float hue, saturation, value;
	ImGui::ColorConvertRGBtoHSV(color.Value.x, color.Value.y, color.Value.z, hue, saturation, value);

	ImColor colors[] = {
		ImColor(255, 0, 0),
		ImColor(255, 255, 0),
		ImColor(0, 255, 0),
		ImColor(0, 255, 255),
		ImColor(0, 0, 255),
		ImColor(255, 0, 255),
		ImColor(255, 0, 0)
	};

	for (int i = 0; i < 6; i++)
	{
		draw_list->AddRectFilledMultiColor(
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + SPACING, picker_pos.y + i * (SV_PICKER_SIZE.y / 6)),
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + SPACING + HUE_PICKER_WIDTH,
				picker_pos.y + (i + 1) * (SV_PICKER_SIZE.y / 6)),
			colors[i],
			colors[i],
			colors[i + 1],
			colors[i + 1]
		);
	}

	draw_list->AddLine(
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x + SPACING - 2, picker_pos.y + hue * SV_PICKER_SIZE.y),
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x + SPACING + 2 + HUE_PICKER_WIDTH, picker_pos.y + hue * SV_PICKER_SIZE.y),
		ImColor(255, 255, 255)
	);

	if (alphabar)
	{
		float alpha = col[3];

		draw_list->AddRectFilledMultiColor(
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 2 * SPACING + HUE_PICKER_WIDTH, picker_pos.y),
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 2 * SPACING + 2 * HUE_PICKER_WIDTH, picker_pos.y + SV_PICKER_SIZE.y),
			ImColor(0, 0, 0), ImColor(0, 0, 0), ImColor(255, 255, 255), ImColor(255, 255, 255)
		);

		draw_list->AddLine(
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 2 * (SPACING - 2) + HUE_PICKER_WIDTH, picker_pos.y + alpha * SV_PICKER_SIZE.y),
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 2 * (SPACING + 2) + 2 * HUE_PICKER_WIDTH, picker_pos.y + alpha * SV_PICKER_SIZE.y),
			ImColor(255.f - alpha, 255.f, 255.f)
		);
	}

	const ImU32 c_oColorBlack = ImGui::ColorConvertFloat4ToU32(ImVec4(0.f, 0.f, 0.f, 1.f));
	const ImU32 c_oColorBlackTransparent = ImGui::ColorConvertFloat4ToU32(ImVec4(0.f, 0.f, 0.f, 0.f));
	const ImU32 c_oColorWhite = ImGui::ColorConvertFloat4ToU32(ImVec4(1.f, 1.f, 1.f, 1.f));

	ImVec4 cHueValue(1, 1, 1, 1);
	ImGui::ColorConvertHSVtoRGB(hue, 1, 1, cHueValue.x, cHueValue.y, cHueValue.z);
	ImU32 oHueColor = ImGui::ColorConvertFloat4ToU32(cHueValue);

	draw_list->AddRectFilledMultiColor(
		ImVec2(picker_pos.x, picker_pos.y),
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x, picker_pos.y + SV_PICKER_SIZE.y),
		c_oColorWhite,
		oHueColor,
		oHueColor,
		c_oColorWhite
	);

	draw_list->AddRectFilledMultiColor(
		ImVec2(picker_pos.x, picker_pos.y),
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x, picker_pos.y + SV_PICKER_SIZE.y),
		c_oColorBlackTransparent,
		c_oColorBlackTransparent,
		c_oColorBlack,
		c_oColorBlack
	);

	float x = saturation * SV_PICKER_SIZE.x;
	float y = (1 - value) * SV_PICKER_SIZE.y;
	ImVec2 p(picker_pos.x + x, picker_pos.y + y);
	draw_list->AddLine(ImVec2(p.x - CROSSHAIR_SIZE, p.y), ImVec2(p.x - 2, p.y), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x + CROSSHAIR_SIZE, p.y), ImVec2(p.x + 2, p.y), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x, p.y + CROSSHAIR_SIZE), ImVec2(p.x, p.y + 2), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x, p.y - CROSSHAIR_SIZE), ImVec2(p.x, p.y - 2), ImColor(255, 255, 255));

	ImGui::InvisibleButton("saturation_value_selector", SV_PICKER_SIZE);

	if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0])
	{
		ImVec2 mouse_pos_in_canvas = ImVec2(ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

		if (mouse_pos_in_canvas.x <	0)
			mouse_pos_in_canvas.x = 0;
		else if (mouse_pos_in_canvas.x >= SV_PICKER_SIZE.x - 1)
			mouse_pos_in_canvas.x = SV_PICKER_SIZE.x - 1;

		if (mouse_pos_in_canvas.y < 0)
			mouse_pos_in_canvas.y = 0;
		else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 1)
			mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 1;

		value = 1 - (mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1));
		saturation = mouse_pos_in_canvas.x / (SV_PICKER_SIZE.x - 1);
		value_changed = true;
	}

	// hue bar logic
	ImGui::SetCursorScreenPos(ImVec2(picker_pos.x + SPACING + SV_PICKER_SIZE.x, picker_pos.y));
	ImGui::InvisibleButton("hue_selector", ImVec2(HUE_PICKER_WIDTH, SV_PICKER_SIZE.y));

	if (ImGui::GetIO().MouseDown[0] && (ImGui::IsItemHovered() || ImGui::IsItemActive()))
	{
		ImVec2 mouse_pos_in_canvas = ImVec2(ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

		if (mouse_pos_in_canvas.y <	0)
			mouse_pos_in_canvas.y = 0;
		else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 1)
			mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 1;

		hue = mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1);
		value_changed = true;
	}

	if (alphabar)
	{
		ImGui::SetCursorScreenPos(ImVec2(picker_pos.x + SPACING * 2 + HUE_PICKER_WIDTH + SV_PICKER_SIZE.x, picker_pos.y));
		ImGui::InvisibleButton("alpha_selector", ImVec2(HUE_PICKER_WIDTH, SV_PICKER_SIZE.y));

		if (ImGui::GetIO().MouseDown[0] && (ImGui::IsItemHovered() || ImGui::IsItemActive()))
		{
			ImVec2 mouse_pos_in_canvas = ImVec2(ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

			if (mouse_pos_in_canvas.y <	0)
				mouse_pos_in_canvas.y = 0;
			else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 1)
				mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 1;

			float alpha = mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1);
			col[3] = alpha;
			value_changed = true;
		}
	}

	color = ImColor::HSV(hue >= 1 ? hue - 10 * 1e-6 : hue, saturation > 0 ? saturation : 10 * 1e-6, value > 0 ? value : 1e-6);
	col[0] = color.Value.x;
	col[1] = color.Value.y;
	col[2] = color.Value.z;

	bool widget_used;
	ImGui::PushItemWidth((alphabar ? SPACING + HUE_PICKER_WIDTH : 0) + SV_PICKER_SIZE.x + SPACING + HUE_PICKER_WIDTH - 2 * ImGui::GetStyle().FramePadding.x);
	widget_used = alphabar ? ImGui::ColorEdit4("", col) : ImGui::ColorEdit3("", col);
	ImGui::PopItemWidth();

	float new_hue, new_sat, new_val;
	ImGui::ColorConvertRGBtoHSV(col[0], col[1], col[2], new_hue, new_sat, new_val);

	if (new_hue <= 0 && hue > 0)
	{
		if (new_val <= 0 && value != new_val)
		{
			color = ImColor::HSV(hue, saturation, new_val <= 0 ? value * 0.5f : new_val);
			col[0] = color.Value.x;
			col[1] = color.Value.y;
			col[2] = color.Value.z;
		}
		else if (new_sat <= 0)
		{
			color = ImColor::HSV(hue, new_sat <= 0 ? saturation * 0.5f : new_sat, new_val);
			col[0] = color.Value.x;
			col[1] = color.Value.y;
			col[2] = color.Value.z;
		}
	}

	return value_changed | widget_used;
}
bool ColorPicker4New(float col[4])
{
	return ColorPickerNew(col, true);
}

struct ColorListVar
{
	const char* name;
	union
	{
		CColor colorVarPtr;
	};


	ColorListVar(const char* name, CColor ptr)
	{
		this->name = name;
		colorVarPtr = ptr;
	}

};





ColorListVar colors[] = {

	{ "CT Box Visible", Hacks.Colors.CTBoxVisable },
	{ "CT Box InVisible", Hacks.Colors.CTBoxInVisable },
	{ "T Box Visible", Hacks.Colors.TBoxVisable },
	{ "T Box InVisible", Hacks.Colors.TBoxInVisable },
	{ "CT Glow Visible", Hacks.Colors.CTGlowVisable },
	{ "CT Glow InVisible", Hacks.Colors.CTGlowInVisable },
	{ "T Glow Visible", Hacks.Colors.TGlowVisable },
	{ "T Glow InVisible", Hacks.Colors.TGlowInVisable },
	{ "Beam-Tracer", Hacks.Colors.Beams },
	{ "Filled Spread Circle", Hacks.Colors.FilledSpread },
	{ "Hit-Capsule", Hacks.Colors.LagCompHitboxes },
	{ "CT Chams Visible", Hacks.Colors.CTChamsVisable },
	{ "CT Chams InVisible", Hacks.Colors.CTChamsInVisable },
	{ "T Chams Visible", Hacks.Colors.TChamsVisable },
	{ "T Chams InVisible", Hacks.Colors.TChamsInVisable },
	{ "Fake Angle Chams", Hacks.Colors.FakeAngleChams },
	{ "Sound Esp", Hacks.Colors.SoundESP },
	{ "Damage Esp", Hacks.Colors.DamageESP },
	{ "Arrows Indicators", Hacks.Colors.Stelki }
};

/*CColor ColorForMenu(int NeedColor)
{
	switch (NeedColor)
	{
	case 0:return Hacks.Colors.CTBoxVisable; break;
	case 1:return Hacks.Colors.CTBoxInVisable; break;
	case 2:return Hacks.Colors.TBoxVisable; break;
	case 3:return Hacks.Colors.TBoxInVisable; break;
	case 4:return Hacks.Colors.CTGlowVisable; break;
	case 5:return Hacks.Colors.CTGlowInVisable; break;
	case 6:return Hacks.Colors.TGlowVisable; break;
	case 7:return Hacks.Colors.TGlowInVisable; break;
	default:return CColor(255, 255, 255, 255); break;
	}
}*/


const char* colorNames[IM_ARRAYSIZE(colors)];


std::string SanitizeName(char *name)
{
	name[127] = '\0';

	std::string tmp(name);

	for (int i = 0; i < (int)tmp.length(); i++)
	{
		if ((
			tmp[i] >= 'a' && tmp[i] <= 'z' ||
			tmp[i] >= 'A' && tmp[i] <= 'Z' ||
			tmp[i] >= '0' && tmp[i] <= '9' ||
			tmp[i] == ' ' || tmp[i] == '.' || tmp[i] == '/' || tmp[i] == ':' ||
			tmp[i] == ',' || tmp[i] == '_' || tmp[i] == '#' || tmp[i] == '$' ||
			tmp[i] == '<' || tmp[i] == '>' || tmp[i] == '-' || tmp[i] == '+' ||
			tmp[i] == '*' || tmp[i] == '%' || tmp[i] == '@' || tmp[i] == '(' ||
			tmp[i] == ')' || tmp[i] == '{' || tmp[i] == '}' || tmp[i] == '[' || tmp[i] == ']' ||
			tmp[i] == '!' || tmp[i] == '&' || tmp[i] == '~' || tmp[i] == '^'
			) == false)
		{
			tmp[i] = '_';
		}
	}
	
		if (tmp.length() > (20))
		{
			tmp.erase(20, (tmp.length() - 20));
			tmp.append("...");
		}
	return tmp;
}


void StdReplaceStr1(std::string& replaceIn, const std::string& replace, const std::string& replaceWith)
{
	size_t const span = replace.size();
	size_t const step = replaceWith.size();
	size_t index = 0;

	while (true)
	{
		index = replaceIn.find(replace, index);

		if (index == std::string::npos)
			break;

		replaceIn.replace(index, span, replaceWith);
		index += step;
	}
}

std::vector<std::string> configs;
void GetConfigMassive(int meme)
{
	//get all files on folder

	configs.clear();

	static char path[MAX_PATH];
	std::string szPath1;

	if (!SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
		return;

	szPath1 = meme == 0 ? (std::string(path) + XorStr("\\Spectro[maincfg]\\*")) : meme == 1 ? (std::string(path) + XorStr("\\Spectro[skincfg]\\*")) : (std::string(path) + XorStr("\\Spectro[colorcfg]\\*"));


	WIN32_FIND_DATA FindFileData;
	HANDLE hf;
	//configs.push_back("default.ini");

	hf = FindFirstFile(szPath1.c_str(), &FindFileData);
	if (hf != INVALID_HANDLE_VALUE) {
		do {
			std::string filename = FindFileData.cFileName;

			if (filename == ".")
				continue;

			if (filename == "..")
				continue;

			if (!(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			{
				if (filename.find(".ini") != std::string::npos)
				{
					configs.push_back(std::string(filename));
				}
			}
		} while (FindNextFile(hf, &FindFileData) != 0);
		FindClose(hf);
	}
}


static std::vector<char> ReadAllBytes(char const* filename)
{
	std::ifstream ifs(filename, std::ios::binary | std::ios::ate);
	std::ifstream::pos_type pos = ifs.tellg();

	std::vector<char>  result(pos);

	ifs.seekg(0, std::ios::beg);
	ifs.read(&result[0], pos);

	return result;
}


void DrawRagechildMeme(bool MenuNotOpened)
{
	ImGui::BeginChild(XorStr("RagebotChild1"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{

		static bool Main = true;
		static bool Accuracy = false;
		static bool HitScan = false;


		static bool  WeapCFG = false;

		ImGuiStyle& style = ImGui::GetStyle();


		style.ItemSpacing = ImVec2(1, 1);
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));


		if (ImGui::Button(XorStr("main"), ImVec2(ImGui::GetWindowWidth() / 3 - 8, 22)))
		{
			Main = true;
			Accuracy = false;
			HitScan = false;
		};
		ImGui::SameLine();
		if (ImGui::Button(XorStr("accuracy"), ImVec2(ImGui::GetWindowWidth() / 3 - 8, 22)))
		{
			Main = false;
			Accuracy = true;
			HitScan = false;
		};
		ImGui::SameLine();
		if (ImGui::Button(XorStr("hitscan"), ImVec2(ImGui::GetWindowWidth() / 3 - 8, 22)))
		{
			Main = false;
			Accuracy = false;
			HitScan = true;
		};


		ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
		style.ItemSpacing = ImVec2(8, 4);





		if (Main)
		{
			ImGui::Checkbox(XorStr("enable"), &g_Options.Ragebot.Ragebot_AimbotEnabled);
			ImGui::Checkbox(XorStr("silent-aim"), &g_Options.Ragebot.Ragebot_SilentAim);
			ImGui::Checkbox(XorStr("auto pistol"), &g_Options.Ragebot.AutoPistol);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("auto click in attack key"));
			ImGui::Checkbox(XorStr("auto revolver"), &g_Options.Ragebot.AutoRevolver);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("auto cocking"));

			ImGui::Checkbox(XorStr("no-interpolation"), &g_Options.Ragebot.LagComp);

			ImGui::Combo(XorStr("selection"), &g_Options.Ragebot.Ragebot_Selection, XorStr("fov\0\rdistance\0\rhealth\0\0"), -1, ImVec2(120, 0));
			ImGui::Combo(XorStr("hitbox"), &g_Options.Ragebot.Ragebot_Hitbox, XorStr("head\0\rneck\0\rchest\0\rpelvis\0\rarms\0\rlegs\0\rhitscan\0\0"), -1, ImVec2(120, 0));
			ImGui::Combo(XorStr("autowall type"), &g_Options.Ragebot.Ragebot_AutoWallMode, XorStr("spravedlivii\0\rne spravedlivii\0\0"), -1, ImVec2(120, 0));
			

			

		}
		if (Accuracy)
		{

			ImGui::Checkbox(XorStr("auto-shoot"), &g_Options.Ragebot.Ragebot_AutoShoot);
			ImGui::Checkbox(XorStr("auto-scope"), &g_Options.Ragebot.Ragebot_Autoscope);

			

			ImGui::PushItemWidth(120);
			ImGui::SliderFloat(XorStr("hit chance"), &g_Options.Ragebot.Ragebot_Hitchance, 1.f, 100.f);
			ImGui::SliderFloat(XorStr("min damage"), &g_Options.Ragebot.Ragebot_MinDamage, 1.f, 100.f);
			ImGui::PopItemWidth();
			
			ImGui::Checkbox(XorStr("anti-aim correction"), &g_Options.Ragebot.Ragebot_Resolver);
			ImGui::Checkbox(XorStr("override resolver"), &g_Options.Ragebot.Ragebot_Knopka180);
			ImGui::Hotkey(XorStr("key##overrideresolver"), &g_Options.Ragebot.Ragebot_Knopka180Val, ImVec2(120,20));

			ImGui::Checkbox(XorStr("position-adjustment"), &g_Options.Ragebot.Ragebot_PositionAdjustment);
			
		}
		if (HitScan)
		{
	

			ImGui::Text("custom hitscan");
			ImGui::Separator();
			ImGui::Checkbox(XorStr("head"), &g_Options.Ragebot.Ragebot_CustomHitscan[0]);
			ImGui::SameLine();
			ImGui::Checkbox(XorStr("neck"), &g_Options.Ragebot.Ragebot_CustomHitscan[1]);

			ImGui::Checkbox(XorStr("pelvis"), &g_Options.Ragebot.Ragebot_CustomHitscan[2]);
			ImGui::SameLine();
			ImGui::Checkbox(XorStr("body"), &g_Options.Ragebot.Ragebot_CustomHitscan[3]);
		
			ImGui::Checkbox(XorStr("arms"), &g_Options.Ragebot.Ragebot_CustomHitscan[4]);
			ImGui::SameLine();
			ImGui::Checkbox(XorStr("legs"), &g_Options.Ragebot.Ragebot_CustomHitscan[5]);

			ImGui::Spacing();
			ImGui::Spacing();
			ImGui::SameLine();
			ImGui::Spacing();
			ImGui::Spacing();




			ImGui::Columns(2, NULL, false);

			ImGui::Text("multipoint:");

			ImGui::Checkbox(XorStr("head "), &g_Options.Ragebot.MP[0]);
			ImGui::Checkbox(XorStr("neck "), &g_Options.Ragebot.MP[1]);
			ImGui::Checkbox(XorStr("pelvis "), &g_Options.Ragebot.MP[2]);
			ImGui::Checkbox(XorStr("body "), &g_Options.Ragebot.MP[3]);
			ImGui::Checkbox(XorStr("arms "), &g_Options.Ragebot.MP[4]);
			ImGui::Checkbox(XorStr("legs "), &g_Options.Ragebot.MP[5]);

			ImGui::NextColumn();

			ImGui::Text("scale:");


			SliderFloatFSTCustom(XorStr("##mps0"), g_Options.Ragebot.MPs[0], 0.01f, 1.f, 100);
			SliderFloatFSTCustom(XorStr("##mps1"), g_Options.Ragebot.MPs[1], 0.01f, 1.f, 100);
			SliderFloatFSTCustom(XorStr("##mps2"), g_Options.Ragebot.MPs[2], 0.01f, 1.f, 100);
			SliderFloatFSTCustom(XorStr("##mps3"), g_Options.Ragebot.MPs[3], 0.01f, 1.f, 100);
			SliderFloatFSTCustom(XorStr("##mps4"), g_Options.Ragebot.MPs[4], 0.01f, 1.f, 100);
			SliderFloatFSTCustom(XorStr("##mps5"), g_Options.Ragebot.MPs[5], 0.01f, 1.f, 100);

			ImGui::NextColumn();

		}


	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild2"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		static bool Stand = true;
		static bool Move = false;
		static bool Edge = false;
		static bool Misc = false;

		ImGui::Text("    anti aim system");
		ImGui::Separator();

		ImGui::Checkbox(XorStr("stand aa enabled"), &g_Options.Ragebot.AntiAim_Enabled);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr(" enable stand antiaim \n if you have velocity < 85 - aa type = stand antiaims"));

		ImGui::Checkbox(XorStr("move aa enabled"), &g_Options.Ragebot.AntiAim_EnabledMove);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr(" enable move antiaim \n if you have velocity > 85 - aa type = move antiaims"));

		ImGui::Checkbox(XorStr("edge aa enabled"), &g_Options.Ragebot.AntiAim_EnabledEdge);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr(" enable edge antiaim \n if you are near the wall - aa type = edge antiaims"));
		

		ImGui::Hotkey(XorStr("override aa key"),&g_Options.Ragebot.Ragebot_Knopka180ValAA, ImVec2(160,20));

		ImGui::Separator();

		ImGuiStyle& style = ImGui::GetStyle();
		style.ItemSpacing = ImVec2(1, 1);
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));


		ImGui::PushStyleColor(ImGuiCol_Button, Stand ? ImVec4(0.25f, 0.25f, 0.25f, 1.f) : ImVec4(0.1f, 0.1f, 0.1f, 1.f));

		if (ImGui::Button(XorStr("stand"), ImVec2(ImGui::GetWindowWidth() / 4 - 8, 22)))
		{
			Stand = true;
			Move = false;
			Misc = false;
			Edge = false;
		};

		ImGui::PopStyleColor();

		ImGui::SameLine();

		ImGui::PushStyleColor(ImGuiCol_Button, Move ? ImVec4(0.25f, 0.25f, 0.25f, 1.f) : ImVec4(0.1f, 0.1f, 0.1f, 1.f));

		if (ImGui::Button(XorStr("move"), ImVec2(ImGui::GetWindowWidth() / 4 - 8, 22)))
		{
			Stand = false;
			Move = true;
			Misc = false;
			Edge = false;
		};

		ImGui::PopStyleColor();

		ImGui::SameLine();

		ImGui::PushStyleColor(ImGuiCol_Button, Edge ? ImVec4(0.25f, 0.25f, 0.25f, 1.f) : ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		if (ImGui::Button(XorStr("edge"), ImVec2(ImGui::GetWindowWidth() / 4 - 8, 22)))
		{
			Stand = false;
			Move = false;
			Misc = false;
			Edge = true;
		};
		ImGui::PopStyleColor();


		ImGui::SameLine();
		ImGui::PushStyleColor(ImGuiCol_Button, Misc ? ImVec4(0.25f, 0.25f, 0.25f, 1.f) : ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		if (ImGui::Button(XorStr("misc"), ImVec2(ImGui::GetWindowWidth() / 4 - 8, 22)))
		{
			Stand = false;
			Move = false;
			Misc = true;
			Edge = false;
		};
		ImGui::PopStyleColor();

		ImGui::Text("  ");

		ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
		style.ItemSpacing = ImVec2(8, 4);

		
		if (Stand)
		{
			
			ImGui::Combo(XorStr("pitch"), &g_Options.Ragebot.AntiAim_Pitch, XorStr("none\0\rdown\0\rup\0\rminimal\0\rfake down\0\rfake up\0\rfake zero\0\rdownup\0\0"), -1, ImVec2(120, 0));
			
		
			
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("head angles x"));

		

			
			ImGui::Combo(XorStr("real yaw"), &g_Options.Ragebot.AntiAim_Yaw, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerbody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("real angles y"));

			
			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("add real yaw"), &g_Options.Ragebot.Ragebot_AddRealYaw, -180, 180); ImGui::PopItemWidth();
			
			

			ImGui::Combo(XorStr("fake yaw"), &g_Options.Ragebot.AntiAim_FakeYaw, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerBody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("fake angles y"));

			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("Add Fake yaw"), &g_Options.Ragebot.Ragebot_AddFakeYaw, -180, 180); ImGui::PopItemWidth();

			ImGui::Checkbox(XorStr("at targets"), &g_Options.Ragebot.AntiAim_AtTargets);
			

		}
		if (Move)
		{
			
			ImGui::Combo(XorStr("pitch"), &g_Options.Ragebot.AntiAim_PitchMove, XorStr("none\0\rdown\0\rup\0\rminimal\0\rfake down\0\rfake up\0\rfake zero\0\rdownup\0\0"), -1, ImVec2(120, 0));



			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("head angles x"));




			ImGui::Combo(XorStr("real yaw"), &g_Options.Ragebot.AntiAim_YawMove, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerbody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("real angles y"));

			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("add real yaw"), &g_Options.Ragebot.Ragebot_AddRealYawMove, -180, 180); ImGui::PopItemWidth();

			ImGui::Combo(XorStr("fake yaw"), &g_Options.Ragebot.AntiAim_FakeYawMove, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerBody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("fake angles y"));

			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("add fake yaw"), &g_Options.Ragebot.Ragebot_AddFakeYawMove, -180, 180); ImGui::PopItemWidth();

			ImGui::Checkbox(XorStr("at targets"), &g_Options.Ragebot.AntiAim_AtTargetsMove);

		}
		if (Edge)
		{
			
			ImGui::Combo(XorStr("pitch"), &g_Options.Ragebot.AntiAim_PitchEdge, XorStr("none\0\rdown\0\rup\0\rminimal\0\rfake down\0\rfake up\0\rfake zero\0\rdownup\0\0"), -1, ImVec2(120, 0));



			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("Head angles X"));




			ImGui::Combo(XorStr("real yaw"), &g_Options.Ragebot.AntiAim_YawEdge, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerbody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("real angles y"));

			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("add real yaw"), &g_Options.Ragebot.Ragebot_AddRealYawEdge, -180, 180); ImGui::PopItemWidth();

			ImGui::Combo(XorStr("fake yaw"), &g_Options.Ragebot.AntiAim_FakeYawEdge, "none\0\rbackwards\0\rbackwards jitter\0\rsideways\0\rfake lowerBody\0\rsquare jitter\0\0", -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("fake angles y"));

			ImGui::PushItemWidth(120); ImGui::SliderInt(XorStr("add fake yaw"), &g_Options.Ragebot.Ragebot_AddFakeYawEdge, -180, 180); ImGui::PopItemWidth();
		}
		if (Misc)
		{
			
			ImGui::Checkbox(XorStr("moon-walk"), &g_Options.Ragebot.Ragebot_MoonWalk);
			ImGui::Checkbox(XorStr("fake-walk"), &g_Options.Ragebot.Ragebot_FakeWalk);
			if (g_Options.Ragebot.Ragebot_FakeWalk)
			{
				ImGui::Hotkey(XorStr("key   "),&g_Options.Ragebot.Ragebot_FakeWalkKey,ImVec2(120,20));
			}
			SliderFloatFST(XorStr("lby delta"), g_Options.Ragebot.Ragebot_LBYDELTA, 0.f, 180.f); 
		}


	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild3"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		ImGui::Text("    body aim settings");
		ImGui::Separator();

	
		ImGui::Combo(XorStr("prefer baim"), &g_Options.Ragebot.Ragebot_PreferBodyAim, XorStr("off\0\rsmart\0\ralways\0\0"), -1, ImVec2(120, 0));
		ImGui::PushItemWidth(120);
		ImGui::SliderInt(XorStr("after x hp"), &g_Options.Ragebot.Ragebot_BodyAimAfterHP, 0, 100);
		ImGui::PopItemWidth();
		ImGui::Checkbox(XorStr("with awp"), &g_Options.Ragebot.Ragebot_BodyAwp);
		ImGui::Checkbox(XorStr("when fake"), &g_Options.Ragebot.BodyWhenFake);
		ImGui::Hotkey(XorStr("body key"),&g_Options.Ragebot.Ragebot_BodyKeyEnable, ImVec2(120,20));
		
	}ImGui::EndChild();
}
void DrawVisualschildMeme(bool MenuNotOpened)
{
	ImGui::BeginChild(XorStr("RagebotChild1"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{

		static bool Main = true;
		static bool Colors = false;

		static int Page = 0;

		ImGuiStyle& style = ImGui::GetStyle();


		style.ItemSpacing = ImVec2(1, 1);
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));

		const char* meme = "page : error";
		switch (Page)
		{
		case 0: meme = "page : 1";  break;
		case 1: meme = "page : 2";  break;
		case 2: meme = "page : 3";  break;
		case 3: meme = "page : 4";  break;
		case 4: meme = "page : 5";  break;
		default: break;
		}

		ImGui::Text(meme); ImGui::SameLine(); ImGui::Text(XorStr("                  ")); ImGui::SameLine();
		if (ImGui::Button(XorStr("-"), ImVec2(22, 22)))
		{
			if (Page != 0)
				Page--;
		};
		ImGui::SameLine();
		if (ImGui::Button(XorStr("+"), ImVec2(22, 22)))
		{
			if (Page != 3)
				Page++;
		};

		ImGui::Text(XorStr("        "));

		ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
		style.ItemSpacing = ImVec2(8, 4);
		

		switch (Page)
		{
		case 0:
		{
			ImGui::Checkbox(XorStr("enable visuals"), &g_Options.Visuals.Enabled);
			ImGui::Checkbox(XorStr("team esp"), &g_Options.Visuals.Visuals_EspTeam);
			ImGui::Checkbox(XorStr("visable only"), &g_Options.Visuals.Visuals_VisableOnly);



			ImGui::Checkbox(XorStr("draw box"), &g_Options.Visuals.Visuals_BoxEnabled);
			if (g_Options.Visuals.Visuals_BoxEnabled)
			{
				ImGui::Combo(XorStr("box type"), &g_Options.Visuals.Visuals_BoxType, XorStr("full\0\rcorner\0\0"), -1, ImVec2(120, 0));
			}
			ImGui::Checkbox(XorStr("draw health bar"), &g_Options.Visuals.Visuals_HealthBar);
			if (g_Options.Visuals.Visuals_HealthBar)
			{
				ImGui::Combo(XorStr("healthbar type"), &g_Options.Visuals.Visuals_HealthBarType, XorStr("default\0\rseparator\0\0"), -1, ImVec2(120, 0));
			}
			ImGui::Checkbox(XorStr("draw ammo bar"), &g_Options.Visuals.Visuals_AmmoESP);
			if (g_Options.Visuals.Visuals_AmmoESP)
			{
				ImGui::Combo(XorStr("type##ammobar"), &g_Options.Visuals.Visuals_AmmoESPType, XorStr("text\0\rbar\0\0"), -1, ImVec2(120, 0));
			}

			ImGui::Checkbox(XorStr("draw name"), &g_Options.Visuals.Visuals_Name);
			ImGui::Checkbox(XorStr("draw armor"), &g_Options.Visuals.Visuals_ArmorBar);
			ImGui::Checkbox(XorStr("draw weapons"), &g_Options.Visuals.Visuals_Weapons);
			if (g_Options.Visuals.Visuals_Weapons)
			{
				ImGui::Combo(XorStr("type##weapons"), &g_Options.Visuals.Visuals_WeaponsType, XorStr("text\0\ricons\0\0"), -1, ImVec2(120, 0));
			}
			ImGui::Checkbox(XorStr("draw skeleton"), &g_Options.Visuals.Visuals_Skeltal);
			



		}break;
		case 1:
		{
			ImGui::Checkbox(XorStr("draw aimlines"), &g_Options.Visuals.Visuals_AimLines);
			ImGui::Checkbox(XorStr("draw bomb"), &g_Options.Visuals.Visuals_C4);
			ImGui::Checkbox(XorStr("draw beam-lracer"), &g_Options.Visuals.Visuals_DrawBeams);
			if (g_Options.Visuals.Visuals_DrawBeams)
			{
				SliderFloatFST(XorStr("duration ##beamtracer"), g_Options.Visuals.Visuals_DrawBeamsDuration, 1.f, 10.f);
				SliderFloatFST(XorStr("ssize ##beamtracer"), g_Options.Visuals.Visuals_DrawBeamsSize, 0.1f, 10.f);

			}
			ImGui::Checkbox(XorStr("draw hit-capsule"), &g_Options.Visuals.Visuals_DrawCapsules);
			if (g_Options.Visuals.Visuals_DrawCapsules)
			{
				SliderFloatFST(XorStr("duration ##hitcapsule"), g_Options.Visuals.Visuals_DrawCapsulesDuration, 1.f, 10.f);
			}
			ImGui::Checkbox(XorStr("draw hit-marker"), &g_Options.Visuals.Visuals_Hitmarker);
			ImGui::Checkbox(XorStr("draw event log"), &g_Options.Visuals.Visuals_DrawEventLog);
			ImGui::Checkbox(XorStr("draw spread"), &g_Options.Visuals.Visuals_Spread);
			if (g_Options.Visuals.Visuals_Spread)
			{
				ImGui::Combo(XorStr("draw spread type"), &g_Options.Visuals.Visuals_Spread_Type, XorStr("outline\0\rfilled\0\0"), -1, ImVec2(120, 0));
			}
			ImGui::Checkbox(XorStr("grenade prediction"), &g_Options.Visuals.Visuals_GrenadePrediction);
			ImGui::Checkbox(XorStr("draw damage"), &g_Options.Visuals.Visuals_DamageESP);
		}break;
		case 2:
		{
			ImGui::Checkbox(XorStr("enable sound esp"), &g_Options.Visuals.SoundESP.Enabled);
			if (g_Options.Visuals.SoundESP.Enabled)
			{
				ImGui::Combo(XorStr("sound esp type"), &g_Options.Visuals.SoundESP.type, XorStr("rect\0\rwawes\0\0"), -1, ImVec2(120, 0));
				SliderFloatFST(XorStr(" distance"), g_Options.Visuals.SoundESP.Distance, 50.f, 1500.f);
				SliderFloatFST(XorStr(" radius"), g_Options.Visuals.SoundESP.Radius, 5.f, 25.f);
				ImGui::Checkbox(XorStr("animated"), &g_Options.Visuals.SoundESP.Animated);
				ImGui::SameLine();
				ImGui::Checkbox(XorStr("novis. only"), &g_Options.Visuals.SoundESP.visonly);

			}
			ImGui::Separator();
			ImGui::Checkbox(XorStr("engine radar"), &g_Options.Visuals.Visuals_EngineRadar);
			ImGui::Checkbox(XorStr("external radar"), &g_Options.Visuals.Panels.Radar.ExternalRadar);
			ImGui::Combo(XorStr("style"), &g_Options.Visuals.Panels.Radar.RadarStyle, XorStr("box\0filled box\0circle\0filled circle\0\0"), -1, ImVec2(120, 0));
			SliderFloatFST(XorStr("##RadarDistance"), g_Options.Visuals.Panels.Radar.RadarDistance, 0.1f, 5.0f);
			ImGui::Checkbox(XorStr("visible only"), &g_Options.Visuals.Panels.Radar.RadarVisibleOnly);
			ImGui::Checkbox(XorStr("smoke check"), &g_Options.Visuals.Panels.Radar.RadarSmoke);
			ImGui::Separator();
			ImGui::Checkbox(XorStr("monitor info"), &g_Options.Visuals.Panels.Monitor);
		}break;
		case 3:
		{
			ImGui::Checkbox(XorStr("lower body indicator"), &g_Options.Visuals.lbyIndicator);
			ImGui::Checkbox(XorStr("arrows indicator"), &g_Options.Visuals.strelkiIndicator);

			
		}break;

		default:break;
		}
	

	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild2"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
	
		ImGui::Checkbox(XorStr("chams"), &g_Options.Visuals.Visuals_Chams);
		ImGui::Checkbox(XorStr("chams on teammates"), &g_Options.Visuals.Visuals_ChamsTeam);
		ImGui::Checkbox(XorStr("chams on guns"), &g_Options.Visuals.Visuals_ChamsGuns);
		ImGui::Checkbox(XorStr("chams vis. only"), &g_Options.Visuals.Visuals_ChamsXQZ);
		ImGui::Checkbox(XorStr("chams on local fakes"), &g_Options.Visuals.Visuals_GhostAngle);
		ImGui::Combo(XorStr("chams material"), &g_Options.Visuals.Visuals_ChamsMaterial, XorStr("flat\0\rtextured\0\rgold\0\rmaterial\0\rdogtags outline\0\rglass\0\0"), -1, ImVec2(120, 0));
		ImGui::Separator();

		ImGui::Checkbox(XorStr("glow"), &g_Options.Visuals.Vis_Glow);
		ImGui::Checkbox(XorStr("glow teammates"), &g_Options.Visuals.Vis_Glow_Team);
		ImGui::Checkbox(XorStr("glow vis. only"), &g_Options.Visuals.Vis_Glow_Vis);

		


		ImGui::Separator();
		ImGui::Text("others");
		
		
		ImGui::Checkbox(XorStr("night-mode"), &g_Options.Visuals.Visuals_NightMode);
		ImGui::Checkbox(XorStr("asus-mode"), &g_Options.Visuals.Visuals_Asus);
		ImGui::Separator();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild3"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{

		ImGui::Checkbox(XorStr("scoped info"), &g_Options.Visuals.Visuals_Scoped);
		ImGui::Checkbox(XorStr("flashed info"), &g_Options.Visuals.Visuals_Flashed);
		ImGui::Checkbox(XorStr("defuser info"), &g_Options.Visuals.Visuals_Defuser);

		
		ImGui::Checkbox(XorStr("anti-aim lines"), &g_Options.Visuals.Visuals_DrawLinesAA);
		ImGui::Checkbox(XorStr("dropped weapons"), &g_Options.Visuals.Visuals_DroppedWeapons);
		ImGui::Checkbox(XorStr("no-visual recoil"), &g_Options.Visuals.Visuals_NoRecoil);

		ImGui::Checkbox(XorStr("no-flash"), &g_Options.Visuals.Visuals_NoFlash);
		ImGui::Checkbox(XorStr("no-smoke"), &g_Options.Visuals.Visuals_NoSmoke);
		if(g_Options.Visuals.Visuals_NoSmoke)
			ImGui::Checkbox(XorStr("set no-smoke wireframe var"), &g_Options.Visuals.Visuals_NoSmokeVar);

		ImGui::Checkbox(XorStr("no-scope"), &g_Options.Visuals.Visuals_NoScope);
		ImGui::Checkbox(XorStr("no-zoom"), &g_Options.Visuals.Visuals_NoZoom);
		ImGui::Checkbox(XorStr("no-postProcess"), &g_Options.Visuals.Visuals_NoPostProcess);


		ImGui::Checkbox(XorStr("crosshair"), &g_Options.Visuals.Visuals_Crosshair);
		if(g_Options.Visuals.Visuals_Crosshair)
		ImGui::Checkbox(XorStr("crosshair->dynamic"), &g_Options.Visuals.Visuals_CrosshairDynamic);

		/*ImGui::Checkbox(XorStr("Sky Change"), &g_Options.Visuals.Visuals_Sky);
		if (g_Options.Visuals.Visuals_Sky)
		ImGui::Combo(XorStr("Sky"), &g_Options.Visuals.Visuals_SkyVal, XorStr("NoSky\0\rNight\0\rNight2\0\0"), -1, ImVec2(120, 0));*/



	}ImGui::EndChild();

}
void DrawMiscchildMeme(bool MenuNotOpened)
{
	ImGui::BeginChild(XorStr("RagebotChild1"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{

		static bool Main = true;
		static bool Colors = false;
		static bool Colors1 = false;
		static bool meme1 = true;
		static bool meme2 = false;
		static bool meme3 = false;

		ImGuiStyle& style = ImGui::GetStyle();


		style.ItemSpacing = ImVec2(1, 1);
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));

		if (ImGui::Button(XorStr("main"), ImVec2(ImGui::GetWindowWidth() / 2 - 10, 22)))
		{
			Main = true;
			Colors = false;
			Colors1 = false;
		};
		ImGui::SameLine();

		if (ImGui::Button(XorStr("movement"), ImVec2(ImGui::GetWindowWidth() / 2 - 10, 22)))
		{
			Main = false;
			Colors = false;
			Colors1 = true;
		};
		ImGui::Text(XorStr("        "));

		ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
		style.ItemSpacing = ImVec2(8, 4);

	

		if (Main)
		{	
		ImGui::Separator();
		ImGui::Checkbox(XorStr("anti-untrusted"), &g_Options.Misc.AntiCheats.AntiUntrusted);
		ImGui::Checkbox(XorStr("menu-animations"), &g_Options.Menu.Animations);
		ImGui::Checkbox(XorStr("skin-changer window"), &g_Options.Menu.SkinChangerWindow);

		ImGui::Checkbox(XorStr("auto-accept"), &g_Options.Misc.Misc_AutoAccept);
		ImGui::SameLine();
		ImGui::Checkbox(XorStr("knife-bot"), &g_Options.Misc.Misc_KnifeBot);
		ImGui::Checkbox(XorStr("spectator-list"), &g_Options.Misc.SpectatorList);
		ImGui::SameLine();
		ImGui::Checkbox(XorStr("show ranks"), &g_Options.Misc.Misc_Ranks);
		ImGui::Checkbox(XorStr("playerlist"), &g_Options.Players.Playerlist);

		

		SliderIntFST(XorStr("override fov"), g_Options.Misc.Misc_Fov,0, 40);
		SliderIntFST(XorStr("viewmodel fov"), g_Options.Misc.ViewModelFov, 0, 150);

		ImGui::Separator();


		ImGui::Checkbox(XorStr("third-person"), &g_Options.Misc.Visuals_ThirdPerson);
		ImGui::Hotkey(XorStr("key   "), &g_Options.Misc.Visuals_ThirdPersonKey, ImVec2(120, 20));
		SliderIntFST(XorStr("third-person dist"), g_Options.Misc.Visuals_ThirdPersonDistance, 0, 300);
		ImGui::Combo(XorStr("show angle"), &g_Options.Misc.Visuals_ThirdPersonAngle, XorStr("fake\0\rreal\0\rlowerbody\0\0"), -1, ImVec2(120, 0));
		
		}
		
		if (Colors1)
		{
			ImGui::Separator();
			
			ImGui::Checkbox(XorStr("auto-jump"), &g_Options.Misc.Misc_AutoJump);
			if (g_Options.Misc.Misc_AutoJump)
				ImGui::Checkbox(XorStr("auto-strafe"), &g_Options.Misc.Misc_AutoStrafe);
			if (g_Options.Misc.Misc_AutoStrafe && g_Options.Misc.Misc_AutoJump)
				ImGui::Combo(XorStr("strafe type"), &g_Options.Misc.Misc_AutoStraferMode, XorStr("silent\0\rnormal\0\rsideways\0\rforward\0\0"), -1, ImVec2(120, 0));


			ImGui::Separator();


			ImGui::Combo(XorStr("fakelag type"), &g_Options.Misc.FakeLag.Misc_FakeLag, XorStr("off\0\rfactor\0\rsmart\0\radaptive\0\rswitch\0\radaptive2\0\rmaximum\0\0"), -1, ImVec2(120, 0));
			SliderIntFST(XorStr("fakelag factor"), g_Options.Misc.FakeLag.Misc_FakeLagFactor, 0, 14);

			ImGui::Separator();
		}

	}ImGui::EndChild();
	ImGui::SameLine();

	ImGui::BeginChild(XorStr("RagebotChild3"), ImVec2(0, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		static int pages = 0;
		static int Subpages = 0;
		ImGuiStyle& style = ImGui::GetStyle();

		style.ItemSpacing = ImVec2(1, 1);
		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));

		if (ImGui::Button(XorStr("config system"), ImVec2(ImGui::GetWindowWidth() / 2 - 10, 22)))
		{
			pages = 0;
			
		};
		ImGui::SameLine();
		if (ImGui::Button(XorStr("custom colors system"), ImVec2(ImGui::GetWindowWidth() / 2 - 10, 22)))
		{
			pages = 1;
			
		};
		
		

		ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
		style.ItemSpacing = ImVec2(8, 4);

		if (pages == 0)
		{
			style.ItemSpacing = ImVec2(1, 1);
			ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.1f, 0.1f, 1.f));
			ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.2f, 0.2f, 0.8f));
			ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.2f, 0.2f, 1.f));

			if (ImGui::Button(XorStr("main settings"), ImVec2(ImGui::GetWindowWidth() / 3, 22)))
			{
				Subpages = 0;

			};
			ImGui::SameLine();
			if (ImGui::Button(XorStr("skins"), ImVec2(ImGui::GetWindowWidth() / 3 - 20, 22)))
			{
				Subpages = 1;

			};
			ImGui::SameLine();
			if (ImGui::Button(XorStr(" colors "), ImVec2(ImGui::GetWindowWidth() / 3 - 20, 22)))
			{
				Subpages = 2;

			};
			ImGui::PopStyleColor(); ImGui::PopStyleColor(); ImGui::PopStyleColor();
			style.ItemSpacing = ImVec2(8, 4);

			ImGui::Text("");
			if (Subpages == 0)
			{
				
		

			GetConfigMassive(maincfg);

			static int selectedcfg = 0;
			static std::string cfgname = "new main cfg";


			if (ImGui::ListBox("##selectcfg ", &selectedcfg, [](void* data, int idx, const char** out_text)
			{
				*out_text = configs[idx].c_str();
				return true;
			}, nullptr, configs.size(), 5))
			{
				cfgname = configs[selectedcfg];
				cfgname.erase(cfgname.length() - 4, 4);
				strcpy(g_Options.Misc.configname, cfgname.c_str());
			}

			ImGui::PushItemWidth(280); ImGui::InputText(XorStr("name"), g_Options.Misc.configname, 128); ImGui::PopItemWidth();

			if (ImGui::Button(XorStr("save"), ImVec2(100.f, 20.f))) pConfig->Save(maincfg);
			ImGui::SameLine();
			if (ImGui::Button(XorStr("load"), ImVec2(100.f, 20.f))) {
				pConfig->Load(maincfg);
			}
			ImGui::SameLine();
			if (ImGui::Button(XorStr("delete"), ImVec2(100.f, 20.f))) {
				pConfig->Delete(maincfg);
			}

			static bool rename = false;
			if (!rename)
			{
				if (ImGui::Button(XorStr("rename"), ImVec2(100.f, 20.f))) rename = true;
			}
			else
			{
				static char newnamecfg[128] = "new name config";

				if (ImGui::Button(XorStr("apply"), ImVec2(100.f, 20.f)))
				{
					rename = false; pConfig->Rename(newnamecfg, maincfg);
				}
				ImGui::SameLine();
				ImGui::PushItemWidth(160); ImGui::InputText(XorStr("new name"), newnamecfg, 128); ImGui::PopItemWidth();
			}

		}

			if (Subpages == 1)
			{
					
				GetConfigMassive(skincfg);

				static int selectedcfg = 0;
				static std::string cfgname = "new skin cfg";


				if (ImGui::ListBox("##selectcfg ", &selectedcfg, [](void* data, int idx, const char** out_text)
				{
					*out_text = configs[idx].c_str();
					return true;
				}, nullptr, configs.size(), 5))
				{
					cfgname = configs[selectedcfg];
					cfgname.erase(cfgname.length() - 4, 4);
					strcpy(g_Options.Misc.confignameskins, cfgname.c_str());
				}

				ImGui::PushItemWidth(280); ImGui::InputText(XorStr("name"), g_Options.Misc.confignameskins, 128); ImGui::PopItemWidth();

				if (ImGui::Button(XorStr("save"), ImVec2(100.f, 20.f))) pConfigSkins->Save(skincfg);
				ImGui::SameLine();
				if (ImGui::Button(XorStr("load"), ImVec2(100.f, 20.f))) {
					pConfigSkins->Load(skincfg); g_Skinchanger->ForceItemUpdates();
				}
				ImGui::SameLine();
				if (ImGui::Button(XorStr("delete"), ImVec2(100.f, 20.f))) {
					pConfigSkins->Delete(skincfg);
				}

				static bool rename = false;
				if (!rename)
				{
					if (ImGui::Button(XorStr("rename"), ImVec2(100.f, 20.f))) rename = true;
				}
				else
				{
					static char newnamecfg[128] = "new name config";

					if (ImGui::Button(XorStr("apply"), ImVec2(100.f, 20.f)))
					{
						rename = false; pConfigSkins->Rename(newnamecfg, skincfg);
					}
					ImGui::SameLine();
					ImGui::PushItemWidth(160); ImGui::InputText(XorStr("new name"), newnamecfg, 128); ImGui::PopItemWidth();
				}

			}
			if (Subpages == 2)
			{

				GetConfigMassive(3);

				static int selectedcfg = 0;
				static std::string cfgname = "new skin cfg";


				if (ImGui::ListBox("##selectcfg ", &selectedcfg, [](void* data, int idx, const char** out_text)
				{
					*out_text = configs[idx].c_str();
					return true;
				}, nullptr, configs.size(), 5))
				{
					cfgname = configs[selectedcfg];
					cfgname.erase(cfgname.length() - 4, 4);
					strcpy(g_Options.Misc.confignameColors, cfgname.c_str());
				}

				ImGui::PushItemWidth(280); ImGui::InputText(XorStr("name"), g_Options.Misc.confignameColors, 128); ImGui::PopItemWidth();

				if (ImGui::Button(XorStr("save"), ImVec2(100.f, 20.f)))
				{


					
					DeclareToSave(pConfigColors->CTBoxVisable,Hacks.Colors.CTBoxVisable);
					DeclareToSave(pConfigColors->CTBoxInVisable, Hacks.Colors.CTBoxInVisable);
					DeclareToSave(pConfigColors->TBoxVisable, Hacks.Colors.TBoxVisable);
					DeclareToSave(pConfigColors->TBoxInVisable, Hacks.Colors.TBoxInVisable);
					DeclareToSave(pConfigColors->CTGlowVisable, Hacks.Colors.CTGlowVisable);
					DeclareToSave(pConfigColors->CTGlowInVisable, Hacks.Colors.CTGlowInVisable);
					DeclareToSave(pConfigColors->TGlowVisable, Hacks.Colors.TGlowVisable);
					DeclareToSave(pConfigColors->TGlowInVisable, Hacks.Colors.TGlowInVisable);
					DeclareToSave(pConfigColors->Beams, Hacks.Colors.Beams);
					DeclareToSave(pConfigColors->FilledSpread, Hacks.Colors.FilledSpread);
					DeclareToSave(pConfigColors->LagCompHitboxes, Hacks.Colors.LagCompHitboxes);
					DeclareToSave(pConfigColors->SoundESP, Hacks.Colors.SoundESP);
					DeclareToSave(pConfigColors->DamageESP, Hacks.Colors.DamageESP);
					DeclareToSave(pConfigColors->FakeAngleChams, Hacks.Colors.FakeAngleChams);
					DeclareToSave(pConfigColors->Stelki, Hacks.Colors.Stelki);

					DeclareToSave(pConfigColors->CTChamsVisable, Hacks.Colors.CTChamsVisable);
					DeclareToSave(pConfigColors->CTChamsInVisable, Hacks.Colors.CTChamsInVisable);
					DeclareToSave(pConfigColors->TChamsVisable, Hacks.Colors.TChamsVisable);
					DeclareToSave(pConfigColors->TChamsInVisable, Hacks.Colors.TChamsInVisable);








					pConfigColors->Save();
				}
				ImGui::SameLine();
				if (ImGui::Button(XorStr("load"), ImVec2(100.f, 20.f))) {
					pConfigColors->Load();

					
					
					DeclareToLoad(pConfigColors->CTBoxVisable, Hacks.Colors.CTBoxVisable);
					DeclareToLoad(pConfigColors->CTBoxInVisable, Hacks.Colors.CTBoxInVisable);
					DeclareToLoad(pConfigColors->TBoxVisable, Hacks.Colors.TBoxVisable);
					DeclareToLoad(pConfigColors->TBoxInVisable, Hacks.Colors.TBoxInVisable);
					DeclareToLoad(pConfigColors->CTGlowVisable, Hacks.Colors.CTGlowVisable);
					DeclareToLoad(pConfigColors->CTGlowInVisable, Hacks.Colors.CTGlowInVisable);
					DeclareToLoad(pConfigColors->TGlowVisable, Hacks.Colors.TGlowVisable);
					DeclareToLoad(pConfigColors->TGlowInVisable, Hacks.Colors.TGlowInVisable);
					DeclareToLoad(pConfigColors->Beams, Hacks.Colors.Beams);
					DeclareToLoad(pConfigColors->FilledSpread, Hacks.Colors.FilledSpread);
					DeclareToLoad(pConfigColors->LagCompHitboxes, Hacks.Colors.LagCompHitboxes);
					DeclareToLoad(pConfigColors->SoundESP, Hacks.Colors.SoundESP);
					DeclareToLoad(pConfigColors->DamageESP, Hacks.Colors.DamageESP);
		
					DeclareToLoad(pConfigColors->FakeAngleChams, Hacks.Colors.FakeAngleChams);
					DeclareToLoad(pConfigColors->Stelki, Hacks.Colors.Stelki);

					
					DeclareToLoad(pConfigColors->CTChamsVisable, Hacks.Colors.CTChamsVisable);
					DeclareToLoad(pConfigColors->CTChamsInVisable, Hacks.Colors.CTChamsInVisable);
					DeclareToLoad(pConfigColors->TChamsVisable, Hacks.Colors.TChamsVisable);
					DeclareToLoad(pConfigColors->TChamsInVisable, Hacks.Colors.TChamsInVisable);

				}
				ImGui::SameLine();
				if (ImGui::Button(XorStr("delete"), ImVec2(100.f, 20.f))) {
					pConfigColors->Delete();
				}

				static bool rename = false;
				if (!rename)
				{
					if (ImGui::Button(XorStr("rename"), ImVec2(100.f, 20.f))) rename = true;
				}
				else
				{
					static char newnamecfg[128] = "new name config";

					if (ImGui::Button(XorStr("apply"), ImVec2(100.f, 20.f)))
					{
						rename = false; pConfigColors->Rename(newnamecfg);
					}
					ImGui::SameLine();
					ImGui::PushItemWidth(160); ImGui::InputText(XorStr("new name"), newnamecfg, 128); ImGui::PopItemWidth();
				}

			}
		}
		

		if (pages == 1)
		{
			ImGui::Text("");
			for (int i = 0; i < IM_ARRAYSIZE(colors); i++)
				colorNames[i] = colors[i].name;
			static int colorSelected = 0;
			
			ImGui::BeginChild(XorStr("RagebotChild4"), ImVec2(210, 0), 0.f, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize);
			{
				ImGui::PushItemWidth(195);
				ImGui::ListBox("##COLORSELECTION", &colorSelected, colorNames, IM_ARRAYSIZE(colorNames), 13);
				ImGui::PopItemWidth();
			}ImGui::EndChild();
			ImGui::SameLine();
			ImGui::BeginChild(XorStr("RagebotChild5"), ImVec2(0, 0), 0.f, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize);
			{
			ImGui::NextColumn();
			{
				/*
				float col[4] = { min(255.f, ColorForMenu(colorSelected).r() / 255.f),  min(255.f, ColorForMenu(colorSelected).g() / 255.f),  min(255.f, ColorForMenu(colorSelected).b() / 255.f),min(255.f, ColorForMenu(colorSelected).a() / 255.f) };

				 if(ColorPicker4New(col))

				ColorForMenu(colorSelected) = CColor((BYTE)(col[0] * 255), (BYTE)(col[1] * 255), (BYTE)(col[2] * 255), (BYTE)(col[3] * 255));*/

				

				
				float col[4];
				CColor Dcol = CColor(255, 255, 255, 255);

				switch (colorSelected)
				{
				case 0: 
					Dcol = Hacks.Colors.CTBoxVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTBoxVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 1: //if (ImGui::ColorEdit4("##meme", col,true,true))
					Dcol = Hacks.Colors.CTBoxInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTBoxInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 2:
					Dcol = Hacks.Colors.TBoxVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TBoxVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 3: 
					Dcol = Hacks.Colors.TBoxInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TBoxInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 4: 
					Dcol = Hacks.Colors.CTGlowVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTGlowVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 5: 
					Dcol = Hacks.Colors.CTGlowInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTGlowInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 6:
					Dcol = Hacks.Colors.TGlowVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TGlowVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;

				case 7:
					Dcol = Hacks.Colors.TGlowInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TGlowInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 8: 
					Dcol = Hacks.Colors.Beams;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					 if(ColorPicker4New(col))
					Hacks.Colors.Beams = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 9:
					Dcol = Hacks.Colors.FilledSpread;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.FilledSpread = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;

				case 10:
					Dcol = Hacks.Colors.LagCompHitboxes;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.LagCompHitboxes = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 11:
					Dcol = Hacks.Colors.CTChamsVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTChamsVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 12:
					Dcol = Hacks.Colors.CTChamsInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.CTChamsInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 13:
					Dcol = Hacks.Colors.TChamsVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TChamsVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 14:
					Dcol = Hacks.Colors.TChamsInVisable;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.TChamsInVisable = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 15:
					Dcol = Hacks.Colors.FakeAngleChams;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.FakeAngleChams = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 16:
					Dcol = Hacks.Colors.SoundESP;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.SoundESP = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 17:
					Dcol = Hacks.Colors.DamageESP;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.DamageESP = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;
				case 18:
					Dcol = Hacks.Colors.Stelki;
					col[0] = Dcol.r() / 255.f;
					col[1] = Dcol.g() / 255.f;
					col[2] = Dcol.b() / 255.f;
					col[3] = Dcol.a() / 255.f;
					if (ColorPicker4New(col))
						Hacks.Colors.Stelki = CColor(col[0] * 255.f, col[1] * 255.f, col[2] * 255.f, col[3] * 255.f); break;

					
				default:break;

				}
				
			}
			}ImGui::EndChild();

		}
	}ImGui::EndChild();

}
std::string GetWeaponName3()
{
	int id = g_Options.wpn;

	switch (id)
	{
	case WEAPON_DEAGLE:
		return XorStr("desert eagle");
	case WEAPON_ELITE:
		return XorStr("dual berettas");
	case WEAPON_FIVESEVEN:
		return XorStr("five-seveN");
	case WEAPON_GLOCK:
		return XorStr("glock-18");
	case WEAPON_AK47:
		return XorStr("ak-47");
	case WEAPON_AUG:
		return XorStr("aug");
	case WEAPON_AWP:
		return XorStr("awp");
	case WEAPON_FAMAS:
		return XorStr("famas");
	case WEAPON_G3SG1:
		return XorStr("g3sg1");
	case WEAPON_GALILAR:
		return XorStr("galil");
	case WEAPON_M249:
		return XorStr("m249");
	case WEAPON_M4A1:
		return XorStr("m4a1");
	case WEAPON_MAC10:
		return XorStr("mac-10");
	case WEAPON_P90:
		return XorStr("p90");
	case WEAPON_UMP45:
		return XorStr("ump-45");
	case WEAPON_XM1014:
		return XorStr("xm1014");
	case WEAPON_BIZON:
		return XorStr("pp-bizon");
	case WEAPON_MAG7:
		return XorStr("mag-7");
	case WEAPON_NEGEV:
		return XorStr("negev");
	case WEAPON_SAWEDOFF:
		return XorStr("sawed-off");
	case WEAPON_TEC9:
		return XorStr("tec-9");
	case WEAPON_TASER:
		return XorStr("taser");
	case WEAPON_HKP2000:
		return XorStr("p2000");
	case WEAPON_MP7:
		return XorStr("mp7");
	case WEAPON_MP9:
		return XorStr("mp9");
	case WEAPON_NOVA:
		return XorStr("nova");
	case WEAPON_P250:
		return XorStr("p250");
	case WEAPON_SCAR20:
		return XorStr("scar-20");
	case WEAPON_SG556:
		return XorStr("sg 553");
	case WEAPON_SSG08:
		return XorStr("ssg 08");
	case WEAPON_KNIFE:
		return XorStr("knife");
	case WEAPON_FLASHBANG:
		return XorStr("flashbang");
	case WEAPON_HEGRENADE:
		return XorStr("he grenade");
	case WEAPON_SMOKEGRENADE:
		return XorStr("smoke grenade");
	case WEAPON_MOLOTOV:
		return XorStr("molotov");
	case WEAPON_DECOY:
		return XorStr("decoy");
	case WEAPON_INCGRENADE:
		return XorStr("incendiary grenade");
	case WEAPON_C4:
		return XorStr("c4");
	case WEAPON_KNIFE_T:
		return XorStr("knife");
	case WEAPON_M4A1_SILENCER:
		return XorStr("m4a1-S");
	case WEAPON_USP_SILENCER:
		return XorStr("usp-s");
	case WEAPON_CZ75A:
		return XorStr("cz75-auto");
	case WEAPON_REVOLVER:
		return XorStr("r8 revolver");
	default:
		return XorStr("knife");
	}

	return "";
}
bool sPistolmeme(int WeaponId)
{
	return WeaponId == WEAPON_DEAGLE || WeaponId == WEAPON_ELITE || WeaponId == WEAPON_FIVESEVEN || WeaponId == WEAPON_P250 ||
		WeaponId == WEAPON_GLOCK || WeaponId == WEAPON_USP_SILENCER || WeaponId == WEAPON_CZ75A || WeaponId == WEAPON_HKP2000 || WeaponId == WEAPON_TEC9 /*|| WeaponId == weapon_revolver*/;
}
void DrawlegitchildMeme(bool MenuNotOpened)
{
	//	ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.36f, 0.36f, 0.36f, 1.0f));
	//	ImGui::PushStyleColor(ImGuiCol_BorderShadow, ImVec4(0.05f, 1.0f, 0.05f, 0.f));

	ImGui::BeginChild(XorStr("RagebotChild1"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		ImGui::Text(XorStr("aimbot Settings"));
		ImGui::Separator();

		ImGui::Checkbox(XorStr("enable aimbot"), &g_Options.NewLegitbot.Aimbot.Enabled);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("enable future aimbot"));

		ImGui::Checkbox(XorStr("draw fov"), &g_Options.NewLegitbot.Aimbot.DrawFOV);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("drawing current fov aimbot"));

		ImGui::Checkbox(XorStr("auto pistol"), &g_Options.NewLegitbot.Aimbot.AutoPistol);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("auto click in attack key"));

		ImGui::Checkbox(XorStr("backTrack"), &g_Options.NewLegitbot.Aimbot.BackTracking);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("backTrack to mexico"));
		//	ImGui::Checkbox(XorStr("Aim on Key"), &g_Options.NewLegitbot.Aimbot.OnKey);

		/*ImGui::Checkbox(XorStr("FOV Distance Based"), &g_Options.NewLegitbot.Aimbot.DistanceBased);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("Calculate FOV to player and Distance"));*/

		ImGui::Hotkey(XorStr("aimbot key##legit"), &g_Options.NewLegitbot.Aimbot.Key, ImVec2(130, 23));
		

		ImGui::Checkbox(XorStr("friendly fire"), &g_Options.NewLegitbot.Aimbot.FriendlyFire);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("aim at teammates"));

		ImGui::Checkbox(XorStr("smoke check"), &g_Options.NewLegitbot.Aimbot.SmokeCheck);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("if enemy is behind smoke, aim wont work"));

		ImGui::Checkbox(XorStr("flash Check"), &g_Options.NewLegitbot.Aimbot.FlashCheck);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("if you was flashed, aim dont work"));

		if (g_Options.NewLegitbot.Aimbot.FlashCheck)
		{
			if (g_Options.NewLegitbot.Aimbot.FlashCheckAlpha > 255.f)g_Options.NewLegitbot.Aimbot.FlashCheckAlpha = 255.f;
			if (g_Options.NewLegitbot.Aimbot.FlashCheckAlpha < 0.f) g_Options.NewLegitbot.Aimbot.FlashCheckAlpha = 0.f;

			SliderFloatFST(XorStr("flash check alpha"), g_Options.NewLegitbot.Aimbot.FlashCheckAlpha, 0.f, 255.f);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("if you was flashed and white screen alpha > flash check alpha, aim dont work"));
		}

		ImGui::Checkbox(XorStr("jump check"), &g_Options.NewLegitbot.Aimbot.JumpCheck);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("if you in air, aim wont work"));


		ImGui::Checkbox(XorStr("killdelay"), &g_Options.NewLegitbot.Aimbot.bKillDelay);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("enable kill delay"));
		
		SliderFloatFST(XorStr("killdelay amount"), g_Options.NewLegitbot.Aimbot.iKillDelay, 0.f, 2.f);
		if (ImGui::IsItemHovered())
			ImGui::SetTooltip(XorStr("if delay running, aim wont work"));


	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild2"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		//if (g_pEngine->IsConnected())
		//	ImGui::Text(XorStr("Settings for %s"), GetWeaponName3().c_str());
		//else
		//	ImGui::Text(XorStr("Not alive/unknown weapon"));

		if (g_Options.wpn > 0)
		{
			ImGui::Text(XorStr("settings for %s"), GetWeaponName3().c_str());
			ImGui::Separator();

			
			ImGui::Checkbox(XorStr("enabled for cur. weapon"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Enabled);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("enable aimbot with this Weapon ?"));


			ImGui::Combo(XorStr("aimbot type"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Aimtype, XorStr("bullet CFG\0\rsticky\0\0"), -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("type aimbot"));
			ImGui::Combo(XorStr("smooth type"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].SmoothType, XorStr("normal\0\rcurve\0\0"), -1, ImVec2(120, 0));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("smooth type aiming"));

			ImGui::Checkbox(XorStr("nearest bone"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Nearest);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("aims at nearest to crosshair bone"));
			ImGui::Checkbox(XorStr("nearest rcs lock"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].NearestRCS);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr(" nearest bone with calc rcs \n if you start rcs, old aimbone = current aimbone"));

			
			if (!g_Options.NewLegitbot.Weapon[g_Options.wpn].Nearest) {
				//ImGui::Combo(XorStr("Hitbox"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Bone, XorStr("PELVIS\0\r\0\r\0\rHIP\0\rLOWER SPINE\0\rMIDDLE SPINE\0\rUPPER SPINE\0\rNECK\0\rHEAD\0\0"), -1);
				//ImGui::InputInt(XorStr("Hitbox"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Bone);
				ImGui::Combo(XorStr("hitbox"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Bone, XorStr("head\0\rneck\0\rlower neck\0\rpelvis\0\rchest\0\rlower chest\0\rstomach\0\rlower stomach\0\0"), -1, ImVec2(120, 0));
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("aimbot hitbox"));
			}



			ImGui::Checkbox(XorStr("psilent"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].pSilent);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("perfect silent aim"));
			if (g_Options.NewLegitbot.Weapon[g_Options.wpn].pSilent)
			{
				ImGui::PushItemWidth(120);
				ImGui::SliderFloat(XorStr("psilent hitchance"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].pSilentHitChance, 1.f, 100.f);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("when hitchance > your value psilent will work"));

				ImGui::SliderFloat(XorStr("psilent fov"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].pSilentFov, 0.1f, 10.f);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("aimbot field of view for psilent"));
				ImGui::PopItemWidth();
			}
			ImGui::PushItemWidth(120);
			ImGui::SliderFloat(XorStr("fov"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Fov, 0.1f, 20.f);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("aimbot field of view"));


			if (g_Options.NewLegitbot.Weapon[g_Options.wpn].SmoothType == 0)ImGui::TextColored(ImVec4(1.f,0.f,0.f,1.f) , "lower smooth for faster aiming");
			if (g_Options.NewLegitbot.Weapon[g_Options.wpn].SmoothType == 1)ImGui::TextColored(ImVec4(1.f, 0.f, 0.f, 1.f), "higher smooth for faster aiming");
			ImGui::SliderFloat(XorStr("smooth"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].Smooth, 0.1f, 25.f);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip(XorStr("aimbot smoothness"));



			ImGui::PopItemWidth();

			if (g_Options.wpn == WEAPON_AWP || g_Options.wpn == WEAPON_SSG08)
			{
				ImGui::Checkbox(XorStr("fast-zoom"), &g_Options.NewLegitbot.Aimbot.FastZoom);
			}
			else
			{
				
				ImGui::PushItemWidth(120);
				ImGui::SliderFloat(XorStr("rcs speed x"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].RcsX, 1.f, 100.f);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("recoil control system  vertical"));
				ImGui::SliderFloat(XorStr("rcs speed y"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].RcsY, 1.f, 100.f);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("recoil control system horizontal"));
				ImGui::PopItemWidth();

			}
	
			int maxbullets = BulletSizeByMenu(g_Options.wpn);

			if (g_Options.NewLegitbot.Weapon[g_Options.wpn].StartBullet > maxbullets) g_Options.NewLegitbot.Weapon[g_Options.wpn].StartBullet = maxbullets;
			if (g_Options.NewLegitbot.Weapon[g_Options.wpn].EndBullet > maxbullets) g_Options.NewLegitbot.Weapon[g_Options.wpn].EndBullet = maxbullets;


				ImGui::PushItemWidth(120);
				ImGui::SliderInt(XorStr("bullet control one value"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].StartBullet, 1, maxbullets);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("aimbot after x bullet start"));
				ImGui::SliderInt(XorStr("bullet control two value"), &g_Options.NewLegitbot.Weapon[g_Options.wpn].EndBullet, 1, maxbullets);
				if (ImGui::IsItemHovered())
					ImGui::SetTooltip(XorStr("aimbot after x bullet end"));

				ImGui::PopItemWidth();
		


		}
		else
		{
			ImGui::Text(XorStr("invalid weapon"));
			ImGui::Separator();
		}

	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild(XorStr("RagebotChild3"), ImVec2(ImGui::GetWindowWidth() / 3 - 10, 0), true, MenuNotOpened ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
	{
		ImGui::Text(XorStr("triggerbot settings"));
		ImGui::Separator();
		ImGui::Checkbox(XorStr("enable   "), &g_Options.NewLegitbot.Triggerbot.Enabled);
		ImGui::SameLine();
		ImGui::Checkbox(XorStr("ignore key"), &g_Options.NewLegitbot.Triggerbot.AutoFire);
		if (g_Options.NewLegitbot.Triggerbot.AutoFire == false)
		{
			ImGui::PushItemWidth(120);
			ImGui::Hotkey(XorStr("key     "), &g_Options.NewLegitbot.Triggerbot.Key, ImVec2(120, 23));
			ImGui::PopItemWidth();
		}
		
		ImGui::Checkbox(XorStr("hit chance"), &g_Options.NewLegitbot.Triggerbot.HitChance);

		ImGui::PushItemWidth(120);
		ImGui::SliderFloat(XorStr("amount"), &g_Options.NewLegitbot.Triggerbot.HitChanceAmt, 1.f, 100.f, "%.0f");
		ImGui::PopItemWidth();


		ImGui::PushItemWidth(120);
		ImGui::SliderInt(XorStr("delay"), &g_Options.NewLegitbot.Triggerbot.Delay, 1, 200);
		ImGui::PopItemWidth();
		ImGui::Text("");

		ImGui::BeginChild(XorStr("filter"), ImVec2(ImGui::GetWindowContentRegionWidth() * 0.5f, 19 * 6));
		{
			ImGui::Selectable(XorStr("head"), &g_Options.NewLegitbot.Triggerbot.Filter.Head);
			ImGui::Selectable(XorStr("chest"), &g_Options.NewLegitbot.Triggerbot.Filter.Chest);
			ImGui::Selectable(XorStr("stomach"), &g_Options.NewLegitbot.Triggerbot.Filter.Stomach);
			ImGui::Selectable(XorStr("arms"), &g_Options.NewLegitbot.Triggerbot.Filter.Arms);
			ImGui::Selectable(XorStr("legs"), &g_Options.NewLegitbot.Triggerbot.Filter.Legs);
			ImGui::Selectable(XorStr("teammates"), &g_Options.NewLegitbot.Triggerbot.Filter.Friendly);
		}
		ImGui::EndChild();

	}ImGui::EndChild();

	//	ImGui::PopStyleColor();
	//	ImGui::PopStyleColor();
}
class VectorRadar2D
{
public:
	VectorRadar2D() {}
	VectorRadar2D(float x_, float y_) { x = x_; y = y_; }
public:
	float x, y;
};
VectorRadar2D RotatePoint(Vector vecEntity, Vector vecLocal, int iPosX, int iPosY, int iSizeX, int iSizeY, float angle, float zoom, bool* bView, bool bRadians)
{
	float r_1, r_2;
	float x_1, y_1;

	r_1 = -(vecEntity.y - vecLocal.y);
	r_2 = vecEntity.x - vecLocal.x;
	float flYaw = angle - 90.0f;

	float flRad = flYaw * (3.14159265358979323846f / 180.0F);
	x_1 = (float)(r_2 * (float)cos((double)(flRad)) - r_1 * sin((double)(flRad))) / 20;
	y_1 = (float)(r_2 * (float)sin((double)(flRad)) + r_1 * cos((double)(flRad))) / 20;

	*bView = y_1 < 0;

	x_1 *= zoom;
	y_1 *= zoom;

	int sizeX = iSizeX / 2;
	int sizeY = iSizeY / 2;

	x_1 += sizeX;
	y_1 += sizeY;

	if (x_1 < 5)
		x_1 = 5;

	if (x_1 > iSizeX - 5)
		x_1 = iSizeX - 5;

	if (y_1 < 5)
		y_1 = 5;

	if (y_1 > iSizeY - 5)
		y_1 = iSizeY - 5;


	x_1 += iPosX;
	y_1 += iPosY;


	return VectorRadar2D(x_1, y_1);
}

void RenderMonitor()
{
	if (!Interfaces.pEngine->IsConnected())
		return;

	if (!Interfaces.pEngine->IsInGame())
		return;

	CBaseEntity* pLocal = G::LocalPlayer;

	if (!pLocal)
		return;

	if (!pLocal->isAlive())
		return;

	if (pLocal->IsDormant())
		return;

	if (ImGui::Begin(XorStr("Monitor"), &g_Options.Visuals.Panels.Monitor, ImVec2(200, 250), 1.0F, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize))
	{
		ImDrawList* windowDrawList = ImGui::GetWindowDrawList();

		ImVec2 siz = ImGui::GetWindowSize();
		ImVec2 pos = ImGui::GetWindowPos();
		CBaseCombatWeapon* pWeapon = G::LocalPlayer->GetActiveBaseCombatWeapon();
		if (pWeapon)
		{
			float accuracy = pWeapon->GetInaccuracy() * 550.f;

			if (accuracy > 179)
				accuracy = 179;

			int iSpeed = 0;
			Vector vSpeed = pLocal->GetVecVelocity();
			iSpeed = (int)vSpeed.Length2D();

			int iBoost = 0;
			Vector vBoost = pLocal->GetVecVelocity();
			iBoost = (int)vBoost.Length2D() - 300;

			float flPunch = 0.0f;
			Vector vRecoil = pLocal->GetPunchAngle();
			flPunch = (float)vRecoil.Length();

			if (iSpeed < 300)
				windowDrawList->AddText(ImVec2(pos.x + 25, pos.y + 1 + 217), CColor(255, 255, 255, 255).GetU32(), XorStr("Speed"));
			if (iSpeed > 300)
				windowDrawList->AddText(ImVec2(pos.x + 25, pos.y + 1 + 217), CColor(255, 0, 0, 255).GetU32(), XorStr("Boost"));
			windowDrawList->AddText(ImVec2(pos.x + 85, pos.y + 1 + 217), CColor(255, 255, 255, 255).GetU32(), XorStr("Recoil"));
			windowDrawList->AddText(ImVec2(pos.x + 145, pos.y + 1 + 217), CColor(255, 255, 255, 255).GetU32(), XorStr("Spread"));

			windowDrawList->AddRect(ImVec2(pos.x + 147, pos.y + 35), ImVec2(pos.x + 147 + 25, pos.y + 35 + 180), CColor(0, 0, 0, 255).GetU32());
			windowDrawList->AddRect(ImVec2(pos.x + 87, pos.y + 35), ImVec2(pos.x + 87 + 25, pos.y + 35 + 180), CColor(0, 0, 0, 255).GetU32());
			windowDrawList->AddRect(ImVec2(pos.x + 28, pos.y + 35), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), CColor(0, 0, 0, 255).GetU32());

			if (iSpeed < 300)
				windowDrawList->AddRectFilled(ImVec2(pos.x + 28, pos.y + 35 + 180 - (iSpeed * 0.6)), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), CColor(255, 255, 255, 255).GetU32());

			if (iSpeed > 300)
				windowDrawList->AddRectFilled(ImVec2(pos.x + 28, pos.y + 35 + 180 - (iBoost * 0.2)), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), CColor(255, 0, 0, 255).GetU32());

			windowDrawList->AddRectFilled(ImVec2(pos.x + 147, pos.y + 35 + 180 - accuracy), ImVec2(pos.x + 147 + 25, pos.y + 35 + 180), CColor(255, 255, 255, 255).GetU32());
			windowDrawList->AddRectFilled(ImVec2(pos.x + 87, pos.y + 35 + 180 - flPunch * 30), ImVec2(pos.x + 87 + 25, pos.y + 35 + 180), CColor(255, 255, 255, 255).GetU32());

			ImGui::End();
		}
	}
}

void RenderRadar()
{
	ImGuiStyle& style = ImGui::GetStyle();
	ImVec2 oPadding = style.WindowPadding;
	float oAlpha = style.Colors[ImGuiCol_WindowBg].w;

	style.WindowPadding = ImVec2(0, 0);
	style.Colors[ImGuiCol_WindowBg].w = (float)255 / 255.0f;

	if (ImGui::Begin(XorStr("Radar"), &g_Options.Visuals.Panels.Radar.ExternalRadar, ImVec2(200, 200), 0.5F, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse))
	{

		ImVec2 siz = ImGui::GetWindowSize();
		ImVec2 pos = ImGui::GetWindowPos();

		ImDrawList* windowDrawList = ImGui::GetWindowDrawList();

		 CColor Black = CColor(255, 255, 255, 255);
		 CColor Red = CColor(255, 0, 0, 255);
		 CColor Purple = CColor(255, 0, 255, 255);
		 CColor Cyan = CColor(0, 150, 255, 255);
		 CColor Blue = CColor(0, 0, 255, 255);


		windowDrawList->AddLine(ImVec2(pos.x + (siz.x / 2), pos.y + 0), ImVec2(pos.x + (siz.x / 2), pos.y + siz.y), Black.GetU32(), 1.5f);
		windowDrawList->AddLine(ImVec2(pos.x + 0, pos.y + (siz.y / 2)), ImVec2(pos.x + siz.x, pos.y + (siz.y / 2)), Black.GetU32(), 1.5f);

		// Rendering players
		if (Interfaces.pEngine->IsInGame() && Interfaces.pEngine->IsConnected())
		{
			CBaseEntity* pLocal = G::LocalPlayer;
			if (pLocal)
			{
				Vector vecLocal = pLocal->GetEyePosition();
				Vector ang;
				Interfaces.pEngine->GetViewAngles(ang);
				for (int i = 1; i < 65; i++)
				{
					CBaseEntity* pEntity = Interfaces.pEntList->GetClientEntity(i);

					if (!pEntity)
						continue;
					if (pEntity == pLocal)
						continue;
					if (!pEntity->isAlive())
						continue;
					if (pEntity->IsDormant())
						continue;
				
			
					player_info_t player_info;
					if (!Interfaces.pEngine->GetPlayerInfo(i, &player_info))continue;
				
					bool bVisible = pEntity->IsVisible(8);
					bool preVis = G::LineToSmoke(pEntity->GetBonePos(8), pLocal->GetEyePosition(), true);
					bool bViewCheck = false;
					VectorRadar2D vecEntity = RotatePoint(pEntity->GetAbsOrigin(), vecLocal, pos.x, pos.y, siz.x, siz.y, ang.y, g_Options.Visuals.Panels.Radar.RadarDistance, &bViewCheck, false);

				
					if (pEntity->GetTeam() == G::LocalPlayer->GetTeam() && !g_Options.Visuals.Visuals_EspTeam)
						continue;

					if (g_Options.Visuals.Panels.Radar.RadarVisibleOnly && !bVisible)
						continue;
					if (g_Options.Visuals.Panels.Radar.RadarSmoke && !preVis)
						continue;

					int rad = 4;
					ImU32 clr = (pEntity->IsEnemy() ? (bVisible ? Red.GetU32() : Purple.GetU32()) : (bVisible ? Cyan.GetU32() : Blue.GetU32()));

					switch (g_Options.Visuals.Panels.Radar.RadarStyle)
					{
					case 0:
						windowDrawList->AddRect(ImVec2(vecEntity.x - rad, vecEntity.y - rad), ImVec2(vecEntity.x + rad, vecEntity.y + rad), clr);
						break;
					case 1:
						windowDrawList->AddRectFilled(ImVec2(vecEntity.x - rad, vecEntity.y - rad), ImVec2(vecEntity.x + rad, vecEntity.y + rad), clr);
						break;
					case 2:
						windowDrawList->AddCircle(ImVec2(vecEntity.x, vecEntity.y), rad, clr);
						break;
					case 3:
						windowDrawList->AddCircleFilled(ImVec2(vecEntity.x, vecEntity.y), rad, clr);
						break;
					default:
						break;
					}
				}
			}
		}
	}
	ImGui::End();

	style.WindowPadding = oPadding;
	style.Colors[ImGuiCol_WindowBg].w = oAlpha;
}
void PlayerList()
{
	ImGui::SetNextWindowSize(ImVec2(300, 500), ImGuiSetCond_FirstUseEver);
	if (ImGui::Begin(XorStr("Player list"), &g_Options.Players.Playerlist, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders))
	{
		static int currentPlayer = -1;

		if (!Interfaces.pEngine->IsInGame())
			currentPlayer = -1;

		ImGui::ListBoxHeader(XorStr("##PLAYERS"), ImVec2(-1, (ImGui::GetWindowSize().y - 135)));
		{
			if (Interfaces.pEngine->IsInGame())
			{
				for (int i = 1; i < 65; i++)
				{

					if (i == Interfaces.pEngine->GetLocalPlayer())
						continue;

					CBaseEntity* Target = Interfaces.pEntList->GetClientEntity(i);
					if (!Target)
						continue;
					if (Target->GetClientClass()->m_ClassID != 35)
						continue;

					if (Target->GetTeam() == G::LocalPlayer->GetTeam())
						continue;

					player_info_t entityInformation;		
					if(!Interfaces.pEngine->GetPlayerInfo(i, &entityInformation))
						continue;

					if (entityInformation.name == "GOTV" && !Target->GetActiveBaseCombatWeapon())
						continue;

					

	

					ImGui::Separator();
					char buf[255]; sprintf_s(buf, u8"%s", entityInformation.name);
					if (ImGui::Selectable(buf, i == currentPlayer, ImGuiSelectableFlags_SpanAllColumns))
						currentPlayer = i;
				}
			}
		}
		ImGui::ListBoxFooter();

	

		if (currentPlayer != -1)
		{
			player_info_t entityInformation;
			Interfaces.pEngine->GetPlayerInfo(currentPlayer, &entityInformation);

			ImVec2 siz = ImVec2(200, 625 - ImGui::GetCursorPosY() - 40);
			ImVec2 size = ImVec2(200, 625 - ImGui::GetCursorPosY() - 40);
			if (ImGui::BeginChild(XorStr("##PLISTFIX-CHILD"), siz, false))
			{

				bool shouldResolve = std::find(CPlayerList::Players.begin(), CPlayerList::Players.end(), entityInformation.userid) != CPlayerList::Players.end();
				if (ImGui::Checkbox(XorStr("Resolver Whitelist"), &shouldResolve))
				{
					if (shouldResolve)
						CPlayerList::Players.push_back(entityInformation.userid);
					else
						CPlayerList::Players.erase(std::find(CPlayerList::Players.begin(), CPlayerList::Players.end(), entityInformation.userid));
				}

				ImGui::Combo(XorStr("PitchFix"), &g_Options.Players.AAA[currentPlayer].PAngle, XorStr("Auto\0\rDown\0\rUp\0\rZero\0\rEmotion\0\0"), -1);
					
			} ImGui::EndChild(); ImGui::SameLine();
			if (ImGui::BeginChild(XorStr("##CLEARS-CHILD"), size, false))
			{
				if (ImGui::Button(XorStr("Clear NoResolve"), ImVec2(93.f, 20.f)))
					CPlayerList::Players.clear();
				if (ImGui::Button(XorStr("Clear Fixes"), ImVec2(93.f, 20.f))) {
					if (Interfaces.pEngine->IsInGame())
					{
						for (int i = 1; i < 65; i++)
						{
							g_Options.Players.AAA[i].PAngle = 0;
						}
					}
				}
			} ImGui::EndChild(); ImGui::NewLine();
		}
	}
	ImGui::End();
}

namespace MenuUI
{
	void SkinChangerWindow(IDirect3DDevice9* pDevice, IDirect3DTexture9 *TittleBar)
	{

		static bool notFull = true;
		static bool notFull1 = true;
		static bool notFull2 = true;
		static int XMenu = 1;
		static int YMenu = 80;


		if (!g_Options.Menu.Opened || !g_Options.Menu.SkinChangerWindow)
		{
			notFull = true;
			notFull1 = true;
			notFull2 = true;
			XMenu = 1;
			YMenu = 80;
		}
		if (g_Options.Menu.Opened && g_Options.Menu.SkinChangerWindow)
		{
	
			int pX, pY;
			Interfaces.g_pInputSystem->GetCursorPosition(&pX, &pY);
			ImGuiIO& io = ImGui::GetIO();
			io.MousePos.x = (float)(pX);
			io.MousePos.y = (float)(pY);
			//VMProtectBeginMutation("MENU");
			//	char nameChar[128];
			//	sprintf(nameChar, "Project Z");

			int windowWidth3 = 500;
			int windowHeight3 = 350;



			if (windowWidth3 <= XMenu) {
				notFull1 = false;
			}
			if (windowHeight3 <= YMenu) {
				notFull2 = false;
			}
			ImGui::SetNextWindowSize(ImVec2(XMenu, YMenu));

			if (notFull1)
			{
				if (g_Options.Menu.Animations)
					XMenu += 32;
				else
					XMenu = windowWidth3;
			}
			if (notFull2 && !notFull1)
			{
				if (g_Options.Menu.Animations)
					YMenu += 20;
				else
					YMenu = windowHeight3;
			}


			if (ImGui::Begin(("SkinChanger"), &g_Options.Menu.SkinChangerWindow, ImVec2(XMenu, YMenu), 0.0F, (notFull1 || notFull2 ? ImGuiWindowFlags_NoMove : 0) | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar))
			{

				ImGui::PushFont(GlobalFont);
				





				//if (notFull) return;	ImVec2 lPos = ImGui::GetCursorPos();
				ImGuiContext* io = ImGui::GetCurrentContext();
				ImGuiStyle& style = ImGui::GetStyle();


				ImDrawList* windowDrawList = ImGui::GetWindowDrawList();
				windowDrawList->AddRectFilledMultiColor(ImVec2(ImGui::GetWindowPos().x - 5, ImGui::GetWindowPos().y), ImVec2(ImGui::GetWindowPos().x + windowWidth3 + 10, ImGui::GetWindowPos().y + 95),
					ImColor(0.f, 0.f, 0.f, 0.f),//Upleft
					ImColor(0.f, 0.f, 0.f, 0.f),//UpRight
					ImColor(XMenu / 5500.f, XMenu / 5500.f, XMenu / 5500.f, 0.65f),//downleft

					ImColor(XMenu / 5500.f, XMenu / 5500.f, XMenu / 5500.f, 0.65f));//downright


				

				//	if (LegitTabImg == nullptr)D3DXCreateTextureFromFileInMemoryEx(pDevice
				//		, &NameLegitArray, sizeof(NameLegitArray),
				//		1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &LegitTabImg);





				if (!LegitTabImg)
					D3DXCreateTextureFromFileInMemoryEx(pDevice, &NameLegitArray, sizeof(NameLegitArray), 1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &LegitTabImg);


				ImVec2 curWindowPos = ImGui::GetWindowPos();
				windowDrawList->AddImage(TittleBar, ImVec2(curWindowPos.x + 500 / 2.3f, curWindowPos.y), ImVec2(curWindowPos.x + 500 / 2.3f + 95, curWindowPos.y + 95));

				ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_BorderShadow, ImVec4(0.05f, 1.0f, 0.05f, 0.f));

				ImGui::Text(XorStr("                                         "));
				ImGui::Text(XorStr("                                         "));
				ImGui::Text(XorStr("                                         "));

				ImGui::Text(XorStr("                                         "));
				ImGui::Text(XorStr("                                         "));


				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();





				ImGui::BeginChild(XorStr("SkinChangerTabs"), ImVec2(ImGui::GetWindowWidth() - 17, 0), true, notFull1 || notFull2 ? ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar : ImGuiWindowFlags_NoResize | ImGuiWindowFlags_ShowBorders);
				{
					
					ImGui::Separator();

					if (ImGui::Checkbox(XorStr("enable Changer"), &g_Options.Skinchanger.EnabledChanger))g_Skinchanger->ForceItemUpdates();
					ImGui::SameLine(); if (ImGui::Button(XorStr("update"), ImVec2(100.f, 20.f)))g_Skinchanger->ForceItemUpdates();
					if (ImGui::Combo(XorStr("knife Changer"), &g_Options.Skinchanger.knifemodel, XorStr("none\0\rkerambit\0\rbayonet\0\rm9 bayonet\0\rhuntsman\0\rgut\0\rfalchion\0\rdaggers\0\rbutterfly\0\rflip\0\rbowie\0\0"), -1, ImVec2(130, 0)))g_Skinchanger->ForceItemUpdates();
					if (ImGui::Combo(XorStr("glove Model"), &g_Options.Skinchanger.glovemodel, XorStr("none\0\rbloodhound\0\rsport\0\rdriver\0\rhand wraps\0\rmotorcycle\0\rspecialst\0\rhydra\0\0"), -1, ImVec2(130, 0)))g_Skinchanger->ForceItemUpdates();


					const char* gstr;
					if (g_Options.Skinchanger.glovemodel == 1)
					{
						gstr = "charred\0\rsnakebite\0\rbronzed\0\rguerilla\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 2)
					{
						gstr = "hedge maze\0\randoras box\0\rsuperconductor\0\rarid\0\rvice\0\romega\0\ramphibious\0\rbronze morph\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 3)
					{
						gstr = "lunar weave\0\rconvoy\0\rcrimson weave\0\rdiamondback\0\rovertake\0\rracing green\0\rking snake\0\rimperial plaid\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 4)
					{
						gstr = "leather\0\rspruce ddpat\0\rslaughter\0\rbadlands\0\rcobalt skulls\0\roverprint\0\rduct tape\0\rarboreal\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 5)
					{
						gstr = "eclipse\0\rspearmint\0\rboom!\0\rcool mint\0\rturtle\0\rtransport\0\rpolygon\0\rpow!\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 6)
					{
						gstr = "forest ddpat\0\rcrimson kimono\0\remerald web\0\rfoundation\0\rcrimson web\0\rbuckshot\0\rfade\0\rmogul\0\0";
					}
					else if (g_Options.Skinchanger.glovemodel == 7)
					{
						gstr = "emerald\0\rmangrove\0\rrattler\0\rcase hardened\0\0";
					}
					else
					{
						gstr = "";
					}

					if (ImGui::Combo(XorStr("glove skin"), &g_Options.Skinchanger.gloveskin, gstr, -1, ImVec2(130, 0)))g_Skinchanger->ForceItemUpdates();

					std::string skinName = GetWeaponNameById(g_Options.wpn);
					if (g_Options.wpn <= 0)
						//ImGui::Text(XorStr("Parser not Found Skin For This Weapon | Try Later"));
						ImGui::InputInt(XorStr(u8"skin"), &g_Options.Skinchanger.SkinMaster[g_Options.wpn].PaintKit);
					else
					{
						std::string skinStr = "";
						int curItem = -1;
						int s = 0;
						for (auto skin : weaponSkins[skinName])
						{
							int pk = skinMap[skin].paintkit;
							if (pk == g_Options.Skinchanger.SkinMaster[g_Options.wpn].PaintKit)
								curItem = s;

							skinStr += skinNames[skinMap[skin].tagName].c_str();
							skinStr.push_back('\0');
							s++;
						}
						skinStr.push_back('\0');
						if (ImGui::Combo(XorStr(u8"skin"), &curItem, skinStr.c_str()))
						{
							int pk = 0;
							int c = 0;
							for (auto skin : weaponSkins[skinName])
							{
								if (curItem == c)
								{
									pk = skinMap[skin].paintkit;
									break;
								}

								c++;
							}
							g_Options.Skinchanger.SkinMaster[g_Options.wpn].PaintKit = pk;
							if (g_Options.Skinchanger.EnabledChanger) g_Skinchanger->ForceItemUpdates();
						}
					}


					if (ImGui::InputInt(XorStr("seed"), &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Seed))g_Skinchanger->ForceItemUpdates();
					if (ImGui::Checkbox(XorStr("stattrak"), &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stattrak))g_Skinchanger->ForceItemUpdates();
					if (g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stattrak)
					{
						if (ImGui::InputInt(XorStr("stattrak value"), &g_Options.Skinchanger.SkinMaster[g_Options.wpn].StattrakValue))g_Skinchanger->ForceItemUpdates();
					}
					ImGui::PushItemWidth(140);
					if (ImGui::SliderFloat(XorStr("wear procent"), &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Wear, 0, 100))g_Skinchanger->ForceItemUpdates();
					ImGui::PopItemWidth();


					ImGui::Separator();

					if (!IsKnifeForMenu(g_Options.wpn) && g_Options.wpn != 0)
					{
						if (ImGui::Checkbox("sticker Changer", &g_Options.Skinchanger.SkinMaster[g_Options.wpn].StickersEnabled)) if (g_Options.Skinchanger.EnabledChanger) g_Skinchanger->ForceItemUpdates();
						static int iSlot = 0;
						ImGui::Combo("slot", &iSlot, "1 slot\0\r2 slot\0\r3 slot\0\r4 slot\0\0",-1,ImVec2(120,20));
						if (ImGui::SliderFloat("wear ", &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stickers[iSlot].flWear, 0.f, 1.f))g_Skinchanger->ForceItemUpdates();
						if (ImGui::SliderFloat("scale", &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stickers[iSlot].flScale, 0.f, 1.f)) g_Skinchanger->ForceItemUpdates();
						if (ImGui::SliderInt("rotation", &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stickers[iSlot].iRotation, 0, 360))g_Skinchanger->ForceItemUpdates();
						if (ImGui::InputInt("id", &g_Options.Skinchanger.SkinMaster[g_Options.wpn].Stickers[iSlot].iID))g_Skinchanger->ForceItemUpdates();
					}


				}ImGui::EndChild();
				
				ImGui::PopFont();

			}
			ImGui::End();





		}
	}


	void Render(IDirect3DDevice9* pDevice)
	{
		if (!pDevice)
			return;

		ImGui::GetIO().MouseDrawCursor = g_Options.Menu.Opened;

		ImGui_ImplDX9_NewFrame();

		if (g_Options.Menu.Opened)
		{
			if (TittleBar == nullptr)D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NameArry, sizeof(NameArry),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &TittleBar);
			
		}
		SkinChangerWindow(pDevice, TittleBar);
		


		if (g_Options.Visuals.Panels.Monitor)
			RenderMonitor();

		if (g_Options.Visuals.Panels.Radar.ExternalRadar)
			RenderRadar();

		if (g_Options.Misc.SpectatorList)
		{
			ImGuiStyle& style = ImGui::GetStyle();
			style.ChildWindowRounding = 4.0f;
			style.WindowRounding = 4.0f;

			if (ImGui::Begin(XorStr("spectators"), &g_Options.Misc.SpectatorList, ImVec2(300, 100), 0.5f, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize))
			{
				ImGui::Text(XorStr("spectator list"));

				int max = 65;

				for (int i = 1; i < max; i++)
				{
					CBaseEntity *entity = Interfaces.pEntList->GetClientEntity(i);

					if (NULL == entity) continue;
					if (entity->IsDormant()) continue;

					if (entity->GetClientClass()->m_ClassID != _CCSPlayer) continue;

					CBaseHandle sh = entity->GetObserverTarget();

					if (sh == 0xFFFFFFFF) continue;

					CBaseEntity *spectating = Interfaces.pEntList->GetClientEntityFromHandle(sh);

					if (spectating != NULL && spectating == G::LocalPlayer)
					{
						player_info_t info;
						if (Interfaces.pEngine->GetPlayerInfo(entity->GetIndex(), &info))
						{
							std::string tmp = SanitizeName(info.name);

							ImGui::Text(u8"%s", tmp.c_str());
						}
					}
				}

				ImGui::End();
			}
			style.ChildWindowRounding = 0.0f;
			style.WindowRounding = 0.0f;

		}

		static bool notFull = true;
		static bool notFull1 = true;
		static bool notFull2 = true;
		static int XMenu = 1;
		static int YMenu = 80;

		if (!g_Options.Menu.Opened)
		{
			notFull = true;
			notFull1 = true;
			notFull2 = true;
			XMenu = 1;
			YMenu = 95;
		}
		if (g_Options.Menu.Opened)
		{

			if (g_Options.Players.Playerlist)
				PlayerList();

			int pX, pY;
			Interfaces.g_pInputSystem->GetCursorPosition(&pX, &pY);
			ImGuiIO& io = ImGui::GetIO();
			io.MousePos.x = (float)(pX);
			io.MousePos.y = (float)(pY);
			//VMProtectBeginMutation("MENU");
			//	char nameChar[128];
			//	sprintf(nameChar, "Project Z");

			int windowWidth3 = 750;
			int windowHeight3 = 530;



			if (windowWidth3 <= XMenu) {
				notFull1 = false;
			}
			if (windowHeight3 <= YMenu) {
				notFull2 = false;
			}
			ImGui::SetNextWindowSize(ImVec2(XMenu, YMenu));

			if (notFull1)
			{
				if (g_Options.Menu.Animations)
					XMenu += 32;
				else
					XMenu = windowWidth3;
			}
			if (notFull2 && !notFull1)
			{
				if (g_Options.Menu.Animations)
					YMenu += 20;
				else
					YMenu = windowHeight3;
			}

			if (ImGui::Begin(("Spectro"), &g_Options.Menu.Opened, ImVec2(XMenu, YMenu), 0.0F, (notFull1 || notFull2 ? ImGuiWindowFlags_NoMove : 0) | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_ShowBorders | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar))
			{


				ImGui::PushFont(GlobalFont);
			

				static bool legitTab = false;
				static bool visualsTab = false;
				static bool changer = false;
				static bool rageTab = false;
				static bool configTab = false;
				static bool miscTab = false;
				static bool testTab = false;




				//if (notFull) return;	ImVec2 lPos = ImGui::GetCursorPos();
				ImGuiContext* io = ImGui::GetCurrentContext();
				ImGuiStyle& style = ImGui::GetStyle();


				ImDrawList* windowDrawList = ImGui::GetWindowDrawList();
				windowDrawList->AddRectFilledMultiColor(ImVec2(ImGui::GetWindowPos().x - 5, ImGui::GetWindowPos().y), ImVec2(ImGui::GetWindowPos().x + windowWidth3 + 10, ImGui::GetWindowPos().y + 90),
					ImColor(0.f, 0.f, 0.f, 0.f),//Upleft
					ImColor(0.f, 0.f, 0.f, 0.f),//UpRight
					ImColor(XMenu / 5500.f, XMenu / 5500.f, XMenu / 5500.f, 0.65f),//downleft

					ImColor(XMenu / 5500.f, XMenu / 5500.f, XMenu / 5500.f, 0.65f));//downright




				if (!LegitTabImg)
					D3DXCreateTextureFromFileInMemoryEx(pDevice, &NameLegitArray, sizeof(NameLegitArray), 1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &LegitTabImg);

				if (RageTabImg == nullptr)D3DXCreateTextureFromFileInMemoryEx(pDevice
					, &NameRageArray, sizeof(NameRageArray),
					1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &RageTabImg);

				if (VisualsTabImg == nullptr)D3DXCreateTextureFromFileInMemoryEx(pDevice
					, &NameVisualsArray, sizeof(NameVisualsArray),
					1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &VisualsTabImg);


				if (MiscTabImg == nullptr)D3DXCreateTextureFromFileInMemoryEx(pDevice
					, &NameMiscArray, sizeof(NameMiscArray),
					1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &MiscTabImg);
				ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				ImGui::PushStyleColor(ImGuiCol_BorderShadow, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
				
				
				ImVec2 curWindowPos = ImGui::GetWindowPos();
				windowDrawList->AddImage(TittleBar, ImVec2(curWindowPos.x + 750 / 2.5f + 30, curWindowPos.y), ImVec2(curWindowPos.x + 750 / 2.5f + 125, curWindowPos.y + 95));

				//ImGui::Text(XorStr("                                                                     "));
				//ImGui::SameLine();
				//ImGui::Image(TittleBar, ImVec2(150, 75));

				ImGui::Text(XorStr("        "));
				ImGui::Text(XorStr("        "));
				ImGui::Text(XorStr("        "));
				ImGui::Text(XorStr("        "));

				ImGui::Text(XorStr("         "));
				ImGui::SameLine();
				if (ImGui::ImageButton(LegitTabImg, ImVec2(105, 105))) {
					rageTab = false;
					legitTab = true;
					visualsTab = false;
					changer = false;
					configTab = false;
					miscTab = false;
				}
				ImGui::SameLine();
				ImGui::Text(XorStr("       "));
				ImGui::SameLine();
				if (ImGui::ImageButton(RageTabImg, ImVec2(105, 105))) {
					rageTab = true;
					legitTab = false;
					visualsTab = false;
					changer = false;
					configTab = false;
					miscTab = false;
				}
				ImGui::SameLine();
				ImGui::Text(XorStr("       "));
				ImGui::SameLine();
				if (ImGui::ImageButton(VisualsTabImg, ImVec2(105, 105))) {
					rageTab = false;
					legitTab = false;
					visualsTab = true;
					changer = false;
					configTab = false;
					miscTab = false;
				}
				ImGui::SameLine();
				ImGui::Text(XorStr("       "));
				ImGui::SameLine();
				if (ImGui::ImageButton(MiscTabImg, ImVec2(105, 105))) {
					rageTab = false;
					legitTab = false;
					visualsTab = false;
					miscTab = true;
				}


				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();
				ImGui::PopStyleColor();



				if (rageTab)
					DrawRagechildMeme(notFull1 || notFull2);
				if (visualsTab)
					DrawVisualschildMeme(notFull1 || notFull2);
				if (miscTab)
					DrawMiscchildMeme(notFull1 || notFull2);
				if(legitTab)
					DrawlegitchildMeme(notFull1 || notFull2);
		

			}
			ImGui::End();


			ImGui::PopFont();


		}

		ImGui::Render();
	}


}