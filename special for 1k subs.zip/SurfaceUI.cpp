#include "stdafx.h"
#include "SurfaceUI.h"
#define DeclareColorRGBA(x) x.r(),x.g(),x.b(),x.a()
#define DeclareXY(UIPos, w , h) UIPos.x,UIPos.y,UIPos.x + w , UIPos.y + h
#define DeclareXYOutLine(UIPos, w , h, size) UIPos.x - size,UIPos.y - size,UIPos.x + w + size * 2, UIPos.y + h + size * 2
CSurfaceUI* SurfaceUI = new CSurfaceUI();
CCheckBoxUI* CheckBoxUI = new CCheckBoxUI();
CDropBoxUI* DropBoxUI = new CDropBoxUI();
CSliderUI* SliderUI = new CSliderUI();
CInputTextUI* InputTextUI = new CInputTextUI();
CButtonUI* ButtonUI = new CButtonUI();
CSurfaceUIVars* g_OptionsTest = new CSurfaceUIVars();


void CSurfaceUI::Initalize(int Stage)
{

	switch (Stage)
	{
	case MenuStages::StartStageOfMenu:
	{
		Dont_Click = false;

		static bool Initalized = false;
		if (!Initalized)
		{
			int x, y; Interfaces.pEngine->GetScreenSize(x, y);
			UIPos.x = x / 2;
			UIPos.y = y / 2;

			SurfaceUI->SetupStyles();
			Initalized = true;
		}

		if (!(GetAsyncKeyState(VK_LBUTTON) & 0x8000))
		{
			Holding_Mouse_1 = false;
		}
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
		{
			Clicked_This_Frame = true;
		}
		else
		{
			Clicked_This_Frame = false;
		}
		Update_Frame();
	}break;

	case MenuStages::EndStageOfMenu:
	{
		DrawMouse();

		if (Clicked_This_Frame)
		{
			Holding_Mouse_1 = true;
		}

		
	
		
	}break;
	default:break;

	}
	
}


void CSurfaceUI::SetupStyles()
{
	//Colors
	UIStyle.Colors.FrameBackGround = CColor(28, 28, 28, 140);
	UIStyle.Colors.FrameBorder = CColor(255, 155, 28, 140);
	UIStyle.Colors.FrameTitleBar = CColor(54, 54, 54, 255);
	UIStyle.Colors.Text = CColor(255, 255, 255, 255);


	//Sizes
	UIStyle.Sizes.FrameBorderSize = 4;
	UIStyle.Sizes.FrameTitleBarSize = 25;


	//AddPoses
	UIStyle.AddPos.FrameTitleBarX = -25;
	UIStyle.AddPos.FrameTitleBarY = 3;


}
#include <corecrt_malloc.h>


void TestButton()
{
	Interfaces.pEngine->ClientCmd_Unrestricted("clear",0);
	Interfaces.pEngine->ClientCmd_Unrestricted("echo TestButton", 0);

}
static bool CanDraw;
void CSurfaceUI::DrawUI()
{
	
	SurfaceUI->Initalize(StartStageOfMenu);

	CanDraw = false;
	SurfaceUI->BeginFrame("Revenger.us", UIVec2(600,350), true, true);


	SurfaceUI->CheckBox("Test 1", &g_OptionsTest->Test1, 50, 50);
	if (g_OptionsTest->Test1)
	{
		SurfaceUI->CheckBox("Test 2", &g_OptionsTest->Test2, 50, 70);
		std::vector< char* > Hitbox = { "Testmeme2", "Testmeme2", "Testmeme3", "Testmeme4" };
		std::vector< char* > Hitbox3 = { "Testmeme23", "Testmeme23", "Testmeme213", "31" };

	
		SurfaceUI->ComboBox("Test 3", &g_OptionsTest->Test3, 50, 100, Hitbox, FuncStages::InitFunc);


		static int ddd;
		SurfaceUI->ComboBox("Test 66", &ddd, 160, 100, Hitbox, FuncStages::InitFunc);


		SurfaceUI->SliderInt("Test 4", &g_OptionsTest->Test4, 0, 100, 50, 130);


		
		SurfaceUI->InputText("Test 5", Test1, 50, 160);

		SurfaceUI->Button("Test 6", (DWORD)TestButton, 50, 200);

	}

	

	CanDraw = true;
	SurfaceUI->Initalize(EndStageOfMenu);
}


void CSurfaceUI::InputText(char* name, int itsa, int x, int y)
{
	InputTextUI->Init(name, itsa, x, y);
}
void CSurfaceUI::Button(char* name, DWORD function, int x, int y)
{
	ButtonUI->Init(x,y,function,name);
}
void CSurfaceUI::CheckBox(char* name, bool* Func, int x, int y)
{
	CheckBoxUI->Init(name, Func, x, y);
}
void CSurfaceUI::SliderInt(char* name, int* Func, double min, double max, int x, int y)
{
	SliderUI->Init(x,y,min,max,name,Func);
}
void CSurfaceUI::ComboBox(char* name, int* Func, int x, int y, std::vector< char* > arr, int stage)
{
	DropBoxUI->Init(x, y, Func, name, arr.size(), arr);
	DropBoxUI->Draw();
}


void CSurfaceUI::BeginFrame(char* name, const UIVec2& VecUI, bool borders, bool TitleBar)
{
	UIVec2 size = VecUI;
	
	UIPos.UIUpdateX = VecUI.x;
	UIPos.UIUpdateY = TitleBar ? UIStyle.Sizes.FrameTitleBarSize : VecUI.y;

	Interfaces.pSurface->DrawSetColor(DeclareColorRGBA(UIStyle.Colors.FrameBackGround));
	Interfaces.pSurface->DrawFilledRect(DeclareXY(UIPos, size.x, size.y));

	if (TitleBar)
	{
		Interfaces.pSurface->DrawSetColor(DeclareColorRGBA(UIStyle.Colors.FrameTitleBar));
		Interfaces.pSurface->DrawFilledRect(DeclareXY(UIPos, size.x, UIStyle.Sizes.FrameTitleBarSize));

		Interfaces.pSurface->DrawT(UIPos.x + size.x / 2 + UIStyle.AddPos.FrameTitleBarX, UIPos.y + UIStyle.AddPos.FrameTitleBarY, CColor(UIStyle.Colors.Text), Hacks.Font_HUD, false, "Revenger.us");
		
	}

	if (borders)
	{
		Interfaces.pSurface->DrawSetColor(DeclareColorRGBA(UIStyle.Colors.FrameBorder));
		for (int i = 1; i < UIStyle.Sizes.FrameBorderSize; i++)
		{
			Interfaces.pSurface->DrawOutlinedRect(DeclareXYOutLine(UIPos, size.x, size.y, i));
		}
	}
}
void CSurfaceUI::DrawMouse()
{
	int red;
	int blue;
	int green;


	static float rainbow;
	rainbow += 0.002f;
	red = abs(255 * sin(rainbow + 4));
	blue = abs(255 * sin(rainbow + 2));
	green = abs(255 * sin(rainbow));
	POINT Mouse;
	POINT mp;
	GetCursorPos(&mp);
	ScreenToClient(GetForegroundWindow(), &mp);
	Mouse.x = mp.x;
	Mouse.y = mp.y;
	static int Texturer = Interfaces.pSurface->CreateNewTextureID(true);
	unsigned char buffer[4] = { (unsigned char)255, (unsigned char)255, (unsigned char)255, (unsigned char)255 };

	Interfaces.pSurface->DrawSetTextureRGBA(Texturer, buffer, 1, 1);
	Interfaces.pSurface->DrawSetTexture(Texturer);
	Interfaces.pSurface->DrawSetColor(red, green, blue, 255);
	/**/
	Vertex_t Verts[4];
	Verts[0].x = Mouse.x;
	Verts[0].y = Mouse.y;
	Verts[1].x = Mouse.x + 15;
	Verts[1].y = Mouse.y + 5;
	Verts[2].x = Mouse.x + 15;
	Verts[2].y = Mouse.y + 15;
	Verts[3].x = Mouse.x + 5;
	Verts[3].y = Mouse.y + 15;
	Interfaces.pSurface->DrawTexturedPolygon(4, Verts);
	static int Texturer2 = Interfaces.pSurface->CreateNewTextureID(true);
	unsigned char buffer2[5] = { (unsigned char)255, (unsigned char)255, (unsigned char)255, (unsigned char)255 };

	Interfaces.pSurface->DrawSetTextureRGBA(Texturer2, buffer2, 1, 1);
	Interfaces.pSurface->DrawSetTexture(Texturer2);
	Interfaces.pSurface->DrawSetColor(60, 60, 60, 255);
	Vertex_t Verts3[4];
	Verts3[0].x = Mouse.x + 4;
	Verts3[0].y = Mouse.y + 4;
	Verts3[1].x = Mouse.x + 15;
	Verts3[1].y = Mouse.y + 7;
	Verts3[2].x = Mouse.x + 15;
	Verts3[2].y = Mouse.y + 15;
	Verts3[3].x = Mouse.x + 7;
	Verts3[3].y = Mouse.y + 15;
	Interfaces.pSurface->DrawTexturedPolygon(4, Verts3);
}
void CSurfaceUI::Update_Frame()
{
	if (!Holding_Mouse_1)
	{
		if (Clicked_CurrentFrame())
		{
			Holding_Menu = true;
		}
		else
		{
			Holding_Menu = false;
		}
	}

	if (Holding_Menu)
	{
		UIPositions NewPOS;
		POINT Mouse;
		POINT mp;
		GetCursorPos(&mp);
		ScreenToClient(GetForegroundWindow(), &mp);
		Mouse.x = mp.x;
		Mouse.y = mp.y;



		NewPOS.x = Mouse.x - Menu_Drag_X;
		NewPOS.y = Mouse.y - Menu_Drag_Y;
		this->UIPos.x = NewPOS.x;
		this->UIPos.y = NewPOS.y;

	}
}
bool CSurfaceUI::Clicked_CurrentFrame()
{
	if (!(GetAsyncKeyState(VK_LBUTTON) & 0x8000))
	{
		return false;
	}

	POINT Mouse;
	POINT mp;
	GetCursorPos(&mp);
	ScreenToClient(GetForegroundWindow(), &mp);
	Mouse.x = mp.x;
	Mouse.y = mp.y;


	
	if (Mouse.x > this->UIPos.x && Mouse.y > this->UIPos.y - 16 && Mouse.x < this->UIPos.x + this->UIPos.UIUpdateX && Mouse.y < this->UIPos.y + this->UIPos.UIUpdateY)
	{
		if (!Holding_Mouse_1)
		{
			Menu_Drag_X = Mouse.x - UIPos.x;
			Menu_Drag_Y = Mouse.y - UIPos.y;
		}
		return true;
	}
	else
	{
		return false;
	}
}