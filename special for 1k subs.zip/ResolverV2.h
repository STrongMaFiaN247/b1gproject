#pragma once
#include "stdafx.h"






struct ResolverData
{

	float yaw, addyaw, addmoveyaw, lbycurtime, unres;
	int Shoot;
	float  lastmovinglby = 1337.f;
	int tick, balanceadjusttick, missedshots, shoots;
	bool playerhurtcalled;

};

class CResolver {
public:
	void AntiAimResolver();
	ResolverData pResolverData[64];
private:
	void DeleteInfo(int i);
};

extern CResolver* Resolver;

void CResolver::DeleteInfo(int i)
{
	pResolverData[i].addyaw = 0.f;
	pResolverData[i].addmoveyaw = 0.f;
	pResolverData[i].Shoot = 0;
	pResolverData[i].lastmovinglby = 1337.f;
	pResolverData[i].unres = 1337.f;

}
void CResolver::AntiAimResolver()
{	
	for (int i = 1; i < 65; i++)
	{
		auto pEntity = Interfaces.pEntList->GetClientEntity(i);

		if (!pEntity || !G::LocalPlayer)
		{	DeleteInfo(i); continue; }
			

		if (pEntity == G::LocalPlayer)
		{
			DeleteInfo(i); continue;
		}

		if (pEntity->GetTeam() == G::LocalPlayer->GetTeam())
		{
			DeleteInfo(i); continue;
		}

		if (pEntity->IsDormant())
		{
			continue;
		}

		Hacks.CurMode[i] = ResolverModes::NONE;

		
		if (pEntity->isAlive())
		{

			if (g_Options.Ragebot.Ragebot_Resolver)
			{
				int FakeLby = 0;

				Vector* pAngles = pEntity->GetEyeAnglesPointer();
			

				if (G::LocalPlayer->GetShootsField() > 1)
				{
					if (G::LocalPlayer->GetShootsField() != pResolverData[G::AimbotID].shoots)
					{
						if (!pResolverData[G::AimbotID].playerhurtcalled)
						{
							pResolverData[G::AimbotID].addyaw += 45.f;
							pResolverData[G::AimbotID].addmoveyaw += 15.f;
							pResolverData[G::AimbotID].Shoot++;
						}
						else
							pResolverData[G::AimbotID].playerhurtcalled = false;
						pResolverData[G::AimbotID].shoots = G::LocalPlayer->GetShootsField();
					}
				}

				CAnimationLayer *layer6 = pEntity->GetAnimOverlayAARec(6);
				if (layer6 && layer6->m_flPlaybackRate > 0.0f && layer6->m_flPlaybackRate < 0.008f && pEntity->GetVecVelocity().Length2D() <= 24.0f)
					Hacks.fakewalking[i] = true;
				else
					Hacks.fakewalking[i] = false;

				for (int w = 0; w < 13; w++)
				{
					auto layer = pEntity->GetAnimOverlaysAARec()[w];

					int number = layer.m_nSequence,
						activity = pEntity->GetSequenceActivity(number);


					if (pResolverData[i].Shoot >= 10 || !G::LocalPlayer->isAlive())
					{
						pResolverData[i].Shoot = 0;
					}

					

					if (pEntity->GetVecVelocity().Length2D() > 1.f && pEntity->GetFlags() & FL_ONGROUND && !Hacks.fakewalking[i]) //��� �� �������� � �� � ������� �� �����, �� �� � ����
					{
						pResolverData[i].lastmovinglby = pEntity->pelvisangs(); // ����������  ��� ���

						pAngles->y = pEntity->pelvisangs(); // ��� ��������� �� ���� ����� 

						Hacks.CurMode[i] = ResolverModes::MOVING;
					}
					else
					{
						if (pResolverData[i].lastmovinglby != 1337.f)
						{
							pAngles->y = pResolverData[i].lastmovinglby + pResolverData[G::AimbotID].addmoveyaw; //������ ������� ���, ���� ��� ��������

							Hacks.CurMode[i] = ResolverModes::LBY;
						}
						else
						{
							if (pResolverData[i].unres != 1337.f)
							{
								pAngles->y = pResolverData[i].unres + pResolverData[G::AimbotID].addmoveyaw; //������ ������� ���, ���� ��� ��������

								Hacks.CurMode[i] = ResolverModes::LASTSHAKELBY;
							}
							else
							{
								pAngles->y = pEntity->pelvisangs() + 180; //������ ������� ���, ���� ��� ��������

								Hacks.CurMode[i] = ResolverModes::LBY_BRUTE;
							}
						}
					}
					
					
				
				

					if (activity == 979 && (w == 3 || w == 2 || w == 5 || w == 6))
						FakeLby = 1;
			



				}

				Hacks.FakingLBY[i] = FakeLby;

				if (pEntity->GetAnimOverlaysAARec()[3].m_flWeight < 0.01f && pEntity->GetAnimOverlaysAARec()[3].m_flCycle < 0.92f &&  (pEntity->GetVecVelocity().Length2D() == 0 || Hacks.fakewalking[i]))
				{
					pAngles->y = pEntity->pelvisangs();
					pResolverData[i].unres = pEntity->pelvisangs() + 145.f; // ���������� ������� ���
					Hacks.CurMode[i] = ResolverModes::LBY_FLICK;
					Hacks.FakingLBY[i] = 2;

				}

				pAngles->Normalize();
			}
		}
	}
}
CResolver* Resolver = new CResolver();