#include "Options.h"
#include "stdafx.h"
#include <ios>
Variables g_Options;

namespace CPlayerList
{
	std::vector<int> Players;
}
namespace ResolverVars
{
	int ResolverStage[65];
	int DidhitHS[65];
	int ResolvedpAngles[65];
}