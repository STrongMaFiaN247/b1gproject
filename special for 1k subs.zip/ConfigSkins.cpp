#include "ConfigSkins.h"
//#include "SDK.h"
#include <winerror.h>
#include <ShlObj.h>
#include <ShlObj_core.h>
#pragma comment(lib, "Shell32.lib")


std::string GetCFGNameChangerRR(int iWeaponID, int secondint)
{
	if (secondint == 0)
	{
		switch (iWeaponID)
		{
		case WEAPON_DEAGLE:
			return XorStr("Desert Eagle");
		case WEAPON_ELITE:
			return XorStr("Dual Berettas");
		case WEAPON_FIVESEVEN:
			return XorStr("Five-SeveN");
		case WEAPON_GLOCK:
			return XorStr("Glock-18");
		case WEAPON_AK47:
			return XorStr("AK-47");
		case WEAPON_AUG:
			return XorStr("AUG");
		case WEAPON_AWP:
			return XorStr("AWP");
		case WEAPON_FAMAS:
			return XorStr("FAMAS");
		case WEAPON_G3SG1:
			return XorStr("G3SG1");
		case WEAPON_GALILAR:
			return XorStr("Galil");
		case WEAPON_M249:
			return XorStr("M249");
		case WEAPON_M4A1:
			return XorStr("M4A1");
		case WEAPON_MAC10:
			return XorStr("MAC-10");
		case WEAPON_P90:
			return XorStr("P90");
		case WEAPON_UMP45:
			return XorStr("UMP-45");
		case WEAPON_XM1014:
			return XorStr("XM1014");
		case WEAPON_BIZON:
			return XorStr("PP-Bizon");
		case WEAPON_MAG7:
			return XorStr("MAG-7");
		case WEAPON_NEGEV:
			return XorStr("Negev");
		case WEAPON_SAWEDOFF:
			return XorStr("Sawed-Off");
		case WEAPON_TEC9:
			return XorStr("Tec-9");
		case WEAPON_TASER:
			return XorStr("Taser");
		case WEAPON_HKP2000:
			return XorStr("P2000");
		case WEAPON_MP7:
			return XorStr("MP7");
		case WEAPON_MP9:
			return XorStr("MP9");
		case WEAPON_NOVA:
			return XorStr("Nova");
		case WEAPON_P250:
			return XorStr("P250");
		case WEAPON_SCAR20:
			return XorStr("SCAR-20");
		case WEAPON_SG556:
			return XorStr("SG 553");
		case WEAPON_SSG08:
			return XorStr("SSG 08");
		case WEAPON_KNIFE:
			return XorStr("KnifeCT");
		case WEAPON_FLASHBANG:
			return XorStr("Flashbang");
		case WEAPON_HEGRENADE:
			return XorStr("HE Grenade");
		case WEAPON_SMOKEGRENADE:
			return XorStr("Smoke Grenade");
		case WEAPON_MOLOTOV:
			return XorStr("Molotov");
		case WEAPON_DECOY:
			return XorStr("Decoy");
		case WEAPON_INCGRENADE:
			return XorStr("Incendiary Grenade");
		case WEAPON_C4:
			return XorStr("C4");
		case WEAPON_KNIFE_T:
			return XorStr("KnifeT");
		case WEAPON_M4A1_SILENCER:
			return XorStr("M4A1-S");
		case WEAPON_USP_SILENCER:
			return XorStr("USP-S");
		case WEAPON_CZ75A:
			return XorStr("CZ75-Auto");
		case WEAPON_REVOLVER:
			return XorStr("R8 Revolver");
		case WEAPON_KNIFE_BAYONET:
			return XorStr("KNIFE_BAYONET");
		case WEAPON_KNIFE_M9_BAYONET:
			return XorStr("KNIFE_M9_BAYONET");
		case WEAPON_KNIFE_SURVIVAL_BOWIE:
			return XorStr("KNIFE_BOWIE");
		case WEAPON_KNIFE_BUTTERFLY:
			return XorStr("KNIFE_BUTTERFLY");
		case WEAPON_KNIFE_FALCHION:
			return XorStr("KNIFE_FALCHION");
		case WEAPON_KNIFE_FLIP:
			return XorStr("KNIFE_FLIP");
		case WEAPON_KNIFE_PUSH:
			return XorStr("KNIFE_PUSH");
		case WEAPON_KNIFE_TACTICAL:
			return XorStr("KNIFE_TACTICAL");
		default:
			return XorStr("none");
		}
	}
	else
	{
		return XorStr("none");
	}
}

void CConfigSkins::Setup()
{
		for (int idNEW = 1; idNEW < 519; idNEW++)
		{
			if ((idNEW > 65 && idNEW < 499))
				continue;
			if(idNEW == 5 || idNEW == 6 || idNEW == 12 || idNEW == 15 || idNEW == 18 || idNEW == 20 || idNEW == 21 || idNEW == 22 || idNEW == 23
				|| idNEW == 37 || idNEW == 41 || idNEW == 50 || idNEW == 51 || idNEW == 52 || idNEW == 53 || idNEW == 54 || idNEW == 55 || idNEW == 56 || idNEW == 57
				|| idNEW == 58 || idNEW == 65 || idNEW == 499)
				continue;
			SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].PaintKit, 0, GetCFGNameChangerRR(idNEW, 0), XorStr("PaintKit"));
			SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].Seed, 0, GetCFGNameChangerRR(idNEW, 0), XorStr("Seed"));
			SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].Stattrak, false, GetCFGNameChangerRR(idNEW, 0), XorStr("Stattrak"));
			SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].StattrakValue, 0, GetCFGNameChangerRR(idNEW, 0), XorStr("StattrakValue"));
			SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].Wear, 0.f, GetCFGNameChangerRR(idNEW, 0), XorStr("Wear"));
	//		SetupValue(g_Options.Skinchanger.SkinMaster[idNEW].StickersEnabled, false, GetCFGNameChangerRR(idNEW, 0), XorStr("StickersEnabled"));
		}
		SetupValue(g_Options.Skinchanger.EnabledChanger, false, "SkinChanger", XorStr("EnabledChanger"));
		SetupValue(g_Options.Skinchanger.knifemodel, 3, "SkinChanger", XorStr("KnifeModel"));
		SetupValue(g_Options.Skinchanger.glovemodel, 3, "SkinChanger", XorStr("GloveModel"));
		SetupValue(g_Options.Skinchanger.gloveskin, 0, "SkinChanger", XorStr("GloveSkin"));

}
void CConfigSkins::SetupValue(char &value, char def, std::string category, std::string name)
{
	value = def;
	chars.push_back(new ConfigValueSkins<char>(category, name, &value));
}
void CConfigSkins::SetupValue(int &value, int def, std::string category, std::string name)
{
	value = def;
	ints.push_back(new ConfigValueSkins<int>(category, name, &value));
}

void CConfigSkins::SetupValue(float &value, float def, std::string category, std::string name)
{
	value = def;
	floats.push_back(new ConfigValueSkins<float>(category, name, &value));
}

void CConfigSkins::SetupValue(bool &value, bool def, std::string category, std::string name)
{
	value = def;
	bools.push_back(new ConfigValueSkins<bool>(category, name, &value));
}


#include <stdio.h>
void CConfigSkins::Delete(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		file = std::string(path) + szCmd;
	}

	DeleteFileA(file.c_str());


}
void CConfigSkins::Rename(char* newname, CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string file, output;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		char szCmd2[256];
		sprintf(szCmd2, "\\Spectro[skincfg]\\%s.ini", newname);

		file = std::string(path) + szCmd;
		output = std::string(path) + szCmd2;
	}

	std::rename(file.c_str(), output.c_str());

}
void CConfigSkins::Save(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		folder = std::string(path) + XorStr("\\Spectro[skincfg]\\");


		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	for (auto value : ints)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : floats)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : bools)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), *value->value ? "true" : "false", file.c_str());


}

void CConfigSkins::Load(CFGTYPE Type)
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[skincfg]\\%s.ini", g_Options.Misc.confignameskins);
		folder = std::string(path) + XorStr("\\Spectro[skincfg]\\");
		
		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	char value_l[32] = { '\0' };

	for (auto value : ints)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atoi(value_l);
	}

	for (auto value : floats)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atof(value_l);
	}

	for (auto value : bools)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = !strcmp(value_l, "true");
	}
}


CConfigSkins* pConfigSkins = new CConfigSkins();


