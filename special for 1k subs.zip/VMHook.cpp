
#include "stdafx.h"
#include "VMHook.h"

int(__cdecl *ReadInt) (uintptr_t);
float(__cdecl *ReadFloat) (uintptr_t);
double(__cdecl *ReadDouble) (uintptr_t);
short(__cdecl *ReadShort) (uintptr_t);
void(__cdecl *WriteByte) (uintptr_t, unsigned char);
void(__cdecl *WriteInt) (uintptr_t, int);
void(__cdecl *WriteFloat) (uintptr_t, float);
void(__cdecl *WriteDouble) (uintptr_t, double);
void(__cdecl *WriteShort) (uintptr_t, short);
VTHook* HNetchanZ = nullptr;