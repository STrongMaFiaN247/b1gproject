#pragma once


namespace MenuUI
{
	void SkinChangerWindow(IDirect3DDevice9* pDevice, IDirect3DTexture9 *TittleBar);
	void Render(IDirect3DDevice9* pDevice);

}