#include "ColorCFG.h"
//#include "SDK.h"
#include <winerror.h>
#include <ShlObj_core.h>
#pragma comment(lib, "Shell32.lib")


void CConfigColors::DeclareSave(int col[4], std::string category)
{
	SetupValue(col[0], 0, category, XorStr("red"));
	SetupValue(col[1], 0, category, XorStr("green"));
	SetupValue(col[2], 0, category, XorStr("blue"));
	SetupValue(col[3], 0, category, XorStr("alpha"));
}

void CConfigColors::Setup()
{
	DeclareSave(CTBoxVisable, XorStr("CTBoxVisable"));
	DeclareSave(CTBoxInVisable, XorStr("CTBoxInVisable"));
	DeclareSave(TBoxVisable, XorStr("TBoxVisable"));
	DeclareSave(TBoxInVisable, XorStr("TBoxInVisable"));

	DeclareSave(CTGlowVisable, XorStr("CTGlowVisable"));
	DeclareSave(CTGlowInVisable, XorStr("CTGlowInVisable"));
	DeclareSave(TGlowVisable, XorStr("TGlowVisable"));
	DeclareSave(TGlowInVisable, XorStr("TGlowInVisable"));

	DeclareSave(Beams, XorStr("Beams"));
	DeclareSave(FilledSpread, XorStr("FilledSpread"));
	DeclareSave(LagCompHitboxes, XorStr("LagCompHitboxes"));
	DeclareSave(SoundESP, XorStr("SoundESP"));
	DeclareSave(DamageESP, XorStr("DamageESP"));

	DeclareSave(FakeAngleChams, XorStr("FakeAngleChams"));
	DeclareSave(Stelki, XorStr("Arrow Indicator"));

	DeclareSave(CTChamsVisable, XorStr("CTChamsVisable"));
	DeclareSave(CTChamsInVisable, XorStr("CTChamsInVisable"));
	DeclareSave(TChamsVisable, XorStr("TChamsVisable"));
	DeclareSave(TChamsInVisable, XorStr("TChamsInVisable"));

	

}
void CConfigColors::SetupValue(char &value, char def, std::string category, std::string name)
{
	value = def;
	chars.push_back(new ConfigValueColors<char>(category, name, &value));
}
void CConfigColors::SetupValue(int &value, int def, std::string category, std::string name)
{
	value = def;
	ints.push_back(new ConfigValueColors<int>(category, name, &value));
}

void CConfigColors::SetupValue(float &value, float def, std::string category, std::string name)
{
	value = def;
	floats.push_back(new ConfigValueColors<float>(category, name, &value));
}

void CConfigColors::SetupValue(bool &value, bool def, std::string category, std::string name)
{
	value = def;
	bools.push_back(new ConfigValueColors<bool>(category, name, &value));
}


#include <stdio.h>
void CConfigColors::Delete()
{
	static char path[MAX_PATH];
	std::string file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[colorcfg]\\%s.ini", g_Options.Misc.confignameColors);
		file = std::string(path) + szCmd;
	}

	DeleteFileA(file.c_str());


}
void CConfigColors::Rename(char* newname)
{
	static char path[MAX_PATH];
	std::string file, output;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[colorcfg]\\%s.ini", g_Options.Misc.confignameColors);
		char szCmd2[256];
		sprintf(szCmd2, "\\Spectro[colorcfg]\\%s.ini", newname);

		file = std::string(path) + szCmd;
		output = std::string(path) + szCmd2;
	}

	std::rename(file.c_str(), output.c_str());

}
void CConfigColors::Save()
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[colorcfg]\\%s.ini", g_Options.Misc.confignameColors);
		folder = std::string(path) + XorStr("\\Spectro[colorcfg]\\");


		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	for (auto value : ints)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : floats)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : bools)
		WritePrivateProfileStringA(value->category.c_str(), value->name.c_str(), *value->value ? "true" : "false", file.c_str());


}

void CConfigColors::Load()
{
	static char path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, path)))
	{
		char szCmd[256];
		sprintf(szCmd, "\\Spectro[colorcfg]\\%s.ini", g_Options.Misc.confignameColors);
		folder = std::string(path) + XorStr("\\Spectro[colorcfg]\\");

		file = std::string(path) + szCmd;
	}

	CreateDirectoryA(folder.c_str(), NULL);

	char value_l[32] = { '\0' };

	for (auto value : ints)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atoi(value_l);
	}

	for (auto value : floats)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atof(value_l);
	}

	for (auto value : bools)
	{
		GetPrivateProfileStringA(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = !strcmp(value_l, "true");
	}
}


CConfigColors* pConfigColors = new CConfigColors();


